﻿#include "pch-cpp.hpp"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include <limits>
#include <stdint.h>



// System.Object[]
struct ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE;
// System.IFormatProvider
struct IFormatProvider_tF2AECC4B14F41D36718920D67F930CED940412DF;
// System.String
struct String_t;

IL2CPP_EXTERN_C RuntimeClass* Int32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Math_tA269614262430118C9FC5C4D9EF4F61C812568F0_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Single_tE07797BA3C98D4CA9B5A19413C19A76688AB899E_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* UInt32_tE60352A06233E4E69DD198BCC67142159F686B15_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* float2_t11F5F2974404951113DDC4E13EEB6E2456295547_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C String_t* _stringLiteral039B19E6A63E9AA22F1AF2817559D285768A7B4A;
IL2CPP_EXTERN_C String_t* _stringLiteral1578CABA4FF62AC9986DD5D0BA4C26A5CCB44A6A;
IL2CPP_EXTERN_C String_t* _stringLiteral43DDB8ABCD260FFF159CAB7520989AEB22E45033;
IL2CPP_EXTERN_C String_t* _stringLiteral50EDAD5CFB15084F3338C313ED64018C8F78CD58;
IL2CPP_EXTERN_C String_t* _stringLiteralE134155080D59FDE2A83A55D0BB359039175A4EA;
IL2CPP_EXTERN_C String_t* _stringLiteralE368123B559BBC0EC2335D3AF9EC37C25C8B5945;
IL2CPP_EXTERN_C String_t* _stringLiteralFEC52A4F763D4C868968D018DEC2AF8064D4C8E2;

struct ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE;

IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END

#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct U3CModuleU3E_tA96012C582F6417CD28F1C5F72BB7CDE7A2C96C8 
{
public:

public:
};


// System.Object

struct Il2CppArrayBounds;

// System.Array


// System.String
struct String_t  : public RuntimeObject
{
public:
	// System.Int32 System.String::m_stringLength
	int32_t ___m_stringLength_0;
	// System.Char System.String::m_firstChar
	Il2CppChar ___m_firstChar_1;

public:
	inline static int32_t get_offset_of_m_stringLength_0() { return static_cast<int32_t>(offsetof(String_t, ___m_stringLength_0)); }
	inline int32_t get_m_stringLength_0() const { return ___m_stringLength_0; }
	inline int32_t* get_address_of_m_stringLength_0() { return &___m_stringLength_0; }
	inline void set_m_stringLength_0(int32_t value)
	{
		___m_stringLength_0 = value;
	}

	inline static int32_t get_offset_of_m_firstChar_1() { return static_cast<int32_t>(offsetof(String_t, ___m_firstChar_1)); }
	inline Il2CppChar get_m_firstChar_1() const { return ___m_firstChar_1; }
	inline Il2CppChar* get_address_of_m_firstChar_1() { return &___m_firstChar_1; }
	inline void set_m_firstChar_1(Il2CppChar value)
	{
		___m_firstChar_1 = value;
	}
};

struct String_t_StaticFields
{
public:
	// System.String System.String::Empty
	String_t* ___Empty_5;

public:
	inline static int32_t get_offset_of_Empty_5() { return static_cast<int32_t>(offsetof(String_t_StaticFields, ___Empty_5)); }
	inline String_t* get_Empty_5() const { return ___Empty_5; }
	inline String_t** get_address_of_Empty_5() { return &___Empty_5; }
	inline void set_Empty_5(String_t* value)
	{
		___Empty_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Empty_5), (void*)value);
	}
};


// System.ValueType
struct ValueType_tDBF999C1B75C48C68621878250DBF6CDBCF51E52  : public RuntimeObject
{
public:

public:
};

// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_tDBF999C1B75C48C68621878250DBF6CDBCF51E52_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_tDBF999C1B75C48C68621878250DBF6CDBCF51E52_marshaled_com
{
};

// Unity.Mathematics.math
struct math_tFA6CF4319F9BE692A3A01857946865C31AEDED0E  : public RuntimeObject
{
public:

public:
};


// Unity.Mathematics.float2/DebuggerProxy
struct DebuggerProxy_t407BFC8E21A86BDBF1C02CB451D0DF70DBFC7D86  : public RuntimeObject
{
public:

public:
};


// Unity.Mathematics.float3/DebuggerProxy
struct DebuggerProxy_t57C699F1846E116DDAF0A5D1D5CF136A3DE498AA  : public RuntimeObject
{
public:

public:
};


// Unity.Mathematics.float4/DebuggerProxy
struct DebuggerProxy_t368A74D6971F51452A7461C738E4BC540678C7AC  : public RuntimeObject
{
public:

public:
};


// Unity.Mathematics.int2/DebuggerProxy
struct DebuggerProxy_tB3E8CFFB2EC112B8E0B663550D06E20FDFE1F559  : public RuntimeObject
{
public:

public:
};


// Unity.Mathematics.uint2/DebuggerProxy
struct DebuggerProxy_t9CAD504CEF7A30BA24D56E70D16F78E18B20D5CB  : public RuntimeObject
{
public:

public:
};


// Unity.Mathematics.uint3/DebuggerProxy
struct DebuggerProxy_tCB285AE3638D7C28AEB223FC39D09610BBA961AF  : public RuntimeObject
{
public:

public:
};


// Unity.Mathematics.uint4/DebuggerProxy
struct DebuggerProxy_t63A74C0E16E809774ABBED1438A4714624A76094  : public RuntimeObject
{
public:

public:
};


// System.Boolean
struct Boolean_t07D1E3F34E4813023D64F584DFF7B34C9D922F37 
{
public:
	// System.Boolean System.Boolean::m_value
	bool ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Boolean_t07D1E3F34E4813023D64F584DFF7B34C9D922F37, ___m_value_0)); }
	inline bool get_m_value_0() const { return ___m_value_0; }
	inline bool* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(bool value)
	{
		___m_value_0 = value;
	}
};

struct Boolean_t07D1E3F34E4813023D64F584DFF7B34C9D922F37_StaticFields
{
public:
	// System.String System.Boolean::TrueString
	String_t* ___TrueString_5;
	// System.String System.Boolean::FalseString
	String_t* ___FalseString_6;

public:
	inline static int32_t get_offset_of_TrueString_5() { return static_cast<int32_t>(offsetof(Boolean_t07D1E3F34E4813023D64F584DFF7B34C9D922F37_StaticFields, ___TrueString_5)); }
	inline String_t* get_TrueString_5() const { return ___TrueString_5; }
	inline String_t** get_address_of_TrueString_5() { return &___TrueString_5; }
	inline void set_TrueString_5(String_t* value)
	{
		___TrueString_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___TrueString_5), (void*)value);
	}

	inline static int32_t get_offset_of_FalseString_6() { return static_cast<int32_t>(offsetof(Boolean_t07D1E3F34E4813023D64F584DFF7B34C9D922F37_StaticFields, ___FalseString_6)); }
	inline String_t* get_FalseString_6() const { return ___FalseString_6; }
	inline String_t** get_address_of_FalseString_6() { return &___FalseString_6; }
	inline void set_FalseString_6(String_t* value)
	{
		___FalseString_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___FalseString_6), (void*)value);
	}
};


// System.Double
struct Double_t42821932CB52DE2057E685D0E1AF3DE5033D2181 
{
public:
	// System.Double System.Double::m_value
	double ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Double_t42821932CB52DE2057E685D0E1AF3DE5033D2181, ___m_value_0)); }
	inline double get_m_value_0() const { return ___m_value_0; }
	inline double* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(double value)
	{
		___m_value_0 = value;
	}
};

struct Double_t42821932CB52DE2057E685D0E1AF3DE5033D2181_StaticFields
{
public:
	// System.Double System.Double::NegativeZero
	double ___NegativeZero_7;

public:
	inline static int32_t get_offset_of_NegativeZero_7() { return static_cast<int32_t>(offsetof(Double_t42821932CB52DE2057E685D0E1AF3DE5033D2181_StaticFields, ___NegativeZero_7)); }
	inline double get_NegativeZero_7() const { return ___NegativeZero_7; }
	inline double* get_address_of_NegativeZero_7() { return &___NegativeZero_7; }
	inline void set_NegativeZero_7(double value)
	{
		___NegativeZero_7 = value;
	}
};


// System.Int32
struct Int32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046 
{
public:
	// System.Int32 System.Int32::m_value
	int32_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Int32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046, ___m_value_0)); }
	inline int32_t get_m_value_0() const { return ___m_value_0; }
	inline int32_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(int32_t value)
	{
		___m_value_0 = value;
	}
};


// System.Single
struct Single_tE07797BA3C98D4CA9B5A19413C19A76688AB899E 
{
public:
	// System.Single System.Single::m_value
	float ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Single_tE07797BA3C98D4CA9B5A19413C19A76688AB899E, ___m_value_0)); }
	inline float get_m_value_0() const { return ___m_value_0; }
	inline float* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(float value)
	{
		___m_value_0 = value;
	}
};


// System.UInt32
struct UInt32_tE60352A06233E4E69DD198BCC67142159F686B15 
{
public:
	// System.UInt32 System.UInt32::m_value
	uint32_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(UInt32_tE60352A06233E4E69DD198BCC67142159F686B15, ___m_value_0)); }
	inline uint32_t get_m_value_0() const { return ___m_value_0; }
	inline uint32_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(uint32_t value)
	{
		___m_value_0 = value;
	}
};


// UnityEngine.Vector2
struct Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 
{
public:
	// System.Single UnityEngine.Vector2::x
	float ___x_0;
	// System.Single UnityEngine.Vector2::y
	float ___y_1;

public:
	inline static int32_t get_offset_of_x_0() { return static_cast<int32_t>(offsetof(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9, ___x_0)); }
	inline float get_x_0() const { return ___x_0; }
	inline float* get_address_of_x_0() { return &___x_0; }
	inline void set_x_0(float value)
	{
		___x_0 = value;
	}

	inline static int32_t get_offset_of_y_1() { return static_cast<int32_t>(offsetof(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9, ___y_1)); }
	inline float get_y_1() const { return ___y_1; }
	inline float* get_address_of_y_1() { return &___y_1; }
	inline void set_y_1(float value)
	{
		___y_1 = value;
	}
};

struct Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9_StaticFields
{
public:
	// UnityEngine.Vector2 UnityEngine.Vector2::zeroVector
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___zeroVector_2;
	// UnityEngine.Vector2 UnityEngine.Vector2::oneVector
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___oneVector_3;
	// UnityEngine.Vector2 UnityEngine.Vector2::upVector
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___upVector_4;
	// UnityEngine.Vector2 UnityEngine.Vector2::downVector
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___downVector_5;
	// UnityEngine.Vector2 UnityEngine.Vector2::leftVector
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___leftVector_6;
	// UnityEngine.Vector2 UnityEngine.Vector2::rightVector
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___rightVector_7;
	// UnityEngine.Vector2 UnityEngine.Vector2::positiveInfinityVector
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___positiveInfinityVector_8;
	// UnityEngine.Vector2 UnityEngine.Vector2::negativeInfinityVector
	Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___negativeInfinityVector_9;

public:
	inline static int32_t get_offset_of_zeroVector_2() { return static_cast<int32_t>(offsetof(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9_StaticFields, ___zeroVector_2)); }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  get_zeroVector_2() const { return ___zeroVector_2; }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * get_address_of_zeroVector_2() { return &___zeroVector_2; }
	inline void set_zeroVector_2(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  value)
	{
		___zeroVector_2 = value;
	}

	inline static int32_t get_offset_of_oneVector_3() { return static_cast<int32_t>(offsetof(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9_StaticFields, ___oneVector_3)); }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  get_oneVector_3() const { return ___oneVector_3; }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * get_address_of_oneVector_3() { return &___oneVector_3; }
	inline void set_oneVector_3(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  value)
	{
		___oneVector_3 = value;
	}

	inline static int32_t get_offset_of_upVector_4() { return static_cast<int32_t>(offsetof(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9_StaticFields, ___upVector_4)); }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  get_upVector_4() const { return ___upVector_4; }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * get_address_of_upVector_4() { return &___upVector_4; }
	inline void set_upVector_4(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  value)
	{
		___upVector_4 = value;
	}

	inline static int32_t get_offset_of_downVector_5() { return static_cast<int32_t>(offsetof(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9_StaticFields, ___downVector_5)); }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  get_downVector_5() const { return ___downVector_5; }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * get_address_of_downVector_5() { return &___downVector_5; }
	inline void set_downVector_5(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  value)
	{
		___downVector_5 = value;
	}

	inline static int32_t get_offset_of_leftVector_6() { return static_cast<int32_t>(offsetof(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9_StaticFields, ___leftVector_6)); }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  get_leftVector_6() const { return ___leftVector_6; }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * get_address_of_leftVector_6() { return &___leftVector_6; }
	inline void set_leftVector_6(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  value)
	{
		___leftVector_6 = value;
	}

	inline static int32_t get_offset_of_rightVector_7() { return static_cast<int32_t>(offsetof(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9_StaticFields, ___rightVector_7)); }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  get_rightVector_7() const { return ___rightVector_7; }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * get_address_of_rightVector_7() { return &___rightVector_7; }
	inline void set_rightVector_7(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  value)
	{
		___rightVector_7 = value;
	}

	inline static int32_t get_offset_of_positiveInfinityVector_8() { return static_cast<int32_t>(offsetof(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9_StaticFields, ___positiveInfinityVector_8)); }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  get_positiveInfinityVector_8() const { return ___positiveInfinityVector_8; }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * get_address_of_positiveInfinityVector_8() { return &___positiveInfinityVector_8; }
	inline void set_positiveInfinityVector_8(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  value)
	{
		___positiveInfinityVector_8 = value;
	}

	inline static int32_t get_offset_of_negativeInfinityVector_9() { return static_cast<int32_t>(offsetof(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9_StaticFields, ___negativeInfinityVector_9)); }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  get_negativeInfinityVector_9() const { return ___negativeInfinityVector_9; }
	inline Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9 * get_address_of_negativeInfinityVector_9() { return &___negativeInfinityVector_9; }
	inline void set_negativeInfinityVector_9(Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  value)
	{
		___negativeInfinityVector_9 = value;
	}
};


// UnityEngine.Vector3
struct Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E 
{
public:
	// System.Single UnityEngine.Vector3::x
	float ___x_2;
	// System.Single UnityEngine.Vector3::y
	float ___y_3;
	// System.Single UnityEngine.Vector3::z
	float ___z_4;

public:
	inline static int32_t get_offset_of_x_2() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E, ___x_2)); }
	inline float get_x_2() const { return ___x_2; }
	inline float* get_address_of_x_2() { return &___x_2; }
	inline void set_x_2(float value)
	{
		___x_2 = value;
	}

	inline static int32_t get_offset_of_y_3() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E, ___y_3)); }
	inline float get_y_3() const { return ___y_3; }
	inline float* get_address_of_y_3() { return &___y_3; }
	inline void set_y_3(float value)
	{
		___y_3 = value;
	}

	inline static int32_t get_offset_of_z_4() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E, ___z_4)); }
	inline float get_z_4() const { return ___z_4; }
	inline float* get_address_of_z_4() { return &___z_4; }
	inline void set_z_4(float value)
	{
		___z_4 = value;
	}
};

struct Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields
{
public:
	// UnityEngine.Vector3 UnityEngine.Vector3::zeroVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___zeroVector_5;
	// UnityEngine.Vector3 UnityEngine.Vector3::oneVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___oneVector_6;
	// UnityEngine.Vector3 UnityEngine.Vector3::upVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___upVector_7;
	// UnityEngine.Vector3 UnityEngine.Vector3::downVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___downVector_8;
	// UnityEngine.Vector3 UnityEngine.Vector3::leftVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___leftVector_9;
	// UnityEngine.Vector3 UnityEngine.Vector3::rightVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___rightVector_10;
	// UnityEngine.Vector3 UnityEngine.Vector3::forwardVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___forwardVector_11;
	// UnityEngine.Vector3 UnityEngine.Vector3::backVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___backVector_12;
	// UnityEngine.Vector3 UnityEngine.Vector3::positiveInfinityVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___positiveInfinityVector_13;
	// UnityEngine.Vector3 UnityEngine.Vector3::negativeInfinityVector
	Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___negativeInfinityVector_14;

public:
	inline static int32_t get_offset_of_zeroVector_5() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___zeroVector_5)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_zeroVector_5() const { return ___zeroVector_5; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_zeroVector_5() { return &___zeroVector_5; }
	inline void set_zeroVector_5(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___zeroVector_5 = value;
	}

	inline static int32_t get_offset_of_oneVector_6() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___oneVector_6)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_oneVector_6() const { return ___oneVector_6; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_oneVector_6() { return &___oneVector_6; }
	inline void set_oneVector_6(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___oneVector_6 = value;
	}

	inline static int32_t get_offset_of_upVector_7() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___upVector_7)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_upVector_7() const { return ___upVector_7; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_upVector_7() { return &___upVector_7; }
	inline void set_upVector_7(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___upVector_7 = value;
	}

	inline static int32_t get_offset_of_downVector_8() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___downVector_8)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_downVector_8() const { return ___downVector_8; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_downVector_8() { return &___downVector_8; }
	inline void set_downVector_8(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___downVector_8 = value;
	}

	inline static int32_t get_offset_of_leftVector_9() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___leftVector_9)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_leftVector_9() const { return ___leftVector_9; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_leftVector_9() { return &___leftVector_9; }
	inline void set_leftVector_9(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___leftVector_9 = value;
	}

	inline static int32_t get_offset_of_rightVector_10() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___rightVector_10)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_rightVector_10() const { return ___rightVector_10; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_rightVector_10() { return &___rightVector_10; }
	inline void set_rightVector_10(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___rightVector_10 = value;
	}

	inline static int32_t get_offset_of_forwardVector_11() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___forwardVector_11)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_forwardVector_11() const { return ___forwardVector_11; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_forwardVector_11() { return &___forwardVector_11; }
	inline void set_forwardVector_11(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___forwardVector_11 = value;
	}

	inline static int32_t get_offset_of_backVector_12() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___backVector_12)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_backVector_12() const { return ___backVector_12; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_backVector_12() { return &___backVector_12; }
	inline void set_backVector_12(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___backVector_12 = value;
	}

	inline static int32_t get_offset_of_positiveInfinityVector_13() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___positiveInfinityVector_13)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_positiveInfinityVector_13() const { return ___positiveInfinityVector_13; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_positiveInfinityVector_13() { return &___positiveInfinityVector_13; }
	inline void set_positiveInfinityVector_13(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___positiveInfinityVector_13 = value;
	}

	inline static int32_t get_offset_of_negativeInfinityVector_14() { return static_cast<int32_t>(offsetof(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E_StaticFields, ___negativeInfinityVector_14)); }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  get_negativeInfinityVector_14() const { return ___negativeInfinityVector_14; }
	inline Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * get_address_of_negativeInfinityVector_14() { return &___negativeInfinityVector_14; }
	inline void set_negativeInfinityVector_14(Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  value)
	{
		___negativeInfinityVector_14 = value;
	}
};


// UnityEngine.Vector4
struct Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7 
{
public:
	// System.Single UnityEngine.Vector4::x
	float ___x_1;
	// System.Single UnityEngine.Vector4::y
	float ___y_2;
	// System.Single UnityEngine.Vector4::z
	float ___z_3;
	// System.Single UnityEngine.Vector4::w
	float ___w_4;

public:
	inline static int32_t get_offset_of_x_1() { return static_cast<int32_t>(offsetof(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7, ___x_1)); }
	inline float get_x_1() const { return ___x_1; }
	inline float* get_address_of_x_1() { return &___x_1; }
	inline void set_x_1(float value)
	{
		___x_1 = value;
	}

	inline static int32_t get_offset_of_y_2() { return static_cast<int32_t>(offsetof(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7, ___y_2)); }
	inline float get_y_2() const { return ___y_2; }
	inline float* get_address_of_y_2() { return &___y_2; }
	inline void set_y_2(float value)
	{
		___y_2 = value;
	}

	inline static int32_t get_offset_of_z_3() { return static_cast<int32_t>(offsetof(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7, ___z_3)); }
	inline float get_z_3() const { return ___z_3; }
	inline float* get_address_of_z_3() { return &___z_3; }
	inline void set_z_3(float value)
	{
		___z_3 = value;
	}

	inline static int32_t get_offset_of_w_4() { return static_cast<int32_t>(offsetof(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7, ___w_4)); }
	inline float get_w_4() const { return ___w_4; }
	inline float* get_address_of_w_4() { return &___w_4; }
	inline void set_w_4(float value)
	{
		___w_4 = value;
	}
};

struct Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7_StaticFields
{
public:
	// UnityEngine.Vector4 UnityEngine.Vector4::zeroVector
	Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  ___zeroVector_5;
	// UnityEngine.Vector4 UnityEngine.Vector4::oneVector
	Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  ___oneVector_6;
	// UnityEngine.Vector4 UnityEngine.Vector4::positiveInfinityVector
	Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  ___positiveInfinityVector_7;
	// UnityEngine.Vector4 UnityEngine.Vector4::negativeInfinityVector
	Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  ___negativeInfinityVector_8;

public:
	inline static int32_t get_offset_of_zeroVector_5() { return static_cast<int32_t>(offsetof(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7_StaticFields, ___zeroVector_5)); }
	inline Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  get_zeroVector_5() const { return ___zeroVector_5; }
	inline Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7 * get_address_of_zeroVector_5() { return &___zeroVector_5; }
	inline void set_zeroVector_5(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  value)
	{
		___zeroVector_5 = value;
	}

	inline static int32_t get_offset_of_oneVector_6() { return static_cast<int32_t>(offsetof(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7_StaticFields, ___oneVector_6)); }
	inline Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  get_oneVector_6() const { return ___oneVector_6; }
	inline Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7 * get_address_of_oneVector_6() { return &___oneVector_6; }
	inline void set_oneVector_6(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  value)
	{
		___oneVector_6 = value;
	}

	inline static int32_t get_offset_of_positiveInfinityVector_7() { return static_cast<int32_t>(offsetof(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7_StaticFields, ___positiveInfinityVector_7)); }
	inline Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  get_positiveInfinityVector_7() const { return ___positiveInfinityVector_7; }
	inline Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7 * get_address_of_positiveInfinityVector_7() { return &___positiveInfinityVector_7; }
	inline void set_positiveInfinityVector_7(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  value)
	{
		___positiveInfinityVector_7 = value;
	}

	inline static int32_t get_offset_of_negativeInfinityVector_8() { return static_cast<int32_t>(offsetof(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7_StaticFields, ___negativeInfinityVector_8)); }
	inline Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  get_negativeInfinityVector_8() const { return ___negativeInfinityVector_8; }
	inline Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7 * get_address_of_negativeInfinityVector_8() { return &___negativeInfinityVector_8; }
	inline void set_negativeInfinityVector_8(Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  value)
	{
		___negativeInfinityVector_8 = value;
	}
};


// System.Void
struct Void_t700C6383A2A510C2CF4DD86DABD5CA9FF70ADAC5 
{
public:
	union
	{
		struct
		{
		};
		uint8_t Void_t700C6383A2A510C2CF4DD86DABD5CA9FF70ADAC5__padding[1];
	};

public:
};


// Unity.Mathematics.float2
struct float2_t11F5F2974404951113DDC4E13EEB6E2456295547 
{
public:
	// System.Single Unity.Mathematics.float2::x
	float ___x_0;
	// System.Single Unity.Mathematics.float2::y
	float ___y_1;

public:
	inline static int32_t get_offset_of_x_0() { return static_cast<int32_t>(offsetof(float2_t11F5F2974404951113DDC4E13EEB6E2456295547, ___x_0)); }
	inline float get_x_0() const { return ___x_0; }
	inline float* get_address_of_x_0() { return &___x_0; }
	inline void set_x_0(float value)
	{
		___x_0 = value;
	}

	inline static int32_t get_offset_of_y_1() { return static_cast<int32_t>(offsetof(float2_t11F5F2974404951113DDC4E13EEB6E2456295547, ___y_1)); }
	inline float get_y_1() const { return ___y_1; }
	inline float* get_address_of_y_1() { return &___y_1; }
	inline void set_y_1(float value)
	{
		___y_1 = value;
	}
};

struct float2_t11F5F2974404951113DDC4E13EEB6E2456295547_StaticFields
{
public:
	// Unity.Mathematics.float2 Unity.Mathematics.float2::zero
	float2_t11F5F2974404951113DDC4E13EEB6E2456295547  ___zero_2;

public:
	inline static int32_t get_offset_of_zero_2() { return static_cast<int32_t>(offsetof(float2_t11F5F2974404951113DDC4E13EEB6E2456295547_StaticFields, ___zero_2)); }
	inline float2_t11F5F2974404951113DDC4E13EEB6E2456295547  get_zero_2() const { return ___zero_2; }
	inline float2_t11F5F2974404951113DDC4E13EEB6E2456295547 * get_address_of_zero_2() { return &___zero_2; }
	inline void set_zero_2(float2_t11F5F2974404951113DDC4E13EEB6E2456295547  value)
	{
		___zero_2 = value;
	}
};


// Unity.Mathematics.float3
struct float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D 
{
public:
	// System.Single Unity.Mathematics.float3::x
	float ___x_0;
	// System.Single Unity.Mathematics.float3::y
	float ___y_1;
	// System.Single Unity.Mathematics.float3::z
	float ___z_2;

public:
	inline static int32_t get_offset_of_x_0() { return static_cast<int32_t>(offsetof(float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D, ___x_0)); }
	inline float get_x_0() const { return ___x_0; }
	inline float* get_address_of_x_0() { return &___x_0; }
	inline void set_x_0(float value)
	{
		___x_0 = value;
	}

	inline static int32_t get_offset_of_y_1() { return static_cast<int32_t>(offsetof(float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D, ___y_1)); }
	inline float get_y_1() const { return ___y_1; }
	inline float* get_address_of_y_1() { return &___y_1; }
	inline void set_y_1(float value)
	{
		___y_1 = value;
	}

	inline static int32_t get_offset_of_z_2() { return static_cast<int32_t>(offsetof(float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D, ___z_2)); }
	inline float get_z_2() const { return ___z_2; }
	inline float* get_address_of_z_2() { return &___z_2; }
	inline void set_z_2(float value)
	{
		___z_2 = value;
	}
};

struct float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D_StaticFields
{
public:
	// Unity.Mathematics.float3 Unity.Mathematics.float3::zero
	float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___zero_3;

public:
	inline static int32_t get_offset_of_zero_3() { return static_cast<int32_t>(offsetof(float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D_StaticFields, ___zero_3)); }
	inline float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  get_zero_3() const { return ___zero_3; }
	inline float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * get_address_of_zero_3() { return &___zero_3; }
	inline void set_zero_3(float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  value)
	{
		___zero_3 = value;
	}
};


// Unity.Mathematics.float4
struct float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 
{
public:
	// System.Single Unity.Mathematics.float4::x
	float ___x_0;
	// System.Single Unity.Mathematics.float4::y
	float ___y_1;
	// System.Single Unity.Mathematics.float4::z
	float ___z_2;
	// System.Single Unity.Mathematics.float4::w
	float ___w_3;

public:
	inline static int32_t get_offset_of_x_0() { return static_cast<int32_t>(offsetof(float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883, ___x_0)); }
	inline float get_x_0() const { return ___x_0; }
	inline float* get_address_of_x_0() { return &___x_0; }
	inline void set_x_0(float value)
	{
		___x_0 = value;
	}

	inline static int32_t get_offset_of_y_1() { return static_cast<int32_t>(offsetof(float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883, ___y_1)); }
	inline float get_y_1() const { return ___y_1; }
	inline float* get_address_of_y_1() { return &___y_1; }
	inline void set_y_1(float value)
	{
		___y_1 = value;
	}

	inline static int32_t get_offset_of_z_2() { return static_cast<int32_t>(offsetof(float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883, ___z_2)); }
	inline float get_z_2() const { return ___z_2; }
	inline float* get_address_of_z_2() { return &___z_2; }
	inline void set_z_2(float value)
	{
		___z_2 = value;
	}

	inline static int32_t get_offset_of_w_3() { return static_cast<int32_t>(offsetof(float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883, ___w_3)); }
	inline float get_w_3() const { return ___w_3; }
	inline float* get_address_of_w_3() { return &___w_3; }
	inline void set_w_3(float value)
	{
		___w_3 = value;
	}
};

struct float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883_StaticFields
{
public:
	// Unity.Mathematics.float4 Unity.Mathematics.float4::zero
	float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  ___zero_4;

public:
	inline static int32_t get_offset_of_zero_4() { return static_cast<int32_t>(offsetof(float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883_StaticFields, ___zero_4)); }
	inline float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  get_zero_4() const { return ___zero_4; }
	inline float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 * get_address_of_zero_4() { return &___zero_4; }
	inline void set_zero_4(float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  value)
	{
		___zero_4 = value;
	}
};


// Unity.Mathematics.int2
struct int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558 
{
public:
	// System.Int32 Unity.Mathematics.int2::x
	int32_t ___x_0;
	// System.Int32 Unity.Mathematics.int2::y
	int32_t ___y_1;

public:
	inline static int32_t get_offset_of_x_0() { return static_cast<int32_t>(offsetof(int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558, ___x_0)); }
	inline int32_t get_x_0() const { return ___x_0; }
	inline int32_t* get_address_of_x_0() { return &___x_0; }
	inline void set_x_0(int32_t value)
	{
		___x_0 = value;
	}

	inline static int32_t get_offset_of_y_1() { return static_cast<int32_t>(offsetof(int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558, ___y_1)); }
	inline int32_t get_y_1() const { return ___y_1; }
	inline int32_t* get_address_of_y_1() { return &___y_1; }
	inline void set_y_1(int32_t value)
	{
		___y_1 = value;
	}
};

struct int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558_StaticFields
{
public:
	// Unity.Mathematics.int2 Unity.Mathematics.int2::zero
	int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558  ___zero_2;

public:
	inline static int32_t get_offset_of_zero_2() { return static_cast<int32_t>(offsetof(int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558_StaticFields, ___zero_2)); }
	inline int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558  get_zero_2() const { return ___zero_2; }
	inline int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558 * get_address_of_zero_2() { return &___zero_2; }
	inline void set_zero_2(int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558  value)
	{
		___zero_2 = value;
	}
};


// Unity.Mathematics.uint2
struct uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A 
{
public:
	// System.UInt32 Unity.Mathematics.uint2::x
	uint32_t ___x_0;
	// System.UInt32 Unity.Mathematics.uint2::y
	uint32_t ___y_1;

public:
	inline static int32_t get_offset_of_x_0() { return static_cast<int32_t>(offsetof(uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A, ___x_0)); }
	inline uint32_t get_x_0() const { return ___x_0; }
	inline uint32_t* get_address_of_x_0() { return &___x_0; }
	inline void set_x_0(uint32_t value)
	{
		___x_0 = value;
	}

	inline static int32_t get_offset_of_y_1() { return static_cast<int32_t>(offsetof(uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A, ___y_1)); }
	inline uint32_t get_y_1() const { return ___y_1; }
	inline uint32_t* get_address_of_y_1() { return &___y_1; }
	inline void set_y_1(uint32_t value)
	{
		___y_1 = value;
	}
};


// Unity.Mathematics.uint3
struct uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE 
{
public:
	// System.UInt32 Unity.Mathematics.uint3::x
	uint32_t ___x_0;
	// System.UInt32 Unity.Mathematics.uint3::y
	uint32_t ___y_1;
	// System.UInt32 Unity.Mathematics.uint3::z
	uint32_t ___z_2;

public:
	inline static int32_t get_offset_of_x_0() { return static_cast<int32_t>(offsetof(uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE, ___x_0)); }
	inline uint32_t get_x_0() const { return ___x_0; }
	inline uint32_t* get_address_of_x_0() { return &___x_0; }
	inline void set_x_0(uint32_t value)
	{
		___x_0 = value;
	}

	inline static int32_t get_offset_of_y_1() { return static_cast<int32_t>(offsetof(uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE, ___y_1)); }
	inline uint32_t get_y_1() const { return ___y_1; }
	inline uint32_t* get_address_of_y_1() { return &___y_1; }
	inline void set_y_1(uint32_t value)
	{
		___y_1 = value;
	}

	inline static int32_t get_offset_of_z_2() { return static_cast<int32_t>(offsetof(uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE, ___z_2)); }
	inline uint32_t get_z_2() const { return ___z_2; }
	inline uint32_t* get_address_of_z_2() { return &___z_2; }
	inline void set_z_2(uint32_t value)
	{
		___z_2 = value;
	}
};


// Unity.Mathematics.uint4
struct uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92 
{
public:
	// System.UInt32 Unity.Mathematics.uint4::x
	uint32_t ___x_0;
	// System.UInt32 Unity.Mathematics.uint4::y
	uint32_t ___y_1;
	// System.UInt32 Unity.Mathematics.uint4::z
	uint32_t ___z_2;
	// System.UInt32 Unity.Mathematics.uint4::w
	uint32_t ___w_3;

public:
	inline static int32_t get_offset_of_x_0() { return static_cast<int32_t>(offsetof(uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92, ___x_0)); }
	inline uint32_t get_x_0() const { return ___x_0; }
	inline uint32_t* get_address_of_x_0() { return &___x_0; }
	inline void set_x_0(uint32_t value)
	{
		___x_0 = value;
	}

	inline static int32_t get_offset_of_y_1() { return static_cast<int32_t>(offsetof(uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92, ___y_1)); }
	inline uint32_t get_y_1() const { return ___y_1; }
	inline uint32_t* get_address_of_y_1() { return &___y_1; }
	inline void set_y_1(uint32_t value)
	{
		___y_1 = value;
	}

	inline static int32_t get_offset_of_z_2() { return static_cast<int32_t>(offsetof(uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92, ___z_2)); }
	inline uint32_t get_z_2() const { return ___z_2; }
	inline uint32_t* get_address_of_z_2() { return &___z_2; }
	inline void set_z_2(uint32_t value)
	{
		___z_2 = value;
	}

	inline static int32_t get_offset_of_w_3() { return static_cast<int32_t>(offsetof(uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92, ___w_3)); }
	inline uint32_t get_w_3() const { return ___w_3; }
	inline uint32_t* get_address_of_w_3() { return &___w_3; }
	inline void set_w_3(uint32_t value)
	{
		___w_3 = value;
	}
};


// Unity.Mathematics.math/IntFloatUnion
struct IntFloatUnion_t3B42C127ECCA706E64B5C2B9EE370A632FC83548 
{
public:
	union
	{
		#pragma pack(push, tp, 1)
		struct
		{
			// System.Int32 Unity.Mathematics.math/IntFloatUnion::intValue
			int32_t ___intValue_0;
		};
		#pragma pack(pop, tp)
		struct
		{
			int32_t ___intValue_0_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			// System.Single Unity.Mathematics.math/IntFloatUnion::floatValue
			float ___floatValue_1;
		};
		#pragma pack(pop, tp)
		struct
		{
			float ___floatValue_1_forAlignmentOnly;
		};
	};

public:
	inline static int32_t get_offset_of_intValue_0() { return static_cast<int32_t>(offsetof(IntFloatUnion_t3B42C127ECCA706E64B5C2B9EE370A632FC83548, ___intValue_0)); }
	inline int32_t get_intValue_0() const { return ___intValue_0; }
	inline int32_t* get_address_of_intValue_0() { return &___intValue_0; }
	inline void set_intValue_0(int32_t value)
	{
		___intValue_0 = value;
	}

	inline static int32_t get_offset_of_floatValue_1() { return static_cast<int32_t>(offsetof(IntFloatUnion_t3B42C127ECCA706E64B5C2B9EE370A632FC83548, ___floatValue_1)); }
	inline float get_floatValue_1() const { return ___floatValue_1; }
	inline float* get_address_of_floatValue_1() { return &___floatValue_1; }
	inline void set_floatValue_1(float value)
	{
		___floatValue_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// System.Object[]
struct ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) RuntimeObject * m_Items[1];

public:
	inline RuntimeObject * GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline RuntimeObject ** GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, RuntimeObject * value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
	inline RuntimeObject * GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline RuntimeObject ** GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, RuntimeObject * value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
};



// System.Void Unity.Mathematics.float2::.ctor(System.Single,System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void float2__ctor_mA85C140C72CD3A1E8F287AEC7FF12A35C85C819C_inline (float2_t11F5F2974404951113DDC4E13EEB6E2456295547 * __this, float ___x0, float ___y1, const RuntimeMethod* method);
// Unity.Mathematics.float2 Unity.Mathematics.float2::get_xy()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float2_t11F5F2974404951113DDC4E13EEB6E2456295547  float2_get_xy_m70AC8FFD749BA962E2C2822CCD4B731098858DCB_inline (float2_t11F5F2974404951113DDC4E13EEB6E2456295547 * __this, const RuntimeMethod* method);
// System.Boolean Unity.Mathematics.float2::Equals(Unity.Mathematics.float2)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool float2_Equals_m406569E20C262C01141F2977EB04430121AD5AFE_inline (float2_t11F5F2974404951113DDC4E13EEB6E2456295547 * __this, float2_t11F5F2974404951113DDC4E13EEB6E2456295547  ___rhs0, const RuntimeMethod* method);
// System.Boolean Unity.Mathematics.float2::Equals(System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool float2_Equals_mB13D7F862604D5C8577B46794CB4F4741917D1BC (float2_t11F5F2974404951113DDC4E13EEB6E2456295547 * __this, RuntimeObject * ___o0, const RuntimeMethod* method);
// System.UInt32 Unity.Mathematics.math::hash(Unity.Mathematics.float2)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint32_t math_hash_m0214B7050F1399AD283DFF8CB115A65E0B95E1BA_inline (float2_t11F5F2974404951113DDC4E13EEB6E2456295547  ___v0, const RuntimeMethod* method);
// System.Int32 Unity.Mathematics.float2::GetHashCode()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t float2_GetHashCode_mAB652A4865F38E1A58F754B6B8E17F24617B2C23_inline (float2_t11F5F2974404951113DDC4E13EEB6E2456295547 * __this, const RuntimeMethod* method);
// System.String System.String::Format(System.String,System.Object,System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* String_Format_m8D1CB0410C35E052A53AE957C914C841E54BAB66 (String_t* ___format0, RuntimeObject * ___arg01, RuntimeObject * ___arg12, const RuntimeMethod* method);
// System.String Unity.Mathematics.float2::ToString()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR String_t* float2_ToString_m88AFB1A56BC992680CB633C9A73EBEFD3369F8B1_inline (float2_t11F5F2974404951113DDC4E13EEB6E2456295547 * __this, const RuntimeMethod* method);
// System.String System.Single::ToString(System.String,System.IFormatProvider)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* Single_ToString_m7631D332703B4197EAA7DC0BA067CE7E16334D8B (float* __this, String_t* ___format0, RuntimeObject* ___provider1, const RuntimeMethod* method);
// System.String Unity.Mathematics.float2::ToString(System.String,System.IFormatProvider)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR String_t* float2_ToString_m663E65C99B64AD3B4CBEC51AC457685D0A0369B6_inline (float2_t11F5F2974404951113DDC4E13EEB6E2456295547 * __this, String_t* ___format0, RuntimeObject* ___formatProvider1, const RuntimeMethod* method);
// System.Void Unity.Mathematics.float3::.ctor(System.Single,System.Single,System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void float3__ctor_m853853CCAF2BC58F66EE07DB9338C1644698D483_inline (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * __this, float ___x0, float ___y1, float ___z2, const RuntimeMethod* method);
// System.Void Unity.Mathematics.float3::.ctor(Unity.Mathematics.float2,System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void float3__ctor_mB8B1FC017A7671C0F19CBF32B243871B770F219B_inline (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * __this, float2_t11F5F2974404951113DDC4E13EEB6E2456295547  ___xy0, float ___z1, const RuntimeMethod* method);
// System.Void Unity.Mathematics.float3::.ctor(System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void float3__ctor_mD066F7C313EE72EC068E4CD9E6475CD0D148A4B4_inline (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * __this, float ___v0, const RuntimeMethod* method);
// Unity.Mathematics.float3 Unity.Mathematics.float3::get_xzy()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  float3_get_xzy_mE4543537819B8525168D59076E3A19F95728DC77_inline (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * __this, const RuntimeMethod* method);
// Unity.Mathematics.float3 Unity.Mathematics.float3::get_yzx()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  float3_get_yzx_mAE305D9ABE33A40967A3BEECAF5E8CA1E66B2D6B_inline (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * __this, const RuntimeMethod* method);
// Unity.Mathematics.float2 Unity.Mathematics.float3::get_xz()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float2_t11F5F2974404951113DDC4E13EEB6E2456295547  float3_get_xz_m9955DC8BBF06D0C80113321EB39C8946100B3693_inline (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * __this, const RuntimeMethod* method);
// System.Boolean Unity.Mathematics.float3::Equals(Unity.Mathematics.float3)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool float3_Equals_m082B461D20DCFD179A2A50F68737C51794D30F72_inline (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * __this, float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___rhs0, const RuntimeMethod* method);
// System.Boolean Unity.Mathematics.float3::Equals(System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool float3_Equals_mF2580FD87C3D31BDF4C4EF55489BE5F9D4A02E10 (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * __this, RuntimeObject * ___o0, const RuntimeMethod* method);
// System.UInt32 Unity.Mathematics.math::hash(Unity.Mathematics.float3)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint32_t math_hash_m7B43A24382293202DAB3DF5C3953BE904664205B_inline (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___v0, const RuntimeMethod* method);
// System.Int32 Unity.Mathematics.float3::GetHashCode()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t float3_GetHashCode_m9D7B789ABF601895DE5127F10AB318E5FB34FF33_inline (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * __this, const RuntimeMethod* method);
// System.String System.String::Format(System.String,System.Object,System.Object,System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* String_Format_m039737CCD992C5BFC8D16DFD681F5E8786E87FA6 (String_t* ___format0, RuntimeObject * ___arg01, RuntimeObject * ___arg12, RuntimeObject * ___arg23, const RuntimeMethod* method);
// System.String Unity.Mathematics.float3::ToString()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR String_t* float3_ToString_m1826B8701C72517A17CEDB7F7E4C804400A45F92_inline (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * __this, const RuntimeMethod* method);
// System.String Unity.Mathematics.float3::ToString(System.String,System.IFormatProvider)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR String_t* float3_ToString_m341757749BF9ED59EC04C13798F9402B220E86C6_inline (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * __this, String_t* ___format0, RuntimeObject* ___formatProvider1, const RuntimeMethod* method);
// System.Void UnityEngine.Vector3::.ctor(System.Single,System.Single,System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * __this, float ___x0, float ___y1, float ___z2, const RuntimeMethod* method);
// System.Void Unity.Mathematics.float4::.ctor(System.Single,System.Single,System.Single,System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void float4__ctor_m289038BF46A44D4F1F0A897417C1F9C96B96F349_inline (float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 * __this, float ___x0, float ___y1, float ___z2, float ___w3, const RuntimeMethod* method);
// Unity.Mathematics.float3 Unity.Mathematics.float4::get_xyz()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  float4_get_xyz_mC891E5A9ADFCD1137A3E1D0DF70A60A10290E4D2_inline (float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 * __this, const RuntimeMethod* method);
// System.Void Unity.Mathematics.float4::set_xyz(Unity.Mathematics.float3)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void float4_set_xyz_m835174016809C625D7564655F4E2CCB95A024C45_inline (float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 * __this, float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___value0, const RuntimeMethod* method);
// System.Boolean Unity.Mathematics.float4::Equals(Unity.Mathematics.float4)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool float4_Equals_mFDF5FFF5DBF9FCD0FFD92C00CC3A0E6A22676C76_inline (float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 * __this, float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  ___rhs0, const RuntimeMethod* method);
// System.Boolean Unity.Mathematics.float4::Equals(System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool float4_Equals_m481BDCD35ED8247881583FCBA9C66794A8BC008F (float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 * __this, RuntimeObject * ___o0, const RuntimeMethod* method);
// System.UInt32 Unity.Mathematics.math::hash(Unity.Mathematics.float4)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint32_t math_hash_m53A15DB25196562BA8CF64481E3F9B4995AE75F7_inline (float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  ___v0, const RuntimeMethod* method);
// System.Int32 Unity.Mathematics.float4::GetHashCode()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t float4_GetHashCode_m7138A6A1ED3F8142D24A7D0F53264FD3D3C2DA97_inline (float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 * __this, const RuntimeMethod* method);
// System.String System.String::Format(System.String,System.Object[])
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* String_Format_mCED6767EA5FEE6F15ABCD5B4F9150D1284C2795B (String_t* ___format0, ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* ___args1, const RuntimeMethod* method);
// System.String Unity.Mathematics.float4::ToString()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR String_t* float4_ToString_mEF96A2289BB136EEE679B8F90D771C58DB031EB7_inline (float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 * __this, const RuntimeMethod* method);
// System.String Unity.Mathematics.float4::ToString(System.String,System.IFormatProvider)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR String_t* float4_ToString_mF157EB1EA5B178949D39582EEB7AD960797E3CCF_inline (float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 * __this, String_t* ___format0, RuntimeObject* ___formatProvider1, const RuntimeMethod* method);
// System.Void UnityEngine.Vector4::.ctor(System.Single,System.Single,System.Single,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Vector4__ctor_mCAB598A37C4D5E80282277E828B8A3EAD936D3B2 (Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7 * __this, float ___x0, float ___y1, float ___z2, float ___w3, const RuntimeMethod* method);
// System.Void Unity.Mathematics.int2::.ctor(System.Int32,System.Int32)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void int2__ctor_mF2809193E310D356095F5534AF632CEB504845D1_inline (int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558 * __this, int32_t ___x0, int32_t ___y1, const RuntimeMethod* method);
// System.Boolean Unity.Mathematics.int2::Equals(Unity.Mathematics.int2)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool int2_Equals_m24E4968D84F6232AB37F57692C3F8CBC03036668_inline (int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558 * __this, int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558  ___rhs0, const RuntimeMethod* method);
// System.Boolean Unity.Mathematics.int2::Equals(System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool int2_Equals_m66230D0C353BB0482EA0F13904ABC3766BA7FF53 (int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558 * __this, RuntimeObject * ___o0, const RuntimeMethod* method);
// System.UInt32 Unity.Mathematics.math::hash(Unity.Mathematics.int2)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint32_t math_hash_m23BB2E45EEDF0493DF3AD90AC3837C34A70FE471_inline (int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558  ___v0, const RuntimeMethod* method);
// System.Int32 Unity.Mathematics.int2::GetHashCode()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t int2_GetHashCode_m8F2D5944D3AEC3ADCB056ADD4B03DF6038B5C7B0_inline (int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558 * __this, const RuntimeMethod* method);
// System.String Unity.Mathematics.int2::ToString()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR String_t* int2_ToString_m04651E132A626D5DDED8BCF33FB65768602FB655_inline (int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558 * __this, const RuntimeMethod* method);
// System.String System.Int32::ToString(System.String,System.IFormatProvider)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* Int32_ToString_m246774E1922012AE787EB97743F42CB798B70CD8 (int32_t* __this, String_t* ___format0, RuntimeObject* ___provider1, const RuntimeMethod* method);
// System.String Unity.Mathematics.int2::ToString(System.String,System.IFormatProvider)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR String_t* int2_ToString_mBE1C05766EA0EE72C974AB8D78FBB0FFE747E1AC_inline (int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558 * __this, String_t* ___format0, RuntimeObject* ___formatProvider1, const RuntimeMethod* method);
// Unity.Mathematics.uint2 Unity.Mathematics.math::asuint(Unity.Mathematics.float2)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  math_asuint_mADD3FB6B29BD406CC3254B1DE3776D5B92F7B161_inline (float2_t11F5F2974404951113DDC4E13EEB6E2456295547  ___x0, const RuntimeMethod* method);
// Unity.Mathematics.uint2 Unity.Mathematics.math::uint2(System.UInt32,System.UInt32)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  math_uint2_mF2E830E0F3E660D4E640F5EF5D5A3FCA75378D01_inline (uint32_t ___x0, uint32_t ___y1, const RuntimeMethod* method);
// Unity.Mathematics.uint2 Unity.Mathematics.uint2::op_Multiply(Unity.Mathematics.uint2,Unity.Mathematics.uint2)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  uint2_op_Multiply_m7636391131B0EDC9918A5772AD85C68109F2235F_inline (uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  ___lhs0, uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  ___rhs1, const RuntimeMethod* method);
// System.UInt32 Unity.Mathematics.math::csum(Unity.Mathematics.uint2)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint32_t math_csum_m27D50739B96EE2F2DEA2EABD207F2B827F87E232_inline (uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  ___x0, const RuntimeMethod* method);
// Unity.Mathematics.uint3 Unity.Mathematics.math::asuint(Unity.Mathematics.float3)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  math_asuint_m391E0BC4333E70109D0AC31DBAB8693A082791A7_inline (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___x0, const RuntimeMethod* method);
// Unity.Mathematics.uint3 Unity.Mathematics.math::uint3(System.UInt32,System.UInt32,System.UInt32)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  math_uint3_mCA0FF72ACE1A3319B3E19C41638C710CCFC56A68_inline (uint32_t ___x0, uint32_t ___y1, uint32_t ___z2, const RuntimeMethod* method);
// Unity.Mathematics.uint3 Unity.Mathematics.uint3::op_Multiply(Unity.Mathematics.uint3,Unity.Mathematics.uint3)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  uint3_op_Multiply_mBF3B660B4057B2D4ACD4B6B3DDDC4E747A6C8877_inline (uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  ___lhs0, uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  ___rhs1, const RuntimeMethod* method);
// System.UInt32 Unity.Mathematics.math::csum(Unity.Mathematics.uint3)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint32_t math_csum_m60444A45FBA529E9ED20646FA61559F4B53D96ED_inline (uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  ___x0, const RuntimeMethod* method);
// Unity.Mathematics.uint4 Unity.Mathematics.math::asuint(Unity.Mathematics.float4)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  math_asuint_m3D2A8007FE91051287F5761C654CD4E7F4B669CB_inline (float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  ___x0, const RuntimeMethod* method);
// Unity.Mathematics.uint4 Unity.Mathematics.math::uint4(System.UInt32,System.UInt32,System.UInt32,System.UInt32)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  math_uint4_m2AAC3E9468B39F889CA506EF27BAD9E428C6E15D_inline (uint32_t ___x0, uint32_t ___y1, uint32_t ___z2, uint32_t ___w3, const RuntimeMethod* method);
// Unity.Mathematics.uint4 Unity.Mathematics.uint4::op_Multiply(Unity.Mathematics.uint4,Unity.Mathematics.uint4)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  uint4_op_Multiply_m27352F838EE80439EE98A136D8D246AF5E9EF681_inline (uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  ___lhs0, uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  ___rhs1, const RuntimeMethod* method);
// System.UInt32 Unity.Mathematics.math::csum(Unity.Mathematics.uint4)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint32_t math_csum_m6A08B2FBD9E51F2CC9984B12285CEB4B188B2A35_inline (uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  ___x0, const RuntimeMethod* method);
// Unity.Mathematics.uint2 Unity.Mathematics.math::asuint(Unity.Mathematics.int2)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  math_asuint_mA2C4FDC7E23CDB70403D11B606D2ED33B4A6551D_inline (int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558  ___x0, const RuntimeMethod* method);
// System.Int32 Unity.Mathematics.math::asint(System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t math_asint_mA58A5DFF25FB3AF5A3D8705D6BA70B916A2E41E7_inline (float ___x0, const RuntimeMethod* method);
// System.UInt32 Unity.Mathematics.math::asuint(System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint32_t math_asuint_m5C798CD94D48BA6240ECBB5EFDAD2D565ECDDEE6_inline (float ___x0, const RuntimeMethod* method);
// System.Single Unity.Mathematics.math::asfloat(System.Int32)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_asfloat_m0F490C819C7F72ECFEA9B6079E690C72ED5028ED_inline (int32_t ___x0, const RuntimeMethod* method);
// System.Single Unity.Mathematics.math::asfloat(System.UInt32)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_asfloat_m10F84A2A94E30A6EA7D23F9FCDBCDDB709328684_inline (uint32_t ___x0, const RuntimeMethod* method);
// Unity.Mathematics.float2 Unity.Mathematics.math::float2(System.Single,System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float2_t11F5F2974404951113DDC4E13EEB6E2456295547  math_float2_mB67FFC2F70C70410B564621543211FA6172F549F_inline (float ___x0, float ___y1, const RuntimeMethod* method);
// System.Boolean System.Single::IsNaN(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Single_IsNaN_m458FF076EF1944D4D888A585F7C6C49DA4730599 (float ___f0, const RuntimeMethod* method);
// System.Single Unity.Mathematics.math::min(System.Single,System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_min_m39054317B5C9E28B04360370E05713632A3B544F_inline (float ___x0, float ___y1, const RuntimeMethod* method);
// System.Single Unity.Mathematics.math::max(System.Single,System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_max_m2D9E0840A13662E878067A28926E1A85323E7E25_inline (float ___x0, float ___y1, const RuntimeMethod* method);
// Unity.Mathematics.uint2 Unity.Mathematics.uint2::op_BitwiseAnd(Unity.Mathematics.uint2,System.UInt32)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  uint2_op_BitwiseAnd_mB0E2C747CA4063432C69AFBC68BB4EC28B2815C2_inline (uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  ___lhs0, uint32_t ___rhs1, const RuntimeMethod* method);
// Unity.Mathematics.float2 Unity.Mathematics.math::asfloat(Unity.Mathematics.uint2)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float2_t11F5F2974404951113DDC4E13EEB6E2456295547  math_asfloat_m56FF653BF60DF76D1E13AF495440DF5EB57CFA6E_inline (uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  ___x0, const RuntimeMethod* method);
// System.Single Unity.Mathematics.math::sqrt(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float math_sqrt_m4FD392CA865BFABB6645F3AE365F5FBA2F2F40F6 (float ___x0, const RuntimeMethod* method);
// System.Single Unity.Mathematics.math::dot(Unity.Mathematics.float2,Unity.Mathematics.float2)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_dot_mF3A96DE35F8C3264D3FD4F70B4090DB3261B168B_inline (float2_t11F5F2974404951113DDC4E13EEB6E2456295547  ___x0, float2_t11F5F2974404951113DDC4E13EEB6E2456295547  ___y1, const RuntimeMethod* method);
// System.Single Unity.Mathematics.math::rsqrt(System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_rsqrt_m4A5597C29F30C68AF6855620522D41CB739F9F80_inline (float ___x0, const RuntimeMethod* method);
// Unity.Mathematics.float2 Unity.Mathematics.float2::op_Multiply(System.Single,Unity.Mathematics.float2)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float2_t11F5F2974404951113DDC4E13EEB6E2456295547  float2_op_Multiply_m07CB14BD054267E48BF40992AD4A341FAF0A21ED_inline (float ___lhs0, float2_t11F5F2974404951113DDC4E13EEB6E2456295547  ___rhs1, const RuntimeMethod* method);
// System.Single Unity.Mathematics.math::dot(Unity.Mathematics.float3,Unity.Mathematics.float3)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_dot_m04AB38B7D16991336C8B141B3D59E7C4C6D9D3ED_inline (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___x0, float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___y1, const RuntimeMethod* method);
// Unity.Mathematics.float3 Unity.Mathematics.float3::op_Multiply(System.Single,Unity.Mathematics.float3)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  float3_op_Multiply_m66E0DDABA7E629CCCEFC6407B038D6FD42E1A1B0_inline (float ___lhs0, float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___rhs1, const RuntimeMethod* method);
// Unity.Mathematics.float3 Unity.Mathematics.float3::op_Multiply(Unity.Mathematics.float3,Unity.Mathematics.float3)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  float3_op_Multiply_m296B37BB82979715ED4A076EBE7BE72F83C56CD7_inline (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___lhs0, float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___rhs1, const RuntimeMethod* method);
// Unity.Mathematics.float3 Unity.Mathematics.float3::op_Subtraction(Unity.Mathematics.float3,Unity.Mathematics.float3)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  float3_op_Subtraction_mB3250D4D18B21370A6FEA3B2B527CFA7B6DE439D_inline (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___lhs0, float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___rhs1, const RuntimeMethod* method);
// System.Void Unity.Mathematics.uint2::.ctor(System.UInt32,System.UInt32)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void uint2__ctor_m73EC9E1A714B67A555B594981E100729750DCE96_inline (uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A * __this, uint32_t ___x0, uint32_t ___y1, const RuntimeMethod* method);
// System.Void Unity.Mathematics.uint3::.ctor(System.UInt32,System.UInt32,System.UInt32)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void uint3__ctor_m3B61A70D37EB10BE4F26625A9BBB52466AE9ECE3_inline (uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE * __this, uint32_t ___x0, uint32_t ___y1, uint32_t ___z2, const RuntimeMethod* method);
// System.Void Unity.Mathematics.uint4::.ctor(System.UInt32,System.UInt32,System.UInt32,System.UInt32)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void uint4__ctor_m542805076C6C9E3A87DC3242D32E60C4347439E8_inline (uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92 * __this, uint32_t ___x0, uint32_t ___y1, uint32_t ___z2, uint32_t ___w3, const RuntimeMethod* method);
// System.Boolean Unity.Mathematics.uint2::Equals(Unity.Mathematics.uint2)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool uint2_Equals_m4B2B64A008B39D7386AE19DEDA4AEC83E1C37B36_inline (uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A * __this, uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  ___rhs0, const RuntimeMethod* method);
// System.Boolean Unity.Mathematics.uint2::Equals(System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool uint2_Equals_m25297222C97C233F3D316E747165E47F731FBCB6 (uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A * __this, RuntimeObject * ___o0, const RuntimeMethod* method);
// System.UInt32 Unity.Mathematics.math::hash(Unity.Mathematics.uint2)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint32_t math_hash_m0A5EC4565F35FF66EB626E43BFE5C30853603652_inline (uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  ___v0, const RuntimeMethod* method);
// System.Int32 Unity.Mathematics.uint2::GetHashCode()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t uint2_GetHashCode_m5D6FED071659D7B1E286571116AA379996E21540_inline (uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A * __this, const RuntimeMethod* method);
// System.String Unity.Mathematics.uint2::ToString()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR String_t* uint2_ToString_mCAEFE74E44CB92672B2B6AFE042C6796416F18D7_inline (uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A * __this, const RuntimeMethod* method);
// System.String System.UInt32::ToString(System.String,System.IFormatProvider)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* UInt32_ToString_mAF0A46E9EC70EA43A02EBE522FF287E20DEE691B (uint32_t* __this, String_t* ___format0, RuntimeObject* ___provider1, const RuntimeMethod* method);
// System.String Unity.Mathematics.uint2::ToString(System.String,System.IFormatProvider)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR String_t* uint2_ToString_mF753477C3131F00ABFE352F02919CC57CB6F8F88_inline (uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A * __this, String_t* ___format0, RuntimeObject* ___formatProvider1, const RuntimeMethod* method);
// System.Boolean Unity.Mathematics.uint3::Equals(Unity.Mathematics.uint3)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool uint3_Equals_m4123D7A3796D0EB4F1D33541453971082875FAC5_inline (uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE * __this, uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  ___rhs0, const RuntimeMethod* method);
// System.Boolean Unity.Mathematics.uint3::Equals(System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool uint3_Equals_m6EEB50DA7949D150AE0E87B037BDFE252D5617CF (uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE * __this, RuntimeObject * ___o0, const RuntimeMethod* method);
// System.UInt32 Unity.Mathematics.math::hash(Unity.Mathematics.uint3)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint32_t math_hash_m8C856AA564098835DF61AF436DD3D70B51C34C56_inline (uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  ___v0, const RuntimeMethod* method);
// System.Int32 Unity.Mathematics.uint3::GetHashCode()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t uint3_GetHashCode_mFAA802DA823258302D91BA287D4C924197646F5B_inline (uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE * __this, const RuntimeMethod* method);
// System.String Unity.Mathematics.uint3::ToString()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR String_t* uint3_ToString_m0497363E44BBF1E7F68936646E1CFC09675FF23B_inline (uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE * __this, const RuntimeMethod* method);
// System.String Unity.Mathematics.uint3::ToString(System.String,System.IFormatProvider)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR String_t* uint3_ToString_m786F82DA9F9EE5A6985F8B8FE3600710D806232B_inline (uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE * __this, String_t* ___format0, RuntimeObject* ___formatProvider1, const RuntimeMethod* method);
// System.Boolean Unity.Mathematics.uint4::Equals(Unity.Mathematics.uint4)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool uint4_Equals_mCD29FF2676C20223B8043FD676230CCB4EAA934D_inline (uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92 * __this, uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  ___rhs0, const RuntimeMethod* method);
// System.Boolean Unity.Mathematics.uint4::Equals(System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool uint4_Equals_m852477DBE9163FE512CE869B6ED4DB1470B5171E (uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92 * __this, RuntimeObject * ___o0, const RuntimeMethod* method);
// System.UInt32 Unity.Mathematics.math::hash(Unity.Mathematics.uint4)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint32_t math_hash_m75BFBA2E7EB5F1542B66C31F5CC1F398EFBF697E_inline (uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  ___v0, const RuntimeMethod* method);
// System.Int32 Unity.Mathematics.uint4::GetHashCode()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t uint4_GetHashCode_m86A07B8FA19284D7065183699510D9601B490778_inline (uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92 * __this, const RuntimeMethod* method);
// System.String Unity.Mathematics.uint4::ToString()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR String_t* uint4_ToString_m9EFC2F5F7AC7B62F848D0E59CE894B72EED63B7B_inline (uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92 * __this, const RuntimeMethod* method);
// System.String Unity.Mathematics.uint4::ToString(System.String,System.IFormatProvider)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR String_t* uint4_ToString_mC1805F654F5474DF4F49D92910751B8A9B81C315_inline (uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92 * __this, String_t* ___format0, RuntimeObject* ___formatProvider1, const RuntimeMethod* method);
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void Unity.Mathematics.float2::.ctor(System.Single,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void float2__ctor_mA85C140C72CD3A1E8F287AEC7FF12A35C85C819C (float2_t11F5F2974404951113DDC4E13EEB6E2456295547 * __this, float ___x0, float ___y1, const RuntimeMethod* method)
{
	{
		// this.x = x;
		float L_0 = ___x0;
		__this->set_x_0(L_0);
		// this.y = y;
		float L_1 = ___y1;
		__this->set_y_1(L_1);
		// }
		return;
	}
}
IL2CPP_EXTERN_C  void float2__ctor_mA85C140C72CD3A1E8F287AEC7FF12A35C85C819C_AdjustorThunk (RuntimeObject * __this, float ___x0, float ___y1, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	float2_t11F5F2974404951113DDC4E13EEB6E2456295547 * _thisAdjusted = reinterpret_cast<float2_t11F5F2974404951113DDC4E13EEB6E2456295547 *>(__this + _offset);
	float2__ctor_mA85C140C72CD3A1E8F287AEC7FF12A35C85C819C_inline(_thisAdjusted, ___x0, ___y1, method);
}
// Unity.Mathematics.float2 Unity.Mathematics.float2::op_Multiply(Unity.Mathematics.float2,Unity.Mathematics.float2)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float2_t11F5F2974404951113DDC4E13EEB6E2456295547  float2_op_Multiply_mCDF7671FD1B50471F0144C61C9D051D5B389D828 (float2_t11F5F2974404951113DDC4E13EEB6E2456295547  ___lhs0, float2_t11F5F2974404951113DDC4E13EEB6E2456295547  ___rhs1, const RuntimeMethod* method)
{
	{
		// public static float2 operator * (float2 lhs, float2 rhs) { return new float2 (lhs.x * rhs.x, lhs.y * rhs.y); }
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_0 = ___lhs0;
		float L_1 = L_0.get_x_0();
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_2 = ___rhs1;
		float L_3 = L_2.get_x_0();
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_4 = ___lhs0;
		float L_5 = L_4.get_y_1();
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_6 = ___rhs1;
		float L_7 = L_6.get_y_1();
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_8;
		memset((&L_8), 0, sizeof(L_8));
		float2__ctor_mA85C140C72CD3A1E8F287AEC7FF12A35C85C819C_inline((&L_8), ((float)il2cpp_codegen_multiply((float)L_1, (float)L_3)), ((float)il2cpp_codegen_multiply((float)L_5, (float)L_7)), /*hidden argument*/NULL);
		return L_8;
	}
}
// Unity.Mathematics.float2 Unity.Mathematics.float2::op_Multiply(Unity.Mathematics.float2,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float2_t11F5F2974404951113DDC4E13EEB6E2456295547  float2_op_Multiply_m42DF12B16A00A45E9F56D7EA0EAE0761B02F8D9C (float2_t11F5F2974404951113DDC4E13EEB6E2456295547  ___lhs0, float ___rhs1, const RuntimeMethod* method)
{
	{
		// public static float2 operator * (float2 lhs, float rhs) { return new float2 (lhs.x * rhs, lhs.y * rhs); }
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_0 = ___lhs0;
		float L_1 = L_0.get_x_0();
		float L_2 = ___rhs1;
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_3 = ___lhs0;
		float L_4 = L_3.get_y_1();
		float L_5 = ___rhs1;
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_6;
		memset((&L_6), 0, sizeof(L_6));
		float2__ctor_mA85C140C72CD3A1E8F287AEC7FF12A35C85C819C_inline((&L_6), ((float)il2cpp_codegen_multiply((float)L_1, (float)L_2)), ((float)il2cpp_codegen_multiply((float)L_4, (float)L_5)), /*hidden argument*/NULL);
		return L_6;
	}
}
// Unity.Mathematics.float2 Unity.Mathematics.float2::op_Multiply(System.Single,Unity.Mathematics.float2)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float2_t11F5F2974404951113DDC4E13EEB6E2456295547  float2_op_Multiply_m07CB14BD054267E48BF40992AD4A341FAF0A21ED (float ___lhs0, float2_t11F5F2974404951113DDC4E13EEB6E2456295547  ___rhs1, const RuntimeMethod* method)
{
	{
		// public static float2 operator * (float lhs, float2 rhs) { return new float2 (lhs * rhs.x, lhs * rhs.y); }
		float L_0 = ___lhs0;
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_1 = ___rhs1;
		float L_2 = L_1.get_x_0();
		float L_3 = ___lhs0;
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_4 = ___rhs1;
		float L_5 = L_4.get_y_1();
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_6;
		memset((&L_6), 0, sizeof(L_6));
		float2__ctor_mA85C140C72CD3A1E8F287AEC7FF12A35C85C819C_inline((&L_6), ((float)il2cpp_codegen_multiply((float)L_0, (float)L_2)), ((float)il2cpp_codegen_multiply((float)L_3, (float)L_5)), /*hidden argument*/NULL);
		return L_6;
	}
}
// Unity.Mathematics.float2 Unity.Mathematics.float2::op_Addition(Unity.Mathematics.float2,Unity.Mathematics.float2)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float2_t11F5F2974404951113DDC4E13EEB6E2456295547  float2_op_Addition_m556A2E2D194BC26DEB4669A60BD31BA58B04DAF5 (float2_t11F5F2974404951113DDC4E13EEB6E2456295547  ___lhs0, float2_t11F5F2974404951113DDC4E13EEB6E2456295547  ___rhs1, const RuntimeMethod* method)
{
	{
		// public static float2 operator + (float2 lhs, float2 rhs) { return new float2 (lhs.x + rhs.x, lhs.y + rhs.y); }
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_0 = ___lhs0;
		float L_1 = L_0.get_x_0();
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_2 = ___rhs1;
		float L_3 = L_2.get_x_0();
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_4 = ___lhs0;
		float L_5 = L_4.get_y_1();
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_6 = ___rhs1;
		float L_7 = L_6.get_y_1();
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_8;
		memset((&L_8), 0, sizeof(L_8));
		float2__ctor_mA85C140C72CD3A1E8F287AEC7FF12A35C85C819C_inline((&L_8), ((float)il2cpp_codegen_add((float)L_1, (float)L_3)), ((float)il2cpp_codegen_add((float)L_5, (float)L_7)), /*hidden argument*/NULL);
		return L_8;
	}
}
// Unity.Mathematics.float2 Unity.Mathematics.float2::op_Subtraction(Unity.Mathematics.float2,Unity.Mathematics.float2)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float2_t11F5F2974404951113DDC4E13EEB6E2456295547  float2_op_Subtraction_mAB64955A1F75E3ED6D1055AA7F2851552F0AB98A (float2_t11F5F2974404951113DDC4E13EEB6E2456295547  ___lhs0, float2_t11F5F2974404951113DDC4E13EEB6E2456295547  ___rhs1, const RuntimeMethod* method)
{
	{
		// public static float2 operator - (float2 lhs, float2 rhs) { return new float2 (lhs.x - rhs.x, lhs.y - rhs.y); }
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_0 = ___lhs0;
		float L_1 = L_0.get_x_0();
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_2 = ___rhs1;
		float L_3 = L_2.get_x_0();
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_4 = ___lhs0;
		float L_5 = L_4.get_y_1();
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_6 = ___rhs1;
		float L_7 = L_6.get_y_1();
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_8;
		memset((&L_8), 0, sizeof(L_8));
		float2__ctor_mA85C140C72CD3A1E8F287AEC7FF12A35C85C819C_inline((&L_8), ((float)il2cpp_codegen_subtract((float)L_1, (float)L_3)), ((float)il2cpp_codegen_subtract((float)L_5, (float)L_7)), /*hidden argument*/NULL);
		return L_8;
	}
}
// Unity.Mathematics.float2 Unity.Mathematics.float2::op_UnaryNegation(Unity.Mathematics.float2)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float2_t11F5F2974404951113DDC4E13EEB6E2456295547  float2_op_UnaryNegation_mAA3CE88A7EA79CFD55A2CC7B3D234D508F096777 (float2_t11F5F2974404951113DDC4E13EEB6E2456295547  ___val0, const RuntimeMethod* method)
{
	{
		// public static float2 operator - (float2 val) { return new float2 (-val.x, -val.y); }
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_0 = ___val0;
		float L_1 = L_0.get_x_0();
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_2 = ___val0;
		float L_3 = L_2.get_y_1();
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_4;
		memset((&L_4), 0, sizeof(L_4));
		float2__ctor_mA85C140C72CD3A1E8F287AEC7FF12A35C85C819C_inline((&L_4), ((-L_1)), ((-L_3)), /*hidden argument*/NULL);
		return L_4;
	}
}
// Unity.Mathematics.float2 Unity.Mathematics.float2::get_xy()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float2_t11F5F2974404951113DDC4E13EEB6E2456295547  float2_get_xy_m70AC8FFD749BA962E2C2822CCD4B731098858DCB (float2_t11F5F2974404951113DDC4E13EEB6E2456295547 * __this, const RuntimeMethod* method)
{
	{
		// get { return new float2(x, y); }
		float L_0 = __this->get_x_0();
		float L_1 = __this->get_y_1();
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_2;
		memset((&L_2), 0, sizeof(L_2));
		float2__ctor_mA85C140C72CD3A1E8F287AEC7FF12A35C85C819C_inline((&L_2), L_0, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
IL2CPP_EXTERN_C  float2_t11F5F2974404951113DDC4E13EEB6E2456295547  float2_get_xy_m70AC8FFD749BA962E2C2822CCD4B731098858DCB_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	float2_t11F5F2974404951113DDC4E13EEB6E2456295547 * _thisAdjusted = reinterpret_cast<float2_t11F5F2974404951113DDC4E13EEB6E2456295547 *>(__this + _offset);
	float2_t11F5F2974404951113DDC4E13EEB6E2456295547  _returnValue;
	_returnValue = float2_get_xy_m70AC8FFD749BA962E2C2822CCD4B731098858DCB_inline(_thisAdjusted, method);
	return _returnValue;
}
// System.Boolean Unity.Mathematics.float2::Equals(Unity.Mathematics.float2)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool float2_Equals_m406569E20C262C01141F2977EB04430121AD5AFE (float2_t11F5F2974404951113DDC4E13EEB6E2456295547 * __this, float2_t11F5F2974404951113DDC4E13EEB6E2456295547  ___rhs0, const RuntimeMethod* method)
{
	{
		// public bool Equals(float2 rhs) { return x == rhs.x && y == rhs.y; }
		float L_0 = __this->get_x_0();
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_1 = ___rhs0;
		float L_2 = L_1.get_x_0();
		if ((!(((float)L_0) == ((float)L_2))))
		{
			goto IL_001d;
		}
	}
	{
		float L_3 = __this->get_y_1();
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_4 = ___rhs0;
		float L_5 = L_4.get_y_1();
		return (bool)((((float)L_3) == ((float)L_5))? 1 : 0);
	}

IL_001d:
	{
		return (bool)0;
	}
}
IL2CPP_EXTERN_C  bool float2_Equals_m406569E20C262C01141F2977EB04430121AD5AFE_AdjustorThunk (RuntimeObject * __this, float2_t11F5F2974404951113DDC4E13EEB6E2456295547  ___rhs0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	float2_t11F5F2974404951113DDC4E13EEB6E2456295547 * _thisAdjusted = reinterpret_cast<float2_t11F5F2974404951113DDC4E13EEB6E2456295547 *>(__this + _offset);
	bool _returnValue;
	_returnValue = float2_Equals_m406569E20C262C01141F2977EB04430121AD5AFE_inline(_thisAdjusted, ___rhs0, method);
	return _returnValue;
}
// System.Boolean Unity.Mathematics.float2::Equals(System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool float2_Equals_mB13D7F862604D5C8577B46794CB4F4741917D1BC (float2_t11F5F2974404951113DDC4E13EEB6E2456295547 * __this, RuntimeObject * ___o0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&float2_t11F5F2974404951113DDC4E13EEB6E2456295547_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// public override bool Equals(object o) { return Equals((float2)o); }
		RuntimeObject * L_0 = ___o0;
		bool L_1;
		L_1 = float2_Equals_m406569E20C262C01141F2977EB04430121AD5AFE_inline((float2_t11F5F2974404951113DDC4E13EEB6E2456295547 *)__this, ((*(float2_t11F5F2974404951113DDC4E13EEB6E2456295547 *)((float2_t11F5F2974404951113DDC4E13EEB6E2456295547 *)UnBox(L_0, float2_t11F5F2974404951113DDC4E13EEB6E2456295547_il2cpp_TypeInfo_var)))), /*hidden argument*/NULL);
		return L_1;
	}
}
IL2CPP_EXTERN_C  bool float2_Equals_mB13D7F862604D5C8577B46794CB4F4741917D1BC_AdjustorThunk (RuntimeObject * __this, RuntimeObject * ___o0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	float2_t11F5F2974404951113DDC4E13EEB6E2456295547 * _thisAdjusted = reinterpret_cast<float2_t11F5F2974404951113DDC4E13EEB6E2456295547 *>(__this + _offset);
	bool _returnValue;
	_returnValue = float2_Equals_mB13D7F862604D5C8577B46794CB4F4741917D1BC(_thisAdjusted, ___o0, method);
	return _returnValue;
}
// System.Int32 Unity.Mathematics.float2::GetHashCode()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t float2_GetHashCode_mAB652A4865F38E1A58F754B6B8E17F24617B2C23 (float2_t11F5F2974404951113DDC4E13EEB6E2456295547 * __this, const RuntimeMethod* method)
{
	{
		// public override int GetHashCode() { return (int)math.hash(this); }
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_0 = (*(float2_t11F5F2974404951113DDC4E13EEB6E2456295547 *)__this);
		uint32_t L_1;
		L_1 = math_hash_m0214B7050F1399AD283DFF8CB115A65E0B95E1BA_inline(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
IL2CPP_EXTERN_C  int32_t float2_GetHashCode_mAB652A4865F38E1A58F754B6B8E17F24617B2C23_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	float2_t11F5F2974404951113DDC4E13EEB6E2456295547 * _thisAdjusted = reinterpret_cast<float2_t11F5F2974404951113DDC4E13EEB6E2456295547 *>(__this + _offset);
	int32_t _returnValue;
	_returnValue = float2_GetHashCode_mAB652A4865F38E1A58F754B6B8E17F24617B2C23_inline(_thisAdjusted, method);
	return _returnValue;
}
// System.String Unity.Mathematics.float2::ToString()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* float2_ToString_m88AFB1A56BC992680CB633C9A73EBEFD3369F8B1 (float2_t11F5F2974404951113DDC4E13EEB6E2456295547 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Single_tE07797BA3C98D4CA9B5A19413C19A76688AB899E_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral50EDAD5CFB15084F3338C313ED64018C8F78CD58);
		s_Il2CppMethodInitialized = true;
	}
	{
		// return string.Format("float2({0}f, {1}f)", x, y);
		float L_0 = __this->get_x_0();
		float L_1 = L_0;
		RuntimeObject * L_2 = Box(Single_tE07797BA3C98D4CA9B5A19413C19A76688AB899E_il2cpp_TypeInfo_var, &L_1);
		float L_3 = __this->get_y_1();
		float L_4 = L_3;
		RuntimeObject * L_5 = Box(Single_tE07797BA3C98D4CA9B5A19413C19A76688AB899E_il2cpp_TypeInfo_var, &L_4);
		String_t* L_6;
		L_6 = String_Format_m8D1CB0410C35E052A53AE957C914C841E54BAB66(_stringLiteral50EDAD5CFB15084F3338C313ED64018C8F78CD58, L_2, L_5, /*hidden argument*/NULL);
		return L_6;
	}
}
IL2CPP_EXTERN_C  String_t* float2_ToString_m88AFB1A56BC992680CB633C9A73EBEFD3369F8B1_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	float2_t11F5F2974404951113DDC4E13EEB6E2456295547 * _thisAdjusted = reinterpret_cast<float2_t11F5F2974404951113DDC4E13EEB6E2456295547 *>(__this + _offset);
	String_t* _returnValue;
	_returnValue = float2_ToString_m88AFB1A56BC992680CB633C9A73EBEFD3369F8B1_inline(_thisAdjusted, method);
	return _returnValue;
}
// System.String Unity.Mathematics.float2::ToString(System.String,System.IFormatProvider)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* float2_ToString_m663E65C99B64AD3B4CBEC51AC457685D0A0369B6 (float2_t11F5F2974404951113DDC4E13EEB6E2456295547 * __this, String_t* ___format0, RuntimeObject* ___formatProvider1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral50EDAD5CFB15084F3338C313ED64018C8F78CD58);
		s_Il2CppMethodInitialized = true;
	}
	{
		// return string.Format("float2({0}f, {1}f)", x.ToString(format, formatProvider), y.ToString(format, formatProvider));
		float* L_0 = __this->get_address_of_x_0();
		String_t* L_1 = ___format0;
		RuntimeObject* L_2 = ___formatProvider1;
		String_t* L_3;
		L_3 = Single_ToString_m7631D332703B4197EAA7DC0BA067CE7E16334D8B((float*)L_0, L_1, L_2, /*hidden argument*/NULL);
		float* L_4 = __this->get_address_of_y_1();
		String_t* L_5 = ___format0;
		RuntimeObject* L_6 = ___formatProvider1;
		String_t* L_7;
		L_7 = Single_ToString_m7631D332703B4197EAA7DC0BA067CE7E16334D8B((float*)L_4, L_5, L_6, /*hidden argument*/NULL);
		String_t* L_8;
		L_8 = String_Format_m8D1CB0410C35E052A53AE957C914C841E54BAB66(_stringLiteral50EDAD5CFB15084F3338C313ED64018C8F78CD58, L_3, L_7, /*hidden argument*/NULL);
		return L_8;
	}
}
IL2CPP_EXTERN_C  String_t* float2_ToString_m663E65C99B64AD3B4CBEC51AC457685D0A0369B6_AdjustorThunk (RuntimeObject * __this, String_t* ___format0, RuntimeObject* ___formatProvider1, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	float2_t11F5F2974404951113DDC4E13EEB6E2456295547 * _thisAdjusted = reinterpret_cast<float2_t11F5F2974404951113DDC4E13EEB6E2456295547 *>(__this + _offset);
	String_t* _returnValue;
	_returnValue = float2_ToString_m663E65C99B64AD3B4CBEC51AC457685D0A0369B6_inline(_thisAdjusted, ___format0, ___formatProvider1, method);
	return _returnValue;
}
// Unity.Mathematics.float2 Unity.Mathematics.float2::op_Implicit(UnityEngine.Vector2)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float2_t11F5F2974404951113DDC4E13EEB6E2456295547  float2_op_Implicit_mA182095CB6AFC6D0078712EFDF853D438B712B35 (Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  ___v0, const RuntimeMethod* method)
{
	{
		// public static implicit operator float2(Vector2 v)     { return new float2(v.x, v.y); }
		Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  L_0 = ___v0;
		float L_1 = L_0.get_x_0();
		Vector2_tBB32F2736AEC229A7BFBCE18197EC0F6AC7EC2D9  L_2 = ___v0;
		float L_3 = L_2.get_y_1();
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_4;
		memset((&L_4), 0, sizeof(L_4));
		float2__ctor_mA85C140C72CD3A1E8F287AEC7FF12A35C85C819C_inline((&L_4), L_1, L_3, /*hidden argument*/NULL);
		return L_4;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void Unity.Mathematics.float3::.ctor(System.Single,System.Single,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void float3__ctor_m853853CCAF2BC58F66EE07DB9338C1644698D483 (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * __this, float ___x0, float ___y1, float ___z2, const RuntimeMethod* method)
{
	{
		// this.x = x;
		float L_0 = ___x0;
		__this->set_x_0(L_0);
		// this.y = y;
		float L_1 = ___y1;
		__this->set_y_1(L_1);
		// this.z = z;
		float L_2 = ___z2;
		__this->set_z_2(L_2);
		// }
		return;
	}
}
IL2CPP_EXTERN_C  void float3__ctor_m853853CCAF2BC58F66EE07DB9338C1644698D483_AdjustorThunk (RuntimeObject * __this, float ___x0, float ___y1, float ___z2, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * _thisAdjusted = reinterpret_cast<float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D *>(__this + _offset);
	float3__ctor_m853853CCAF2BC58F66EE07DB9338C1644698D483_inline(_thisAdjusted, ___x0, ___y1, ___z2, method);
}
// System.Void Unity.Mathematics.float3::.ctor(Unity.Mathematics.float2,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void float3__ctor_mB8B1FC017A7671C0F19CBF32B243871B770F219B (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * __this, float2_t11F5F2974404951113DDC4E13EEB6E2456295547  ___xy0, float ___z1, const RuntimeMethod* method)
{
	{
		// this.x = xy.x;
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_0 = ___xy0;
		float L_1 = L_0.get_x_0();
		__this->set_x_0(L_1);
		// this.y = xy.y;
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_2 = ___xy0;
		float L_3 = L_2.get_y_1();
		__this->set_y_1(L_3);
		// this.z = z;
		float L_4 = ___z1;
		__this->set_z_2(L_4);
		// }
		return;
	}
}
IL2CPP_EXTERN_C  void float3__ctor_mB8B1FC017A7671C0F19CBF32B243871B770F219B_AdjustorThunk (RuntimeObject * __this, float2_t11F5F2974404951113DDC4E13EEB6E2456295547  ___xy0, float ___z1, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * _thisAdjusted = reinterpret_cast<float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D *>(__this + _offset);
	float3__ctor_mB8B1FC017A7671C0F19CBF32B243871B770F219B_inline(_thisAdjusted, ___xy0, ___z1, method);
}
// System.Void Unity.Mathematics.float3::.ctor(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void float3__ctor_mD066F7C313EE72EC068E4CD9E6475CD0D148A4B4 (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * __this, float ___v0, const RuntimeMethod* method)
{
	{
		// this.x = v;
		float L_0 = ___v0;
		__this->set_x_0(L_0);
		// this.y = v;
		float L_1 = ___v0;
		__this->set_y_1(L_1);
		// this.z = v;
		float L_2 = ___v0;
		__this->set_z_2(L_2);
		// }
		return;
	}
}
IL2CPP_EXTERN_C  void float3__ctor_mD066F7C313EE72EC068E4CD9E6475CD0D148A4B4_AdjustorThunk (RuntimeObject * __this, float ___v0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * _thisAdjusted = reinterpret_cast<float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D *>(__this + _offset);
	float3__ctor_mD066F7C313EE72EC068E4CD9E6475CD0D148A4B4_inline(_thisAdjusted, ___v0, method);
}
// Unity.Mathematics.float3 Unity.Mathematics.float3::op_Multiply(Unity.Mathematics.float3,Unity.Mathematics.float3)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  float3_op_Multiply_m296B37BB82979715ED4A076EBE7BE72F83C56CD7 (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___lhs0, float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___rhs1, const RuntimeMethod* method)
{
	{
		// public static float3 operator * (float3 lhs, float3 rhs) { return new float3 (lhs.x * rhs.x, lhs.y * rhs.y, lhs.z * rhs.z); }
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_0 = ___lhs0;
		float L_1 = L_0.get_x_0();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_2 = ___rhs1;
		float L_3 = L_2.get_x_0();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_4 = ___lhs0;
		float L_5 = L_4.get_y_1();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_6 = ___rhs1;
		float L_7 = L_6.get_y_1();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_8 = ___lhs0;
		float L_9 = L_8.get_z_2();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_10 = ___rhs1;
		float L_11 = L_10.get_z_2();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_12;
		memset((&L_12), 0, sizeof(L_12));
		float3__ctor_m853853CCAF2BC58F66EE07DB9338C1644698D483_inline((&L_12), ((float)il2cpp_codegen_multiply((float)L_1, (float)L_3)), ((float)il2cpp_codegen_multiply((float)L_5, (float)L_7)), ((float)il2cpp_codegen_multiply((float)L_9, (float)L_11)), /*hidden argument*/NULL);
		return L_12;
	}
}
// Unity.Mathematics.float3 Unity.Mathematics.float3::op_Multiply(Unity.Mathematics.float3,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  float3_op_Multiply_m069A0053A62627B6643C8953CCBA1C8E60F251B8 (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___lhs0, float ___rhs1, const RuntimeMethod* method)
{
	{
		// public static float3 operator * (float3 lhs, float rhs) { return new float3 (lhs.x * rhs, lhs.y * rhs, lhs.z * rhs); }
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_0 = ___lhs0;
		float L_1 = L_0.get_x_0();
		float L_2 = ___rhs1;
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_3 = ___lhs0;
		float L_4 = L_3.get_y_1();
		float L_5 = ___rhs1;
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_6 = ___lhs0;
		float L_7 = L_6.get_z_2();
		float L_8 = ___rhs1;
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_9;
		memset((&L_9), 0, sizeof(L_9));
		float3__ctor_m853853CCAF2BC58F66EE07DB9338C1644698D483_inline((&L_9), ((float)il2cpp_codegen_multiply((float)L_1, (float)L_2)), ((float)il2cpp_codegen_multiply((float)L_4, (float)L_5)), ((float)il2cpp_codegen_multiply((float)L_7, (float)L_8)), /*hidden argument*/NULL);
		return L_9;
	}
}
// Unity.Mathematics.float3 Unity.Mathematics.float3::op_Multiply(System.Single,Unity.Mathematics.float3)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  float3_op_Multiply_m66E0DDABA7E629CCCEFC6407B038D6FD42E1A1B0 (float ___lhs0, float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___rhs1, const RuntimeMethod* method)
{
	{
		// public static float3 operator * (float lhs, float3 rhs) { return new float3 (lhs * rhs.x, lhs * rhs.y, lhs * rhs.z); }
		float L_0 = ___lhs0;
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_1 = ___rhs1;
		float L_2 = L_1.get_x_0();
		float L_3 = ___lhs0;
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_4 = ___rhs1;
		float L_5 = L_4.get_y_1();
		float L_6 = ___lhs0;
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_7 = ___rhs1;
		float L_8 = L_7.get_z_2();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_9;
		memset((&L_9), 0, sizeof(L_9));
		float3__ctor_m853853CCAF2BC58F66EE07DB9338C1644698D483_inline((&L_9), ((float)il2cpp_codegen_multiply((float)L_0, (float)L_2)), ((float)il2cpp_codegen_multiply((float)L_3, (float)L_5)), ((float)il2cpp_codegen_multiply((float)L_6, (float)L_8)), /*hidden argument*/NULL);
		return L_9;
	}
}
// Unity.Mathematics.float3 Unity.Mathematics.float3::op_Addition(Unity.Mathematics.float3,Unity.Mathematics.float3)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  float3_op_Addition_mA5429BE3D1BE852B163E0B253A1E8B9D6FF4F57C (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___lhs0, float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___rhs1, const RuntimeMethod* method)
{
	{
		// public static float3 operator + (float3 lhs, float3 rhs) { return new float3 (lhs.x + rhs.x, lhs.y + rhs.y, lhs.z + rhs.z); }
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_0 = ___lhs0;
		float L_1 = L_0.get_x_0();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_2 = ___rhs1;
		float L_3 = L_2.get_x_0();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_4 = ___lhs0;
		float L_5 = L_4.get_y_1();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_6 = ___rhs1;
		float L_7 = L_6.get_y_1();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_8 = ___lhs0;
		float L_9 = L_8.get_z_2();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_10 = ___rhs1;
		float L_11 = L_10.get_z_2();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_12;
		memset((&L_12), 0, sizeof(L_12));
		float3__ctor_m853853CCAF2BC58F66EE07DB9338C1644698D483_inline((&L_12), ((float)il2cpp_codegen_add((float)L_1, (float)L_3)), ((float)il2cpp_codegen_add((float)L_5, (float)L_7)), ((float)il2cpp_codegen_add((float)L_9, (float)L_11)), /*hidden argument*/NULL);
		return L_12;
	}
}
// Unity.Mathematics.float3 Unity.Mathematics.float3::op_Subtraction(Unity.Mathematics.float3,Unity.Mathematics.float3)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  float3_op_Subtraction_mB3250D4D18B21370A6FEA3B2B527CFA7B6DE439D (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___lhs0, float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___rhs1, const RuntimeMethod* method)
{
	{
		// public static float3 operator - (float3 lhs, float3 rhs) { return new float3 (lhs.x - rhs.x, lhs.y - rhs.y, lhs.z - rhs.z); }
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_0 = ___lhs0;
		float L_1 = L_0.get_x_0();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_2 = ___rhs1;
		float L_3 = L_2.get_x_0();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_4 = ___lhs0;
		float L_5 = L_4.get_y_1();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_6 = ___rhs1;
		float L_7 = L_6.get_y_1();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_8 = ___lhs0;
		float L_9 = L_8.get_z_2();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_10 = ___rhs1;
		float L_11 = L_10.get_z_2();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_12;
		memset((&L_12), 0, sizeof(L_12));
		float3__ctor_m853853CCAF2BC58F66EE07DB9338C1644698D483_inline((&L_12), ((float)il2cpp_codegen_subtract((float)L_1, (float)L_3)), ((float)il2cpp_codegen_subtract((float)L_5, (float)L_7)), ((float)il2cpp_codegen_subtract((float)L_9, (float)L_11)), /*hidden argument*/NULL);
		return L_12;
	}
}
// Unity.Mathematics.float3 Unity.Mathematics.float3::op_Division(Unity.Mathematics.float3,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  float3_op_Division_m21A1D230D6CBA22F20BD0CBAC5979464C2FB6AA2 (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___lhs0, float ___rhs1, const RuntimeMethod* method)
{
	{
		// public static float3 operator / (float3 lhs, float rhs) { return new float3 (lhs.x / rhs, lhs.y / rhs, lhs.z / rhs); }
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_0 = ___lhs0;
		float L_1 = L_0.get_x_0();
		float L_2 = ___rhs1;
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_3 = ___lhs0;
		float L_4 = L_3.get_y_1();
		float L_5 = ___rhs1;
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_6 = ___lhs0;
		float L_7 = L_6.get_z_2();
		float L_8 = ___rhs1;
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_9;
		memset((&L_9), 0, sizeof(L_9));
		float3__ctor_m853853CCAF2BC58F66EE07DB9338C1644698D483_inline((&L_9), ((float)((float)L_1/(float)L_2)), ((float)((float)L_4/(float)L_5)), ((float)((float)L_7/(float)L_8)), /*hidden argument*/NULL);
		return L_9;
	}
}
// Unity.Mathematics.float3 Unity.Mathematics.float3::op_UnaryNegation(Unity.Mathematics.float3)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  float3_op_UnaryNegation_mC07D08180EAFADF5DEECD23A9DF352BBE3C0CFD3 (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___val0, const RuntimeMethod* method)
{
	{
		// public static float3 operator - (float3 val) { return new float3 (-val.x, -val.y, -val.z); }
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_0 = ___val0;
		float L_1 = L_0.get_x_0();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_2 = ___val0;
		float L_3 = L_2.get_y_1();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_4 = ___val0;
		float L_5 = L_4.get_z_2();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_6;
		memset((&L_6), 0, sizeof(L_6));
		float3__ctor_m853853CCAF2BC58F66EE07DB9338C1644698D483_inline((&L_6), ((-L_1)), ((-L_3)), ((-L_5)), /*hidden argument*/NULL);
		return L_6;
	}
}
// Unity.Mathematics.float3 Unity.Mathematics.float3::get_xzy()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  float3_get_xzy_mE4543537819B8525168D59076E3A19F95728DC77 (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * __this, const RuntimeMethod* method)
{
	{
		// get { return new float3(x, z, y); }
		float L_0 = __this->get_x_0();
		float L_1 = __this->get_z_2();
		float L_2 = __this->get_y_1();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_3;
		memset((&L_3), 0, sizeof(L_3));
		float3__ctor_m853853CCAF2BC58F66EE07DB9338C1644698D483_inline((&L_3), L_0, L_1, L_2, /*hidden argument*/NULL);
		return L_3;
	}
}
IL2CPP_EXTERN_C  float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  float3_get_xzy_mE4543537819B8525168D59076E3A19F95728DC77_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * _thisAdjusted = reinterpret_cast<float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D *>(__this + _offset);
	float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  _returnValue;
	_returnValue = float3_get_xzy_mE4543537819B8525168D59076E3A19F95728DC77_inline(_thisAdjusted, method);
	return _returnValue;
}
// Unity.Mathematics.float3 Unity.Mathematics.float3::get_yzx()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  float3_get_yzx_mAE305D9ABE33A40967A3BEECAF5E8CA1E66B2D6B (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * __this, const RuntimeMethod* method)
{
	{
		// get { return new float3(y, z, x); }
		float L_0 = __this->get_y_1();
		float L_1 = __this->get_z_2();
		float L_2 = __this->get_x_0();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_3;
		memset((&L_3), 0, sizeof(L_3));
		float3__ctor_m853853CCAF2BC58F66EE07DB9338C1644698D483_inline((&L_3), L_0, L_1, L_2, /*hidden argument*/NULL);
		return L_3;
	}
}
IL2CPP_EXTERN_C  float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  float3_get_yzx_mAE305D9ABE33A40967A3BEECAF5E8CA1E66B2D6B_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * _thisAdjusted = reinterpret_cast<float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D *>(__this + _offset);
	float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  _returnValue;
	_returnValue = float3_get_yzx_mAE305D9ABE33A40967A3BEECAF5E8CA1E66B2D6B_inline(_thisAdjusted, method);
	return _returnValue;
}
// Unity.Mathematics.float2 Unity.Mathematics.float3::get_xz()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float2_t11F5F2974404951113DDC4E13EEB6E2456295547  float3_get_xz_m9955DC8BBF06D0C80113321EB39C8946100B3693 (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * __this, const RuntimeMethod* method)
{
	{
		// get { return new float2(x, z); }
		float L_0 = __this->get_x_0();
		float L_1 = __this->get_z_2();
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_2;
		memset((&L_2), 0, sizeof(L_2));
		float2__ctor_mA85C140C72CD3A1E8F287AEC7FF12A35C85C819C_inline((&L_2), L_0, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
IL2CPP_EXTERN_C  float2_t11F5F2974404951113DDC4E13EEB6E2456295547  float3_get_xz_m9955DC8BBF06D0C80113321EB39C8946100B3693_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * _thisAdjusted = reinterpret_cast<float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D *>(__this + _offset);
	float2_t11F5F2974404951113DDC4E13EEB6E2456295547  _returnValue;
	_returnValue = float3_get_xz_m9955DC8BBF06D0C80113321EB39C8946100B3693_inline(_thisAdjusted, method);
	return _returnValue;
}
// System.Boolean Unity.Mathematics.float3::Equals(Unity.Mathematics.float3)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool float3_Equals_m082B461D20DCFD179A2A50F68737C51794D30F72 (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * __this, float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___rhs0, const RuntimeMethod* method)
{
	{
		// public bool Equals(float3 rhs) { return x == rhs.x && y == rhs.y && z == rhs.z; }
		float L_0 = __this->get_x_0();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_1 = ___rhs0;
		float L_2 = L_1.get_x_0();
		if ((!(((float)L_0) == ((float)L_2))))
		{
			goto IL_002b;
		}
	}
	{
		float L_3 = __this->get_y_1();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_4 = ___rhs0;
		float L_5 = L_4.get_y_1();
		if ((!(((float)L_3) == ((float)L_5))))
		{
			goto IL_002b;
		}
	}
	{
		float L_6 = __this->get_z_2();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_7 = ___rhs0;
		float L_8 = L_7.get_z_2();
		return (bool)((((float)L_6) == ((float)L_8))? 1 : 0);
	}

IL_002b:
	{
		return (bool)0;
	}
}
IL2CPP_EXTERN_C  bool float3_Equals_m082B461D20DCFD179A2A50F68737C51794D30F72_AdjustorThunk (RuntimeObject * __this, float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___rhs0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * _thisAdjusted = reinterpret_cast<float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D *>(__this + _offset);
	bool _returnValue;
	_returnValue = float3_Equals_m082B461D20DCFD179A2A50F68737C51794D30F72_inline(_thisAdjusted, ___rhs0, method);
	return _returnValue;
}
// System.Boolean Unity.Mathematics.float3::Equals(System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool float3_Equals_mF2580FD87C3D31BDF4C4EF55489BE5F9D4A02E10 (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * __this, RuntimeObject * ___o0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// public override bool Equals(object o) { return Equals((float3)o); }
		RuntimeObject * L_0 = ___o0;
		bool L_1;
		L_1 = float3_Equals_m082B461D20DCFD179A2A50F68737C51794D30F72_inline((float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D *)__this, ((*(float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D *)((float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D *)UnBox(L_0, float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D_il2cpp_TypeInfo_var)))), /*hidden argument*/NULL);
		return L_1;
	}
}
IL2CPP_EXTERN_C  bool float3_Equals_mF2580FD87C3D31BDF4C4EF55489BE5F9D4A02E10_AdjustorThunk (RuntimeObject * __this, RuntimeObject * ___o0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * _thisAdjusted = reinterpret_cast<float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D *>(__this + _offset);
	bool _returnValue;
	_returnValue = float3_Equals_mF2580FD87C3D31BDF4C4EF55489BE5F9D4A02E10(_thisAdjusted, ___o0, method);
	return _returnValue;
}
// System.Int32 Unity.Mathematics.float3::GetHashCode()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t float3_GetHashCode_m9D7B789ABF601895DE5127F10AB318E5FB34FF33 (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * __this, const RuntimeMethod* method)
{
	{
		// public override int GetHashCode() { return (int)math.hash(this); }
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_0 = (*(float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D *)__this);
		uint32_t L_1;
		L_1 = math_hash_m7B43A24382293202DAB3DF5C3953BE904664205B_inline(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
IL2CPP_EXTERN_C  int32_t float3_GetHashCode_m9D7B789ABF601895DE5127F10AB318E5FB34FF33_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * _thisAdjusted = reinterpret_cast<float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D *>(__this + _offset);
	int32_t _returnValue;
	_returnValue = float3_GetHashCode_m9D7B789ABF601895DE5127F10AB318E5FB34FF33_inline(_thisAdjusted, method);
	return _returnValue;
}
// System.String Unity.Mathematics.float3::ToString()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* float3_ToString_m1826B8701C72517A17CEDB7F7E4C804400A45F92 (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Single_tE07797BA3C98D4CA9B5A19413C19A76688AB899E_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral1578CABA4FF62AC9986DD5D0BA4C26A5CCB44A6A);
		s_Il2CppMethodInitialized = true;
	}
	{
		// return string.Format("float3({0}f, {1}f, {2}f)", x, y, z);
		float L_0 = __this->get_x_0();
		float L_1 = L_0;
		RuntimeObject * L_2 = Box(Single_tE07797BA3C98D4CA9B5A19413C19A76688AB899E_il2cpp_TypeInfo_var, &L_1);
		float L_3 = __this->get_y_1();
		float L_4 = L_3;
		RuntimeObject * L_5 = Box(Single_tE07797BA3C98D4CA9B5A19413C19A76688AB899E_il2cpp_TypeInfo_var, &L_4);
		float L_6 = __this->get_z_2();
		float L_7 = L_6;
		RuntimeObject * L_8 = Box(Single_tE07797BA3C98D4CA9B5A19413C19A76688AB899E_il2cpp_TypeInfo_var, &L_7);
		String_t* L_9;
		L_9 = String_Format_m039737CCD992C5BFC8D16DFD681F5E8786E87FA6(_stringLiteral1578CABA4FF62AC9986DD5D0BA4C26A5CCB44A6A, L_2, L_5, L_8, /*hidden argument*/NULL);
		return L_9;
	}
}
IL2CPP_EXTERN_C  String_t* float3_ToString_m1826B8701C72517A17CEDB7F7E4C804400A45F92_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * _thisAdjusted = reinterpret_cast<float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D *>(__this + _offset);
	String_t* _returnValue;
	_returnValue = float3_ToString_m1826B8701C72517A17CEDB7F7E4C804400A45F92_inline(_thisAdjusted, method);
	return _returnValue;
}
// System.String Unity.Mathematics.float3::ToString(System.String,System.IFormatProvider)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* float3_ToString_m341757749BF9ED59EC04C13798F9402B220E86C6 (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * __this, String_t* ___format0, RuntimeObject* ___formatProvider1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral1578CABA4FF62AC9986DD5D0BA4C26A5CCB44A6A);
		s_Il2CppMethodInitialized = true;
	}
	{
		// return string.Format("float3({0}f, {1}f, {2}f)", x.ToString(format, formatProvider), y.ToString(format, formatProvider), z.ToString(format, formatProvider));
		float* L_0 = __this->get_address_of_x_0();
		String_t* L_1 = ___format0;
		RuntimeObject* L_2 = ___formatProvider1;
		String_t* L_3;
		L_3 = Single_ToString_m7631D332703B4197EAA7DC0BA067CE7E16334D8B((float*)L_0, L_1, L_2, /*hidden argument*/NULL);
		float* L_4 = __this->get_address_of_y_1();
		String_t* L_5 = ___format0;
		RuntimeObject* L_6 = ___formatProvider1;
		String_t* L_7;
		L_7 = Single_ToString_m7631D332703B4197EAA7DC0BA067CE7E16334D8B((float*)L_4, L_5, L_6, /*hidden argument*/NULL);
		float* L_8 = __this->get_address_of_z_2();
		String_t* L_9 = ___format0;
		RuntimeObject* L_10 = ___formatProvider1;
		String_t* L_11;
		L_11 = Single_ToString_m7631D332703B4197EAA7DC0BA067CE7E16334D8B((float*)L_8, L_9, L_10, /*hidden argument*/NULL);
		String_t* L_12;
		L_12 = String_Format_m039737CCD992C5BFC8D16DFD681F5E8786E87FA6(_stringLiteral1578CABA4FF62AC9986DD5D0BA4C26A5CCB44A6A, L_3, L_7, L_11, /*hidden argument*/NULL);
		return L_12;
	}
}
IL2CPP_EXTERN_C  String_t* float3_ToString_m341757749BF9ED59EC04C13798F9402B220E86C6_AdjustorThunk (RuntimeObject * __this, String_t* ___format0, RuntimeObject* ___formatProvider1, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * _thisAdjusted = reinterpret_cast<float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D *>(__this + _offset);
	String_t* _returnValue;
	_returnValue = float3_ToString_m341757749BF9ED59EC04C13798F9402B220E86C6_inline(_thisAdjusted, ___format0, ___formatProvider1, method);
	return _returnValue;
}
// UnityEngine.Vector3 Unity.Mathematics.float3::op_Implicit(Unity.Mathematics.float3)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  float3_op_Implicit_m0FDFCBF138EAB0924AEFEB5CC1E1438D7A7E9611 (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___v0, const RuntimeMethod* method)
{
	{
		// public static implicit operator Vector3(float3 v)     { return new Vector3(v.x, v.y, v.z); }
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_0 = ___v0;
		float L_1 = L_0.get_x_0();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_2 = ___v0;
		float L_3 = L_2.get_y_1();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_4 = ___v0;
		float L_5 = L_4.get_z_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_6;
		memset((&L_6), 0, sizeof(L_6));
		Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline((&L_6), L_1, L_3, L_5, /*hidden argument*/NULL);
		return L_6;
	}
}
// Unity.Mathematics.float3 Unity.Mathematics.float3::op_Implicit(UnityEngine.Vector3)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  float3_op_Implicit_m93DBE32F1574A6FD82DD480905BACDD63491924C (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  ___v0, const RuntimeMethod* method)
{
	{
		// public static implicit operator float3(Vector3 v)     { return new float3(v.x, v.y, v.z); }
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_0 = ___v0;
		float L_1 = L_0.get_x_2();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_2 = ___v0;
		float L_3 = L_2.get_y_3();
		Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E  L_4 = ___v0;
		float L_5 = L_4.get_z_4();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_6;
		memset((&L_6), 0, sizeof(L_6));
		float3__ctor_m853853CCAF2BC58F66EE07DB9338C1644698D483_inline((&L_6), L_1, L_3, L_5, /*hidden argument*/NULL);
		return L_6;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void Unity.Mathematics.float4::.ctor(System.Single,System.Single,System.Single,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void float4__ctor_m289038BF46A44D4F1F0A897417C1F9C96B96F349 (float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 * __this, float ___x0, float ___y1, float ___z2, float ___w3, const RuntimeMethod* method)
{
	{
		// this.x = x;
		float L_0 = ___x0;
		__this->set_x_0(L_0);
		// this.y = y;
		float L_1 = ___y1;
		__this->set_y_1(L_1);
		// this.z = z;
		float L_2 = ___z2;
		__this->set_z_2(L_2);
		// this.w = w;
		float L_3 = ___w3;
		__this->set_w_3(L_3);
		// }
		return;
	}
}
IL2CPP_EXTERN_C  void float4__ctor_m289038BF46A44D4F1F0A897417C1F9C96B96F349_AdjustorThunk (RuntimeObject * __this, float ___x0, float ___y1, float ___z2, float ___w3, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 * _thisAdjusted = reinterpret_cast<float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 *>(__this + _offset);
	float4__ctor_m289038BF46A44D4F1F0A897417C1F9C96B96F349_inline(_thisAdjusted, ___x0, ___y1, ___z2, ___w3, method);
}
// Unity.Mathematics.float3 Unity.Mathematics.float4::get_xyz()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  float4_get_xyz_mC891E5A9ADFCD1137A3E1D0DF70A60A10290E4D2 (float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 * __this, const RuntimeMethod* method)
{
	{
		// get { return new float3(x, y, z); }
		float L_0 = __this->get_x_0();
		float L_1 = __this->get_y_1();
		float L_2 = __this->get_z_2();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_3;
		memset((&L_3), 0, sizeof(L_3));
		float3__ctor_m853853CCAF2BC58F66EE07DB9338C1644698D483_inline((&L_3), L_0, L_1, L_2, /*hidden argument*/NULL);
		return L_3;
	}
}
IL2CPP_EXTERN_C  float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  float4_get_xyz_mC891E5A9ADFCD1137A3E1D0DF70A60A10290E4D2_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 * _thisAdjusted = reinterpret_cast<float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 *>(__this + _offset);
	float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  _returnValue;
	_returnValue = float4_get_xyz_mC891E5A9ADFCD1137A3E1D0DF70A60A10290E4D2_inline(_thisAdjusted, method);
	return _returnValue;
}
// System.Void Unity.Mathematics.float4::set_xyz(Unity.Mathematics.float3)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void float4_set_xyz_m835174016809C625D7564655F4E2CCB95A024C45 (float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 * __this, float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___value0, const RuntimeMethod* method)
{
	{
		// set { x = value.x; y = value.y; z = value.z; }
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_0 = ___value0;
		float L_1 = L_0.get_x_0();
		__this->set_x_0(L_1);
		// set { x = value.x; y = value.y; z = value.z; }
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_2 = ___value0;
		float L_3 = L_2.get_y_1();
		__this->set_y_1(L_3);
		// set { x = value.x; y = value.y; z = value.z; }
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_4 = ___value0;
		float L_5 = L_4.get_z_2();
		__this->set_z_2(L_5);
		// set { x = value.x; y = value.y; z = value.z; }
		return;
	}
}
IL2CPP_EXTERN_C  void float4_set_xyz_m835174016809C625D7564655F4E2CCB95A024C45_AdjustorThunk (RuntimeObject * __this, float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___value0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 * _thisAdjusted = reinterpret_cast<float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 *>(__this + _offset);
	float4_set_xyz_m835174016809C625D7564655F4E2CCB95A024C45_inline(_thisAdjusted, ___value0, method);
}
// System.Boolean Unity.Mathematics.float4::Equals(Unity.Mathematics.float4)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool float4_Equals_mFDF5FFF5DBF9FCD0FFD92C00CC3A0E6A22676C76 (float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 * __this, float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  ___rhs0, const RuntimeMethod* method)
{
	{
		// public bool Equals(float4 rhs) { return x == rhs.x && y == rhs.y && z == rhs.z && w == rhs.w; }
		float L_0 = __this->get_x_0();
		float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  L_1 = ___rhs0;
		float L_2 = L_1.get_x_0();
		if ((!(((float)L_0) == ((float)L_2))))
		{
			goto IL_0039;
		}
	}
	{
		float L_3 = __this->get_y_1();
		float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  L_4 = ___rhs0;
		float L_5 = L_4.get_y_1();
		if ((!(((float)L_3) == ((float)L_5))))
		{
			goto IL_0039;
		}
	}
	{
		float L_6 = __this->get_z_2();
		float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  L_7 = ___rhs0;
		float L_8 = L_7.get_z_2();
		if ((!(((float)L_6) == ((float)L_8))))
		{
			goto IL_0039;
		}
	}
	{
		float L_9 = __this->get_w_3();
		float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  L_10 = ___rhs0;
		float L_11 = L_10.get_w_3();
		return (bool)((((float)L_9) == ((float)L_11))? 1 : 0);
	}

IL_0039:
	{
		return (bool)0;
	}
}
IL2CPP_EXTERN_C  bool float4_Equals_mFDF5FFF5DBF9FCD0FFD92C00CC3A0E6A22676C76_AdjustorThunk (RuntimeObject * __this, float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  ___rhs0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 * _thisAdjusted = reinterpret_cast<float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 *>(__this + _offset);
	bool _returnValue;
	_returnValue = float4_Equals_mFDF5FFF5DBF9FCD0FFD92C00CC3A0E6A22676C76_inline(_thisAdjusted, ___rhs0, method);
	return _returnValue;
}
// System.Boolean Unity.Mathematics.float4::Equals(System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool float4_Equals_m481BDCD35ED8247881583FCBA9C66794A8BC008F (float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 * __this, RuntimeObject * ___o0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// public override bool Equals(object o) { return Equals((float4)o); }
		RuntimeObject * L_0 = ___o0;
		bool L_1;
		L_1 = float4_Equals_mFDF5FFF5DBF9FCD0FFD92C00CC3A0E6A22676C76_inline((float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 *)__this, ((*(float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 *)((float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 *)UnBox(L_0, float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883_il2cpp_TypeInfo_var)))), /*hidden argument*/NULL);
		return L_1;
	}
}
IL2CPP_EXTERN_C  bool float4_Equals_m481BDCD35ED8247881583FCBA9C66794A8BC008F_AdjustorThunk (RuntimeObject * __this, RuntimeObject * ___o0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 * _thisAdjusted = reinterpret_cast<float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 *>(__this + _offset);
	bool _returnValue;
	_returnValue = float4_Equals_m481BDCD35ED8247881583FCBA9C66794A8BC008F(_thisAdjusted, ___o0, method);
	return _returnValue;
}
// System.Int32 Unity.Mathematics.float4::GetHashCode()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t float4_GetHashCode_m7138A6A1ED3F8142D24A7D0F53264FD3D3C2DA97 (float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 * __this, const RuntimeMethod* method)
{
	{
		// public override int GetHashCode() { return (int)math.hash(this); }
		float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  L_0 = (*(float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 *)__this);
		uint32_t L_1;
		L_1 = math_hash_m53A15DB25196562BA8CF64481E3F9B4995AE75F7_inline(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
IL2CPP_EXTERN_C  int32_t float4_GetHashCode_m7138A6A1ED3F8142D24A7D0F53264FD3D3C2DA97_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 * _thisAdjusted = reinterpret_cast<float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 *>(__this + _offset);
	int32_t _returnValue;
	_returnValue = float4_GetHashCode_m7138A6A1ED3F8142D24A7D0F53264FD3D3C2DA97_inline(_thisAdjusted, method);
	return _returnValue;
}
// System.String Unity.Mathematics.float4::ToString()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* float4_ToString_mEF96A2289BB136EEE679B8F90D771C58DB031EB7 (float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Single_tE07797BA3C98D4CA9B5A19413C19A76688AB899E_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral43DDB8ABCD260FFF159CAB7520989AEB22E45033);
		s_Il2CppMethodInitialized = true;
	}
	{
		// return string.Format("float4({0}f, {1}f, {2}f, {3}f)", x, y, z, w);
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_0 = (ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE*)(ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE*)SZArrayNew(ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE_il2cpp_TypeInfo_var, (uint32_t)4);
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_1 = L_0;
		float L_2 = __this->get_x_0();
		float L_3 = L_2;
		RuntimeObject * L_4 = Box(Single_tE07797BA3C98D4CA9B5A19413C19A76688AB899E_il2cpp_TypeInfo_var, &L_3);
		NullCheck(L_1);
		ArrayElementTypeCheck (L_1, L_4);
		(L_1)->SetAt(static_cast<il2cpp_array_size_t>(0), (RuntimeObject *)L_4);
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_5 = L_1;
		float L_6 = __this->get_y_1();
		float L_7 = L_6;
		RuntimeObject * L_8 = Box(Single_tE07797BA3C98D4CA9B5A19413C19A76688AB899E_il2cpp_TypeInfo_var, &L_7);
		NullCheck(L_5);
		ArrayElementTypeCheck (L_5, L_8);
		(L_5)->SetAt(static_cast<il2cpp_array_size_t>(1), (RuntimeObject *)L_8);
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_9 = L_5;
		float L_10 = __this->get_z_2();
		float L_11 = L_10;
		RuntimeObject * L_12 = Box(Single_tE07797BA3C98D4CA9B5A19413C19A76688AB899E_il2cpp_TypeInfo_var, &L_11);
		NullCheck(L_9);
		ArrayElementTypeCheck (L_9, L_12);
		(L_9)->SetAt(static_cast<il2cpp_array_size_t>(2), (RuntimeObject *)L_12);
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_13 = L_9;
		float L_14 = __this->get_w_3();
		float L_15 = L_14;
		RuntimeObject * L_16 = Box(Single_tE07797BA3C98D4CA9B5A19413C19A76688AB899E_il2cpp_TypeInfo_var, &L_15);
		NullCheck(L_13);
		ArrayElementTypeCheck (L_13, L_16);
		(L_13)->SetAt(static_cast<il2cpp_array_size_t>(3), (RuntimeObject *)L_16);
		String_t* L_17;
		L_17 = String_Format_mCED6767EA5FEE6F15ABCD5B4F9150D1284C2795B(_stringLiteral43DDB8ABCD260FFF159CAB7520989AEB22E45033, L_13, /*hidden argument*/NULL);
		return L_17;
	}
}
IL2CPP_EXTERN_C  String_t* float4_ToString_mEF96A2289BB136EEE679B8F90D771C58DB031EB7_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 * _thisAdjusted = reinterpret_cast<float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 *>(__this + _offset);
	String_t* _returnValue;
	_returnValue = float4_ToString_mEF96A2289BB136EEE679B8F90D771C58DB031EB7_inline(_thisAdjusted, method);
	return _returnValue;
}
// System.String Unity.Mathematics.float4::ToString(System.String,System.IFormatProvider)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* float4_ToString_mF157EB1EA5B178949D39582EEB7AD960797E3CCF (float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 * __this, String_t* ___format0, RuntimeObject* ___formatProvider1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral43DDB8ABCD260FFF159CAB7520989AEB22E45033);
		s_Il2CppMethodInitialized = true;
	}
	{
		// return string.Format("float4({0}f, {1}f, {2}f, {3}f)", x.ToString(format, formatProvider), y.ToString(format, formatProvider), z.ToString(format, formatProvider), w.ToString(format, formatProvider));
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_0 = (ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE*)(ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE*)SZArrayNew(ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE_il2cpp_TypeInfo_var, (uint32_t)4);
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_1 = L_0;
		float* L_2 = __this->get_address_of_x_0();
		String_t* L_3 = ___format0;
		RuntimeObject* L_4 = ___formatProvider1;
		String_t* L_5;
		L_5 = Single_ToString_m7631D332703B4197EAA7DC0BA067CE7E16334D8B((float*)L_2, L_3, L_4, /*hidden argument*/NULL);
		NullCheck(L_1);
		ArrayElementTypeCheck (L_1, L_5);
		(L_1)->SetAt(static_cast<il2cpp_array_size_t>(0), (RuntimeObject *)L_5);
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_6 = L_1;
		float* L_7 = __this->get_address_of_y_1();
		String_t* L_8 = ___format0;
		RuntimeObject* L_9 = ___formatProvider1;
		String_t* L_10;
		L_10 = Single_ToString_m7631D332703B4197EAA7DC0BA067CE7E16334D8B((float*)L_7, L_8, L_9, /*hidden argument*/NULL);
		NullCheck(L_6);
		ArrayElementTypeCheck (L_6, L_10);
		(L_6)->SetAt(static_cast<il2cpp_array_size_t>(1), (RuntimeObject *)L_10);
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_11 = L_6;
		float* L_12 = __this->get_address_of_z_2();
		String_t* L_13 = ___format0;
		RuntimeObject* L_14 = ___formatProvider1;
		String_t* L_15;
		L_15 = Single_ToString_m7631D332703B4197EAA7DC0BA067CE7E16334D8B((float*)L_12, L_13, L_14, /*hidden argument*/NULL);
		NullCheck(L_11);
		ArrayElementTypeCheck (L_11, L_15);
		(L_11)->SetAt(static_cast<il2cpp_array_size_t>(2), (RuntimeObject *)L_15);
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_16 = L_11;
		float* L_17 = __this->get_address_of_w_3();
		String_t* L_18 = ___format0;
		RuntimeObject* L_19 = ___formatProvider1;
		String_t* L_20;
		L_20 = Single_ToString_m7631D332703B4197EAA7DC0BA067CE7E16334D8B((float*)L_17, L_18, L_19, /*hidden argument*/NULL);
		NullCheck(L_16);
		ArrayElementTypeCheck (L_16, L_20);
		(L_16)->SetAt(static_cast<il2cpp_array_size_t>(3), (RuntimeObject *)L_20);
		String_t* L_21;
		L_21 = String_Format_mCED6767EA5FEE6F15ABCD5B4F9150D1284C2795B(_stringLiteral43DDB8ABCD260FFF159CAB7520989AEB22E45033, L_16, /*hidden argument*/NULL);
		return L_21;
	}
}
IL2CPP_EXTERN_C  String_t* float4_ToString_mF157EB1EA5B178949D39582EEB7AD960797E3CCF_AdjustorThunk (RuntimeObject * __this, String_t* ___format0, RuntimeObject* ___formatProvider1, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 * _thisAdjusted = reinterpret_cast<float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 *>(__this + _offset);
	String_t* _returnValue;
	_returnValue = float4_ToString_mF157EB1EA5B178949D39582EEB7AD960797E3CCF_inline(_thisAdjusted, ___format0, ___formatProvider1, method);
	return _returnValue;
}
// Unity.Mathematics.float4 Unity.Mathematics.float4::op_Implicit(UnityEngine.Vector4)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  float4_op_Implicit_m22A04000B9A6A4A7E2A8199D991C2B719502CDDD (Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  ___v0, const RuntimeMethod* method)
{
	{
		// public static implicit operator float4(Vector4 v)     { return new float4(v.x, v.y, v.z, v.w); }
		Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  L_0 = ___v0;
		float L_1 = L_0.get_x_1();
		Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  L_2 = ___v0;
		float L_3 = L_2.get_y_2();
		Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  L_4 = ___v0;
		float L_5 = L_4.get_z_3();
		Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  L_6 = ___v0;
		float L_7 = L_6.get_w_4();
		float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  L_8;
		memset((&L_8), 0, sizeof(L_8));
		float4__ctor_m289038BF46A44D4F1F0A897417C1F9C96B96F349_inline((&L_8), L_1, L_3, L_5, L_7, /*hidden argument*/NULL);
		return L_8;
	}
}
// UnityEngine.Vector4 Unity.Mathematics.float4::op_Implicit(Unity.Mathematics.float4)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  float4_op_Implicit_m51D77EADF40125DBE6A53C215044AAB87DA7590A (float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  ___v0, const RuntimeMethod* method)
{
	{
		// public static implicit operator Vector4(float4 v)     { return new Vector4(v.x, v.y, v.z, v.w); }
		float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  L_0 = ___v0;
		float L_1 = L_0.get_x_0();
		float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  L_2 = ___v0;
		float L_3 = L_2.get_y_1();
		float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  L_4 = ___v0;
		float L_5 = L_4.get_z_2();
		float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  L_6 = ___v0;
		float L_7 = L_6.get_w_3();
		Vector4_tA56A37FC5661BCC89C3DDC24BE12BA5BCB6A02C7  L_8;
		memset((&L_8), 0, sizeof(L_8));
		Vector4__ctor_mCAB598A37C4D5E80282277E828B8A3EAD936D3B2((&L_8), L_1, L_3, L_5, L_7, /*hidden argument*/NULL);
		return L_8;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void Unity.Mathematics.int2::.ctor(System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void int2__ctor_mF2809193E310D356095F5534AF632CEB504845D1 (int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558 * __this, int32_t ___x0, int32_t ___y1, const RuntimeMethod* method)
{
	{
		// this.x = x;
		int32_t L_0 = ___x0;
		__this->set_x_0(L_0);
		// this.y = y;
		int32_t L_1 = ___y1;
		__this->set_y_1(L_1);
		// }
		return;
	}
}
IL2CPP_EXTERN_C  void int2__ctor_mF2809193E310D356095F5534AF632CEB504845D1_AdjustorThunk (RuntimeObject * __this, int32_t ___x0, int32_t ___y1, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558 * _thisAdjusted = reinterpret_cast<int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558 *>(__this + _offset);
	int2__ctor_mF2809193E310D356095F5534AF632CEB504845D1_inline(_thisAdjusted, ___x0, ___y1, method);
}
// System.Boolean Unity.Mathematics.int2::Equals(Unity.Mathematics.int2)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool int2_Equals_m24E4968D84F6232AB37F57692C3F8CBC03036668 (int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558 * __this, int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558  ___rhs0, const RuntimeMethod* method)
{
	{
		// public bool Equals(int2 rhs) { return x == rhs.x && y == rhs.y; }
		int32_t L_0 = __this->get_x_0();
		int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558  L_1 = ___rhs0;
		int32_t L_2 = L_1.get_x_0();
		if ((!(((uint32_t)L_0) == ((uint32_t)L_2))))
		{
			goto IL_001d;
		}
	}
	{
		int32_t L_3 = __this->get_y_1();
		int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558  L_4 = ___rhs0;
		int32_t L_5 = L_4.get_y_1();
		return (bool)((((int32_t)L_3) == ((int32_t)L_5))? 1 : 0);
	}

IL_001d:
	{
		return (bool)0;
	}
}
IL2CPP_EXTERN_C  bool int2_Equals_m24E4968D84F6232AB37F57692C3F8CBC03036668_AdjustorThunk (RuntimeObject * __this, int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558  ___rhs0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558 * _thisAdjusted = reinterpret_cast<int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558 *>(__this + _offset);
	bool _returnValue;
	_returnValue = int2_Equals_m24E4968D84F6232AB37F57692C3F8CBC03036668_inline(_thisAdjusted, ___rhs0, method);
	return _returnValue;
}
// System.Boolean Unity.Mathematics.int2::Equals(System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool int2_Equals_m66230D0C353BB0482EA0F13904ABC3766BA7FF53 (int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558 * __this, RuntimeObject * ___o0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// public override bool Equals(object o) { return Equals((int2)o); }
		RuntimeObject * L_0 = ___o0;
		bool L_1;
		L_1 = int2_Equals_m24E4968D84F6232AB37F57692C3F8CBC03036668_inline((int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558 *)__this, ((*(int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558 *)((int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558 *)UnBox(L_0, int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558_il2cpp_TypeInfo_var)))), /*hidden argument*/NULL);
		return L_1;
	}
}
IL2CPP_EXTERN_C  bool int2_Equals_m66230D0C353BB0482EA0F13904ABC3766BA7FF53_AdjustorThunk (RuntimeObject * __this, RuntimeObject * ___o0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558 * _thisAdjusted = reinterpret_cast<int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558 *>(__this + _offset);
	bool _returnValue;
	_returnValue = int2_Equals_m66230D0C353BB0482EA0F13904ABC3766BA7FF53(_thisAdjusted, ___o0, method);
	return _returnValue;
}
// System.Int32 Unity.Mathematics.int2::GetHashCode()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t int2_GetHashCode_m8F2D5944D3AEC3ADCB056ADD4B03DF6038B5C7B0 (int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558 * __this, const RuntimeMethod* method)
{
	{
		// public override int GetHashCode() { return (int)math.hash(this); }
		int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558  L_0 = (*(int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558 *)__this);
		uint32_t L_1;
		L_1 = math_hash_m23BB2E45EEDF0493DF3AD90AC3837C34A70FE471_inline(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
IL2CPP_EXTERN_C  int32_t int2_GetHashCode_m8F2D5944D3AEC3ADCB056ADD4B03DF6038B5C7B0_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558 * _thisAdjusted = reinterpret_cast<int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558 *>(__this + _offset);
	int32_t _returnValue;
	_returnValue = int2_GetHashCode_m8F2D5944D3AEC3ADCB056ADD4B03DF6038B5C7B0_inline(_thisAdjusted, method);
	return _returnValue;
}
// System.String Unity.Mathematics.int2::ToString()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* int2_ToString_m04651E132A626D5DDED8BCF33FB65768602FB655 (int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Int32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral039B19E6A63E9AA22F1AF2817559D285768A7B4A);
		s_Il2CppMethodInitialized = true;
	}
	{
		// return string.Format("int2({0}, {1})", x, y);
		int32_t L_0 = __this->get_x_0();
		int32_t L_1 = L_0;
		RuntimeObject * L_2 = Box(Int32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_il2cpp_TypeInfo_var, &L_1);
		int32_t L_3 = __this->get_y_1();
		int32_t L_4 = L_3;
		RuntimeObject * L_5 = Box(Int32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_il2cpp_TypeInfo_var, &L_4);
		String_t* L_6;
		L_6 = String_Format_m8D1CB0410C35E052A53AE957C914C841E54BAB66(_stringLiteral039B19E6A63E9AA22F1AF2817559D285768A7B4A, L_2, L_5, /*hidden argument*/NULL);
		return L_6;
	}
}
IL2CPP_EXTERN_C  String_t* int2_ToString_m04651E132A626D5DDED8BCF33FB65768602FB655_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558 * _thisAdjusted = reinterpret_cast<int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558 *>(__this + _offset);
	String_t* _returnValue;
	_returnValue = int2_ToString_m04651E132A626D5DDED8BCF33FB65768602FB655_inline(_thisAdjusted, method);
	return _returnValue;
}
// System.String Unity.Mathematics.int2::ToString(System.String,System.IFormatProvider)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* int2_ToString_mBE1C05766EA0EE72C974AB8D78FBB0FFE747E1AC (int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558 * __this, String_t* ___format0, RuntimeObject* ___formatProvider1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral039B19E6A63E9AA22F1AF2817559D285768A7B4A);
		s_Il2CppMethodInitialized = true;
	}
	{
		// return string.Format("int2({0}, {1})", x.ToString(format, formatProvider), y.ToString(format, formatProvider));
		int32_t* L_0 = __this->get_address_of_x_0();
		String_t* L_1 = ___format0;
		RuntimeObject* L_2 = ___formatProvider1;
		String_t* L_3;
		L_3 = Int32_ToString_m246774E1922012AE787EB97743F42CB798B70CD8((int32_t*)L_0, L_1, L_2, /*hidden argument*/NULL);
		int32_t* L_4 = __this->get_address_of_y_1();
		String_t* L_5 = ___format0;
		RuntimeObject* L_6 = ___formatProvider1;
		String_t* L_7;
		L_7 = Int32_ToString_m246774E1922012AE787EB97743F42CB798B70CD8((int32_t*)L_4, L_5, L_6, /*hidden argument*/NULL);
		String_t* L_8;
		L_8 = String_Format_m8D1CB0410C35E052A53AE957C914C841E54BAB66(_stringLiteral039B19E6A63E9AA22F1AF2817559D285768A7B4A, L_3, L_7, /*hidden argument*/NULL);
		return L_8;
	}
}
IL2CPP_EXTERN_C  String_t* int2_ToString_mBE1C05766EA0EE72C974AB8D78FBB0FFE747E1AC_AdjustorThunk (RuntimeObject * __this, String_t* ___format0, RuntimeObject* ___formatProvider1, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558 * _thisAdjusted = reinterpret_cast<int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558 *>(__this + _offset);
	String_t* _returnValue;
	_returnValue = int2_ToString_mBE1C05766EA0EE72C974AB8D78FBB0FFE747E1AC_inline(_thisAdjusted, ___format0, ___formatProvider1, method);
	return _returnValue;
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Unity.Mathematics.float2 Unity.Mathematics.math::float2(System.Single,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float2_t11F5F2974404951113DDC4E13EEB6E2456295547  math_float2_mB67FFC2F70C70410B564621543211FA6172F549F (float ___x0, float ___y1, const RuntimeMethod* method)
{
	{
		// public static float2 float2(float x, float y) { return new float2(x, y); }
		float L_0 = ___x0;
		float L_1 = ___y1;
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_2;
		memset((&L_2), 0, sizeof(L_2));
		float2__ctor_mA85C140C72CD3A1E8F287AEC7FF12A35C85C819C_inline((&L_2), L_0, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.UInt32 Unity.Mathematics.math::hash(Unity.Mathematics.float2)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t math_hash_m0214B7050F1399AD283DFF8CB115A65E0B95E1BA (float2_t11F5F2974404951113DDC4E13EEB6E2456295547  ___v0, const RuntimeMethod* method)
{
	{
		// return csum(asuint(v) * uint2(0xFA3A3285u, 0xAD55999Du)) + 0xDCDD5341u;
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_0 = ___v0;
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_1;
		L_1 = math_asuint_mADD3FB6B29BD406CC3254B1DE3776D5B92F7B161_inline(L_0, /*hidden argument*/NULL);
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_2;
		L_2 = math_uint2_mF2E830E0F3E660D4E640F5EF5D5A3FCA75378D01_inline(((int32_t)-96849275), ((int32_t)-1386899043), /*hidden argument*/NULL);
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_3;
		L_3 = uint2_op_Multiply_m7636391131B0EDC9918A5772AD85C68109F2235F_inline(L_1, L_2, /*hidden argument*/NULL);
		uint32_t L_4;
		L_4 = math_csum_m27D50739B96EE2F2DEA2EABD207F2B827F87E232_inline(L_3, /*hidden argument*/NULL);
		return ((int32_t)il2cpp_codegen_add((int32_t)L_4, (int32_t)((int32_t)-589475007)));
	}
}
// System.UInt32 Unity.Mathematics.math::hash(Unity.Mathematics.float3)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t math_hash_m7B43A24382293202DAB3DF5C3953BE904664205B (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___v0, const RuntimeMethod* method)
{
	{
		// return csum(asuint(v) * uint3(0x9B13B92Du, 0x4ABF0813u, 0x86068063u)) + 0xD75513F9u;
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_0 = ___v0;
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_1;
		L_1 = math_asuint_m391E0BC4333E70109D0AC31DBAB8693A082791A7_inline(L_0, /*hidden argument*/NULL);
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_2;
		L_2 = math_uint3_mCA0FF72ACE1A3319B3E19C41638C710CCFC56A68_inline(((int32_t)-1693206227), ((int32_t)1254033427), ((int32_t)-2046394269), /*hidden argument*/NULL);
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_3;
		L_3 = uint3_op_Multiply_mBF3B660B4057B2D4ACD4B6B3DDDC4E747A6C8877_inline(L_1, L_2, /*hidden argument*/NULL);
		uint32_t L_4;
		L_4 = math_csum_m60444A45FBA529E9ED20646FA61559F4B53D96ED_inline(L_3, /*hidden argument*/NULL);
		return ((int32_t)il2cpp_codegen_add((int32_t)L_4, (int32_t)((int32_t)-682290183)));
	}
}
// System.UInt32 Unity.Mathematics.math::hash(Unity.Mathematics.float4)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t math_hash_m53A15DB25196562BA8CF64481E3F9B4995AE75F7 (float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  ___v0, const RuntimeMethod* method)
{
	{
		// return csum(asuint(v) * uint4(0xE69626FFu, 0xBD010EEBu, 0x9CEDE1D1u, 0x43BE0B51u)) + 0xAF836EE1u;
		float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  L_0 = ___v0;
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_1;
		L_1 = math_asuint_m3D2A8007FE91051287F5761C654CD4E7F4B669CB_inline(L_0, /*hidden argument*/NULL);
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_2;
		L_2 = math_uint4_m2AAC3E9468B39F889CA506EF27BAD9E428C6E15D_inline(((int32_t)-426367233), ((int32_t)-1124004117), ((int32_t)-1662131759), ((int32_t)1136528209), /*hidden argument*/NULL);
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_3;
		L_3 = uint4_op_Multiply_m27352F838EE80439EE98A136D8D246AF5E9EF681_inline(L_1, L_2, /*hidden argument*/NULL);
		uint32_t L_4;
		L_4 = math_csum_m6A08B2FBD9E51F2CC9984B12285CEB4B188B2A35_inline(L_3, /*hidden argument*/NULL);
		return ((int32_t)il2cpp_codegen_add((int32_t)L_4, (int32_t)((int32_t)-1350340895)));
	}
}
// System.UInt32 Unity.Mathematics.math::hash(Unity.Mathematics.int2)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t math_hash_m23BB2E45EEDF0493DF3AD90AC3837C34A70FE471 (int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558  ___v0, const RuntimeMethod* method)
{
	{
		// return csum(asuint(v) * uint2(0x83B58237u, 0x833E3E29u)) + 0xA9D919BFu;
		int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558  L_0 = ___v0;
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_1;
		L_1 = math_asuint_mA2C4FDC7E23CDB70403D11B606D2ED33B4A6551D_inline(L_0, /*hidden argument*/NULL);
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_2;
		L_2 = math_uint2_mF2E830E0F3E660D4E640F5EF5D5A3FCA75378D01_inline(((int32_t)-2085256649), ((int32_t)-2093072855), /*hidden argument*/NULL);
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_3;
		L_3 = uint2_op_Multiply_m7636391131B0EDC9918A5772AD85C68109F2235F_inline(L_1, L_2, /*hidden argument*/NULL);
		uint32_t L_4;
		L_4 = math_csum_m27D50739B96EE2F2DEA2EABD207F2B827F87E232_inline(L_3, /*hidden argument*/NULL);
		return ((int32_t)il2cpp_codegen_add((int32_t)L_4, (int32_t)((int32_t)-1445389889)));
	}
}
// System.Int32 Unity.Mathematics.math::asint(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t math_asint_mA58A5DFF25FB3AF5A3D8705D6BA70B916A2E41E7 (float ___x0, const RuntimeMethod* method)
{
	IntFloatUnion_t3B42C127ECCA706E64B5C2B9EE370A632FC83548  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		// u.intValue = 0;
		(&V_0)->set_intValue_0(0);
		// u.floatValue = x;
		float L_0 = ___x0;
		(&V_0)->set_floatValue_1(L_0);
		// return u.intValue;
		IntFloatUnion_t3B42C127ECCA706E64B5C2B9EE370A632FC83548  L_1 = V_0;
		int32_t L_2 = L_1.get_intValue_0();
		return L_2;
	}
}
// Unity.Mathematics.uint2 Unity.Mathematics.math::asuint(Unity.Mathematics.int2)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  math_asuint_mA2C4FDC7E23CDB70403D11B606D2ED33B4A6551D (int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558  ___x0, const RuntimeMethod* method)
{
	{
		// public static uint2 asuint(int2 x) { return uint2((uint)x.x, (uint)x.y); }
		int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558  L_0 = ___x0;
		int32_t L_1 = L_0.get_x_0();
		int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558  L_2 = ___x0;
		int32_t L_3 = L_2.get_y_1();
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_4;
		L_4 = math_uint2_mF2E830E0F3E660D4E640F5EF5D5A3FCA75378D01_inline(L_1, L_3, /*hidden argument*/NULL);
		return L_4;
	}
}
// System.UInt32 Unity.Mathematics.math::asuint(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t math_asuint_m5C798CD94D48BA6240ECBB5EFDAD2D565ECDDEE6 (float ___x0, const RuntimeMethod* method)
{
	{
		// public static uint asuint(float x) { return (uint)asint(x); }
		float L_0 = ___x0;
		int32_t L_1;
		L_1 = math_asint_mA58A5DFF25FB3AF5A3D8705D6BA70B916A2E41E7_inline(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// Unity.Mathematics.uint2 Unity.Mathematics.math::asuint(Unity.Mathematics.float2)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  math_asuint_mADD3FB6B29BD406CC3254B1DE3776D5B92F7B161 (float2_t11F5F2974404951113DDC4E13EEB6E2456295547  ___x0, const RuntimeMethod* method)
{
	{
		// public static uint2 asuint(float2 x) { return uint2(asuint(x.x), asuint(x.y)); }
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_0 = ___x0;
		float L_1 = L_0.get_x_0();
		uint32_t L_2;
		L_2 = math_asuint_m5C798CD94D48BA6240ECBB5EFDAD2D565ECDDEE6_inline(L_1, /*hidden argument*/NULL);
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_3 = ___x0;
		float L_4 = L_3.get_y_1();
		uint32_t L_5;
		L_5 = math_asuint_m5C798CD94D48BA6240ECBB5EFDAD2D565ECDDEE6_inline(L_4, /*hidden argument*/NULL);
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_6;
		L_6 = math_uint2_mF2E830E0F3E660D4E640F5EF5D5A3FCA75378D01_inline(L_2, L_5, /*hidden argument*/NULL);
		return L_6;
	}
}
// Unity.Mathematics.uint3 Unity.Mathematics.math::asuint(Unity.Mathematics.float3)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  math_asuint_m391E0BC4333E70109D0AC31DBAB8693A082791A7 (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___x0, const RuntimeMethod* method)
{
	{
		// public static uint3 asuint(float3 x) { return uint3(asuint(x.x), asuint(x.y), asuint(x.z)); }
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_0 = ___x0;
		float L_1 = L_0.get_x_0();
		uint32_t L_2;
		L_2 = math_asuint_m5C798CD94D48BA6240ECBB5EFDAD2D565ECDDEE6_inline(L_1, /*hidden argument*/NULL);
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_3 = ___x0;
		float L_4 = L_3.get_y_1();
		uint32_t L_5;
		L_5 = math_asuint_m5C798CD94D48BA6240ECBB5EFDAD2D565ECDDEE6_inline(L_4, /*hidden argument*/NULL);
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_6 = ___x0;
		float L_7 = L_6.get_z_2();
		uint32_t L_8;
		L_8 = math_asuint_m5C798CD94D48BA6240ECBB5EFDAD2D565ECDDEE6_inline(L_7, /*hidden argument*/NULL);
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_9;
		L_9 = math_uint3_mCA0FF72ACE1A3319B3E19C41638C710CCFC56A68_inline(L_2, L_5, L_8, /*hidden argument*/NULL);
		return L_9;
	}
}
// Unity.Mathematics.uint4 Unity.Mathematics.math::asuint(Unity.Mathematics.float4)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  math_asuint_m3D2A8007FE91051287F5761C654CD4E7F4B669CB (float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  ___x0, const RuntimeMethod* method)
{
	{
		// public static uint4 asuint(float4 x) { return uint4(asuint(x.x), asuint(x.y), asuint(x.z), asuint(x.w)); }
		float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  L_0 = ___x0;
		float L_1 = L_0.get_x_0();
		uint32_t L_2;
		L_2 = math_asuint_m5C798CD94D48BA6240ECBB5EFDAD2D565ECDDEE6_inline(L_1, /*hidden argument*/NULL);
		float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  L_3 = ___x0;
		float L_4 = L_3.get_y_1();
		uint32_t L_5;
		L_5 = math_asuint_m5C798CD94D48BA6240ECBB5EFDAD2D565ECDDEE6_inline(L_4, /*hidden argument*/NULL);
		float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  L_6 = ___x0;
		float L_7 = L_6.get_z_2();
		uint32_t L_8;
		L_8 = math_asuint_m5C798CD94D48BA6240ECBB5EFDAD2D565ECDDEE6_inline(L_7, /*hidden argument*/NULL);
		float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  L_9 = ___x0;
		float L_10 = L_9.get_w_3();
		uint32_t L_11;
		L_11 = math_asuint_m5C798CD94D48BA6240ECBB5EFDAD2D565ECDDEE6_inline(L_10, /*hidden argument*/NULL);
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_12;
		L_12 = math_uint4_m2AAC3E9468B39F889CA506EF27BAD9E428C6E15D_inline(L_2, L_5, L_8, L_11, /*hidden argument*/NULL);
		return L_12;
	}
}
// System.Single Unity.Mathematics.math::asfloat(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float math_asfloat_m0F490C819C7F72ECFEA9B6079E690C72ED5028ED (int32_t ___x0, const RuntimeMethod* method)
{
	IntFloatUnion_t3B42C127ECCA706E64B5C2B9EE370A632FC83548  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		// u.floatValue = 0;
		(&V_0)->set_floatValue_1((0.0f));
		// u.intValue = x;
		int32_t L_0 = ___x0;
		(&V_0)->set_intValue_0(L_0);
		// return u.floatValue;
		IntFloatUnion_t3B42C127ECCA706E64B5C2B9EE370A632FC83548  L_1 = V_0;
		float L_2 = L_1.get_floatValue_1();
		return L_2;
	}
}
// System.Single Unity.Mathematics.math::asfloat(System.UInt32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float math_asfloat_m10F84A2A94E30A6EA7D23F9FCDBCDDB709328684 (uint32_t ___x0, const RuntimeMethod* method)
{
	{
		// public static float  asfloat(uint x) { return asfloat((int)x); }
		uint32_t L_0 = ___x0;
		float L_1;
		L_1 = math_asfloat_m0F490C819C7F72ECFEA9B6079E690C72ED5028ED_inline(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// Unity.Mathematics.float2 Unity.Mathematics.math::asfloat(Unity.Mathematics.uint2)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float2_t11F5F2974404951113DDC4E13EEB6E2456295547  math_asfloat_m56FF653BF60DF76D1E13AF495440DF5EB57CFA6E (uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  ___x0, const RuntimeMethod* method)
{
	{
		// public static float2 asfloat(uint2 x) { return float2(asfloat(x.x), asfloat(x.y)); }
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_0 = ___x0;
		uint32_t L_1 = L_0.get_x_0();
		float L_2;
		L_2 = math_asfloat_m10F84A2A94E30A6EA7D23F9FCDBCDDB709328684_inline(L_1, /*hidden argument*/NULL);
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_3 = ___x0;
		uint32_t L_4 = L_3.get_y_1();
		float L_5;
		L_5 = math_asfloat_m10F84A2A94E30A6EA7D23F9FCDBCDDB709328684_inline(L_4, /*hidden argument*/NULL);
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_6;
		L_6 = math_float2_mB67FFC2F70C70410B564621543211FA6172F549F_inline(L_2, L_5, /*hidden argument*/NULL);
		return L_6;
	}
}
// System.Int32 Unity.Mathematics.math::min(System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t math_min_m44D70D51DA7252B2D252DCCF7D8321B81AACBB27 (int32_t ___x0, int32_t ___y1, const RuntimeMethod* method)
{
	{
		// public static int min(int x, int y) { return x < y ? x : y; }
		int32_t L_0 = ___x0;
		int32_t L_1 = ___y1;
		if ((((int32_t)L_0) < ((int32_t)L_1)))
		{
			goto IL_0006;
		}
	}
	{
		int32_t L_2 = ___y1;
		return L_2;
	}

IL_0006:
	{
		int32_t L_3 = ___x0;
		return L_3;
	}
}
// System.Single Unity.Mathematics.math::min(System.Single,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float math_min_m39054317B5C9E28B04360370E05713632A3B544F (float ___x0, float ___y1, const RuntimeMethod* method)
{
	{
		// public static float min(float x, float y) { return float.IsNaN(y) || x < y ? x : y; }
		float L_0 = ___y1;
		bool L_1;
		L_1 = Single_IsNaN_m458FF076EF1944D4D888A585F7C6C49DA4730599(L_0, /*hidden argument*/NULL);
		if (L_1)
		{
			goto IL_000e;
		}
	}
	{
		float L_2 = ___x0;
		float L_3 = ___y1;
		if ((((float)L_2) < ((float)L_3)))
		{
			goto IL_000e;
		}
	}
	{
		float L_4 = ___y1;
		return L_4;
	}

IL_000e:
	{
		float L_5 = ___x0;
		return L_5;
	}
}
// Unity.Mathematics.float3 Unity.Mathematics.math::min(Unity.Mathematics.float3,Unity.Mathematics.float3)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  math_min_mF326657FAB4548F84D71C5D8AEC52CE8A96FAB46 (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___x0, float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___y1, const RuntimeMethod* method)
{
	{
		// public static float3 min(float3 x, float3 y) { return new float3(min(x.x, y.x), min(x.y, y.y), min(x.z, y.z)); }
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_0 = ___x0;
		float L_1 = L_0.get_x_0();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_2 = ___y1;
		float L_3 = L_2.get_x_0();
		float L_4;
		L_4 = math_min_m39054317B5C9E28B04360370E05713632A3B544F_inline(L_1, L_3, /*hidden argument*/NULL);
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_5 = ___x0;
		float L_6 = L_5.get_y_1();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_7 = ___y1;
		float L_8 = L_7.get_y_1();
		float L_9;
		L_9 = math_min_m39054317B5C9E28B04360370E05713632A3B544F_inline(L_6, L_8, /*hidden argument*/NULL);
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_10 = ___x0;
		float L_11 = L_10.get_z_2();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_12 = ___y1;
		float L_13 = L_12.get_z_2();
		float L_14;
		L_14 = math_min_m39054317B5C9E28B04360370E05713632A3B544F_inline(L_11, L_13, /*hidden argument*/NULL);
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_15;
		memset((&L_15), 0, sizeof(L_15));
		float3__ctor_m853853CCAF2BC58F66EE07DB9338C1644698D483_inline((&L_15), L_4, L_9, L_14, /*hidden argument*/NULL);
		return L_15;
	}
}
// System.Int32 Unity.Mathematics.math::max(System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t math_max_mC8F55A73FE7E0CE042886B3BAC18422AAEA6991C (int32_t ___x0, int32_t ___y1, const RuntimeMethod* method)
{
	{
		// public static int max(int x, int y) { return x > y ? x : y; }
		int32_t L_0 = ___x0;
		int32_t L_1 = ___y1;
		if ((((int32_t)L_0) > ((int32_t)L_1)))
		{
			goto IL_0006;
		}
	}
	{
		int32_t L_2 = ___y1;
		return L_2;
	}

IL_0006:
	{
		int32_t L_3 = ___x0;
		return L_3;
	}
}
// System.Single Unity.Mathematics.math::max(System.Single,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float math_max_m2D9E0840A13662E878067A28926E1A85323E7E25 (float ___x0, float ___y1, const RuntimeMethod* method)
{
	{
		// public static float max(float x, float y) { return float.IsNaN(y) || x > y ? x : y; }
		float L_0 = ___y1;
		bool L_1;
		L_1 = Single_IsNaN_m458FF076EF1944D4D888A585F7C6C49DA4730599(L_0, /*hidden argument*/NULL);
		if (L_1)
		{
			goto IL_000e;
		}
	}
	{
		float L_2 = ___x0;
		float L_3 = ___y1;
		if ((((float)L_2) > ((float)L_3)))
		{
			goto IL_000e;
		}
	}
	{
		float L_4 = ___y1;
		return L_4;
	}

IL_000e:
	{
		float L_5 = ___x0;
		return L_5;
	}
}
// Unity.Mathematics.float3 Unity.Mathematics.math::max(Unity.Mathematics.float3,Unity.Mathematics.float3)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  math_max_m50BE7BF5F177964230090F2B1AF068FAE0D8E721 (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___x0, float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___y1, const RuntimeMethod* method)
{
	{
		// public static float3 max(float3 x, float3 y) { return new float3(max(x.x, y.x), max(x.y, y.y), max(x.z, y.z)); }
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_0 = ___x0;
		float L_1 = L_0.get_x_0();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_2 = ___y1;
		float L_3 = L_2.get_x_0();
		float L_4;
		L_4 = math_max_m2D9E0840A13662E878067A28926E1A85323E7E25_inline(L_1, L_3, /*hidden argument*/NULL);
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_5 = ___x0;
		float L_6 = L_5.get_y_1();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_7 = ___y1;
		float L_8 = L_7.get_y_1();
		float L_9;
		L_9 = math_max_m2D9E0840A13662E878067A28926E1A85323E7E25_inline(L_6, L_8, /*hidden argument*/NULL);
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_10 = ___x0;
		float L_11 = L_10.get_z_2();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_12 = ___y1;
		float L_13 = L_12.get_z_2();
		float L_14;
		L_14 = math_max_m2D9E0840A13662E878067A28926E1A85323E7E25_inline(L_11, L_13, /*hidden argument*/NULL);
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_15;
		memset((&L_15), 0, sizeof(L_15));
		float3__ctor_m853853CCAF2BC58F66EE07DB9338C1644698D483_inline((&L_15), L_4, L_9, L_14, /*hidden argument*/NULL);
		return L_15;
	}
}
// System.Single Unity.Mathematics.math::lerp(System.Single,System.Single,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float math_lerp_mBA0045ACE36062154DC9AB84CE39B9D3342A9796 (float ___x0, float ___y1, float ___s2, const RuntimeMethod* method)
{
	{
		// public static float lerp(float x, float y, float s) { return x + s * (y - x); }
		float L_0 = ___x0;
		float L_1 = ___s2;
		float L_2 = ___y1;
		float L_3 = ___x0;
		return ((float)il2cpp_codegen_add((float)L_0, (float)((float)il2cpp_codegen_multiply((float)L_1, (float)((float)il2cpp_codegen_subtract((float)L_2, (float)L_3))))));
	}
}
// System.Single Unity.Mathematics.math::clamp(System.Single,System.Single,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float math_clamp_m0144AE0AC721F20699C3219C530DB7EE07F358EB (float ___x0, float ___a1, float ___b2, const RuntimeMethod* method)
{
	{
		// public static float clamp(float x, float a, float b) { return max(a, min(b, x)); }
		float L_0 = ___a1;
		float L_1 = ___b2;
		float L_2 = ___x0;
		float L_3;
		L_3 = math_min_m39054317B5C9E28B04360370E05713632A3B544F_inline(L_1, L_2, /*hidden argument*/NULL);
		float L_4;
		L_4 = math_max_m2D9E0840A13662E878067A28926E1A85323E7E25_inline(L_0, L_3, /*hidden argument*/NULL);
		return L_4;
	}
}
// Unity.Mathematics.float2 Unity.Mathematics.math::abs(Unity.Mathematics.float2)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float2_t11F5F2974404951113DDC4E13EEB6E2456295547  math_abs_m7A4AED4CFD507FBCE527A578B2E391A09649CD93 (float2_t11F5F2974404951113DDC4E13EEB6E2456295547  ___x0, const RuntimeMethod* method)
{
	{
		// public static float2 abs(float2 x) { return asfloat(asuint(x) & 0x7FFFFFFF); }
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_0 = ___x0;
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_1;
		L_1 = math_asuint_mADD3FB6B29BD406CC3254B1DE3776D5B92F7B161_inline(L_0, /*hidden argument*/NULL);
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_2;
		L_2 = uint2_op_BitwiseAnd_mB0E2C747CA4063432C69AFBC68BB4EC28B2815C2_inline(L_1, ((int32_t)2147483647LL), /*hidden argument*/NULL);
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_3;
		L_3 = math_asfloat_m56FF653BF60DF76D1E13AF495440DF5EB57CFA6E_inline(L_2, /*hidden argument*/NULL);
		return L_3;
	}
}
// System.Single Unity.Mathematics.math::dot(Unity.Mathematics.float2,Unity.Mathematics.float2)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float math_dot_mF3A96DE35F8C3264D3FD4F70B4090DB3261B168B (float2_t11F5F2974404951113DDC4E13EEB6E2456295547  ___x0, float2_t11F5F2974404951113DDC4E13EEB6E2456295547  ___y1, const RuntimeMethod* method)
{
	{
		// public static float dot(float2 x, float2 y) { return x.x * y.x + x.y * y.y; }
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_0 = ___x0;
		float L_1 = L_0.get_x_0();
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_2 = ___y1;
		float L_3 = L_2.get_x_0();
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_4 = ___x0;
		float L_5 = L_4.get_y_1();
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_6 = ___y1;
		float L_7 = L_6.get_y_1();
		return ((float)il2cpp_codegen_add((float)((float)il2cpp_codegen_multiply((float)L_1, (float)L_3)), (float)((float)il2cpp_codegen_multiply((float)L_5, (float)L_7))));
	}
}
// System.Single Unity.Mathematics.math::dot(Unity.Mathematics.float3,Unity.Mathematics.float3)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float math_dot_m04AB38B7D16991336C8B141B3D59E7C4C6D9D3ED (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___x0, float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___y1, const RuntimeMethod* method)
{
	{
		// public static float dot(float3 x, float3 y) { return x.x * y.x + x.y * y.y + x.z * y.z; }
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_0 = ___x0;
		float L_1 = L_0.get_x_0();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_2 = ___y1;
		float L_3 = L_2.get_x_0();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_4 = ___x0;
		float L_5 = L_4.get_y_1();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_6 = ___y1;
		float L_7 = L_6.get_y_1();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_8 = ___x0;
		float L_9 = L_8.get_z_2();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_10 = ___y1;
		float L_11 = L_10.get_z_2();
		return ((float)il2cpp_codegen_add((float)((float)il2cpp_codegen_add((float)((float)il2cpp_codegen_multiply((float)L_1, (float)L_3)), (float)((float)il2cpp_codegen_multiply((float)L_5, (float)L_7)))), (float)((float)il2cpp_codegen_multiply((float)L_9, (float)L_11))));
	}
}
// System.Single Unity.Mathematics.math::cos(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float math_cos_m5B49E7388CF7E6259D91E6F8A48050DCE12FEF6D (float ___x0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Math_tA269614262430118C9FC5C4D9EF4F61C812568F0_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// public static float cos(float x) { return (float)System.Math.Cos(x); }
		float L_0 = ___x0;
		IL2CPP_RUNTIME_CLASS_INIT(Math_tA269614262430118C9FC5C4D9EF4F61C812568F0_il2cpp_TypeInfo_var);
		double L_1;
		L_1 = cos(((double)((double)L_0)));
		return ((float)((float)L_1));
	}
}
// System.Single Unity.Mathematics.math::sin(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float math_sin_m4990971352F2652AB79C4F84B25FC73F6CF266A9 (float ___x0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Math_tA269614262430118C9FC5C4D9EF4F61C812568F0_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// public static float sin(float x) { return (float)System.Math.Sin((float)x); }
		float L_0 = ___x0;
		IL2CPP_RUNTIME_CLASS_INIT(Math_tA269614262430118C9FC5C4D9EF4F61C812568F0_il2cpp_TypeInfo_var);
		double L_1;
		L_1 = sin(((double)((double)((float)((float)L_0)))));
		return ((float)((float)L_1));
	}
}
// System.Single Unity.Mathematics.math::sqrt(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float math_sqrt_m4FD392CA865BFABB6645F3AE365F5FBA2F2F40F6 (float ___x0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Math_tA269614262430118C9FC5C4D9EF4F61C812568F0_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// public static float sqrt(float x) { return (float)System.Math.Sqrt((float)x); }
		float L_0 = ___x0;
		IL2CPP_RUNTIME_CLASS_INIT(Math_tA269614262430118C9FC5C4D9EF4F61C812568F0_il2cpp_TypeInfo_var);
		double L_1;
		L_1 = sqrt(((double)((double)((float)((float)L_0)))));
		return ((float)((float)L_1));
	}
}
// System.Single Unity.Mathematics.math::rsqrt(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float math_rsqrt_m4A5597C29F30C68AF6855620522D41CB739F9F80 (float ___x0, const RuntimeMethod* method)
{
	{
		// public static float rsqrt(float x) { return 1.0f / sqrt(x); }
		float L_0 = ___x0;
		float L_1;
		L_1 = math_sqrt_m4FD392CA865BFABB6645F3AE365F5FBA2F2F40F6(L_0, /*hidden argument*/NULL);
		return ((float)((float)(1.0f)/(float)L_1));
	}
}
// Unity.Mathematics.float2 Unity.Mathematics.math::normalize(Unity.Mathematics.float2)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float2_t11F5F2974404951113DDC4E13EEB6E2456295547  math_normalize_m4D2F9902A369AE71138B5F484D59523731405504 (float2_t11F5F2974404951113DDC4E13EEB6E2456295547  ___x0, const RuntimeMethod* method)
{
	{
		// public static float2 normalize(float2 x) { return rsqrt(dot(x, x)) * x; }
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_0 = ___x0;
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_1 = ___x0;
		float L_2;
		L_2 = math_dot_mF3A96DE35F8C3264D3FD4F70B4090DB3261B168B_inline(L_0, L_1, /*hidden argument*/NULL);
		float L_3;
		L_3 = math_rsqrt_m4A5597C29F30C68AF6855620522D41CB739F9F80_inline(L_2, /*hidden argument*/NULL);
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_4 = ___x0;
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_5;
		L_5 = float2_op_Multiply_m07CB14BD054267E48BF40992AD4A341FAF0A21ED_inline(L_3, L_4, /*hidden argument*/NULL);
		return L_5;
	}
}
// Unity.Mathematics.float3 Unity.Mathematics.math::normalize(Unity.Mathematics.float3)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  math_normalize_mBA3DA53965616FB682EA668C724337F12E5E53CC (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___x0, const RuntimeMethod* method)
{
	{
		// public static float3 normalize(float3 x) { return rsqrt(dot(x, x)) * x; }
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_0 = ___x0;
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_1 = ___x0;
		float L_2;
		L_2 = math_dot_m04AB38B7D16991336C8B141B3D59E7C4C6D9D3ED_inline(L_0, L_1, /*hidden argument*/NULL);
		float L_3;
		L_3 = math_rsqrt_m4A5597C29F30C68AF6855620522D41CB739F9F80_inline(L_2, /*hidden argument*/NULL);
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_4 = ___x0;
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_5;
		L_5 = float3_op_Multiply_m66E0DDABA7E629CCCEFC6407B038D6FD42E1A1B0_inline(L_3, L_4, /*hidden argument*/NULL);
		return L_5;
	}
}
// System.Single Unity.Mathematics.math::length(Unity.Mathematics.float3)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float math_length_mCE2FBC3AAD338B3CB3992ECDC93CE8E017CBB55C (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___x0, const RuntimeMethod* method)
{
	{
		// public static float length(float3 x) { return sqrt(dot(x, x)); }
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_0 = ___x0;
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_1 = ___x0;
		float L_2;
		L_2 = math_dot_m04AB38B7D16991336C8B141B3D59E7C4C6D9D3ED_inline(L_0, L_1, /*hidden argument*/NULL);
		float L_3;
		L_3 = math_sqrt_m4FD392CA865BFABB6645F3AE365F5FBA2F2F40F6(L_2, /*hidden argument*/NULL);
		return L_3;
	}
}
// Unity.Mathematics.float3 Unity.Mathematics.math::cross(Unity.Mathematics.float3,Unity.Mathematics.float3)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  math_cross_mABF143F9B2689698D6755111E565815A612D0EA7 (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___x0, float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___y1, const RuntimeMethod* method)
{
	float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		// public static float3 cross(float3 x, float3 y) { return (x * y.yzx - x.yzx * y).yzx; }
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_0 = ___x0;
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_1;
		L_1 = float3_get_yzx_mAE305D9ABE33A40967A3BEECAF5E8CA1E66B2D6B_inline((float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D *)(&___y1), /*hidden argument*/NULL);
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_2;
		L_2 = float3_op_Multiply_m296B37BB82979715ED4A076EBE7BE72F83C56CD7_inline(L_0, L_1, /*hidden argument*/NULL);
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_3;
		L_3 = float3_get_yzx_mAE305D9ABE33A40967A3BEECAF5E8CA1E66B2D6B_inline((float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D *)(&___x0), /*hidden argument*/NULL);
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_4 = ___y1;
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_5;
		L_5 = float3_op_Multiply_m296B37BB82979715ED4A076EBE7BE72F83C56CD7_inline(L_3, L_4, /*hidden argument*/NULL);
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_6;
		L_6 = float3_op_Subtraction_mB3250D4D18B21370A6FEA3B2B527CFA7B6DE439D_inline(L_2, L_5, /*hidden argument*/NULL);
		V_0 = L_6;
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_7;
		L_7 = float3_get_yzx_mAE305D9ABE33A40967A3BEECAF5E8CA1E66B2D6B_inline((float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D *)(&V_0), /*hidden argument*/NULL);
		return L_7;
	}
}
// System.UInt32 Unity.Mathematics.math::select(System.UInt32,System.UInt32,System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t math_select_mC2B82C9C2631A062EC8A1281D39D142D6AB73AF0 (uint32_t ___a0, uint32_t ___b1, bool ___c2, const RuntimeMethod* method)
{
	{
		// public static uint select(uint a, uint b, bool c) { return c ? b : a; }
		bool L_0 = ___c2;
		if (L_0)
		{
			goto IL_0005;
		}
	}
	{
		uint32_t L_1 = ___a0;
		return L_1;
	}

IL_0005:
	{
		uint32_t L_2 = ___b1;
		return L_2;
	}
}
// System.Single Unity.Mathematics.math::radians(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float math_radians_mD9A2D9494B737ED3777B00BA53D3D1A99BEAE319 (float ___x0, const RuntimeMethod* method)
{
	{
		// public static float radians(float x) { return x * 0.0174532925f; }
		float L_0 = ___x0;
		return ((float)il2cpp_codegen_multiply((float)L_0, (float)(0.0174532924f)));
	}
}
// System.UInt32 Unity.Mathematics.math::csum(Unity.Mathematics.uint2)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t math_csum_m27D50739B96EE2F2DEA2EABD207F2B827F87E232 (uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  ___x0, const RuntimeMethod* method)
{
	{
		// public static uint csum(uint2 x) { return x.x + x.y; }
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_0 = ___x0;
		uint32_t L_1 = L_0.get_x_0();
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_2 = ___x0;
		uint32_t L_3 = L_2.get_y_1();
		return ((int32_t)il2cpp_codegen_add((int32_t)L_1, (int32_t)L_3));
	}
}
// System.UInt32 Unity.Mathematics.math::csum(Unity.Mathematics.uint3)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t math_csum_m60444A45FBA529E9ED20646FA61559F4B53D96ED (uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  ___x0, const RuntimeMethod* method)
{
	{
		// public static uint csum(uint3 x) { return x.x + x.y + x.z; }
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_0 = ___x0;
		uint32_t L_1 = L_0.get_x_0();
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_2 = ___x0;
		uint32_t L_3 = L_2.get_y_1();
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_4 = ___x0;
		uint32_t L_5 = L_4.get_z_2();
		return ((int32_t)il2cpp_codegen_add((int32_t)((int32_t)il2cpp_codegen_add((int32_t)L_1, (int32_t)L_3)), (int32_t)L_5));
	}
}
// System.UInt32 Unity.Mathematics.math::csum(Unity.Mathematics.uint4)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t math_csum_m6A08B2FBD9E51F2CC9984B12285CEB4B188B2A35 (uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  ___x0, const RuntimeMethod* method)
{
	{
		// public static uint csum(uint4 x) { return x.x + x.y + x.z + x.w; }
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_0 = ___x0;
		uint32_t L_1 = L_0.get_x_0();
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_2 = ___x0;
		uint32_t L_3 = L_2.get_y_1();
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_4 = ___x0;
		uint32_t L_5 = L_4.get_z_2();
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_6 = ___x0;
		uint32_t L_7 = L_6.get_w_3();
		return ((int32_t)il2cpp_codegen_add((int32_t)((int32_t)il2cpp_codegen_add((int32_t)((int32_t)il2cpp_codegen_add((int32_t)L_1, (int32_t)L_3)), (int32_t)L_5)), (int32_t)L_7));
	}
}
// Unity.Mathematics.uint2 Unity.Mathematics.math::uint2(System.UInt32,System.UInt32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  math_uint2_mF2E830E0F3E660D4E640F5EF5D5A3FCA75378D01 (uint32_t ___x0, uint32_t ___y1, const RuntimeMethod* method)
{
	{
		// public static uint2 uint2(uint x, uint y) { return new uint2(x, y); }
		uint32_t L_0 = ___x0;
		uint32_t L_1 = ___y1;
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_2;
		memset((&L_2), 0, sizeof(L_2));
		uint2__ctor_m73EC9E1A714B67A555B594981E100729750DCE96_inline((&L_2), L_0, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.UInt32 Unity.Mathematics.math::hash(Unity.Mathematics.uint2)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t math_hash_m0A5EC4565F35FF66EB626E43BFE5C30853603652 (uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  ___v0, const RuntimeMethod* method)
{
	{
		// return csum(v * uint2(0x4473BBB1u, 0xCBA11D5Fu)) + 0x685835CFu;
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_0 = ___v0;
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_1;
		L_1 = math_uint2_mF2E830E0F3E660D4E640F5EF5D5A3FCA75378D01_inline(((int32_t)1148435377), ((int32_t)-878633633), /*hidden argument*/NULL);
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_2;
		L_2 = uint2_op_Multiply_m7636391131B0EDC9918A5772AD85C68109F2235F_inline(L_0, L_1, /*hidden argument*/NULL);
		uint32_t L_3;
		L_3 = math_csum_m27D50739B96EE2F2DEA2EABD207F2B827F87E232_inline(L_2, /*hidden argument*/NULL);
		return ((int32_t)il2cpp_codegen_add((int32_t)L_3, (int32_t)((int32_t)1750611407)));
	}
}
// Unity.Mathematics.uint3 Unity.Mathematics.math::uint3(System.UInt32,System.UInt32,System.UInt32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  math_uint3_mCA0FF72ACE1A3319B3E19C41638C710CCFC56A68 (uint32_t ___x0, uint32_t ___y1, uint32_t ___z2, const RuntimeMethod* method)
{
	{
		// public static uint3 uint3(uint x, uint y, uint z) { return new uint3(x, y, z); }
		uint32_t L_0 = ___x0;
		uint32_t L_1 = ___y1;
		uint32_t L_2 = ___z2;
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_3;
		memset((&L_3), 0, sizeof(L_3));
		uint3__ctor_m3B61A70D37EB10BE4F26625A9BBB52466AE9ECE3_inline((&L_3), L_0, L_1, L_2, /*hidden argument*/NULL);
		return L_3;
	}
}
// System.UInt32 Unity.Mathematics.math::hash(Unity.Mathematics.uint3)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t math_hash_m8C856AA564098835DF61AF436DD3D70B51C34C56 (uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  ___v0, const RuntimeMethod* method)
{
	{
		// return csum(v * uint3(0xCD266C89u, 0xF1852A33u, 0x77E35E77u)) + 0x863E3729u;
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_0 = ___v0;
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_1;
		L_1 = math_uint3_mCA0FF72ACE1A3319B3E19C41638C710CCFC56A68_inline(((int32_t)-853119863), ((int32_t)-242931149), ((int32_t)2011389559), /*hidden argument*/NULL);
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_2;
		L_2 = uint3_op_Multiply_mBF3B660B4057B2D4ACD4B6B3DDDC4E747A6C8877_inline(L_0, L_1, /*hidden argument*/NULL);
		uint32_t L_3;
		L_3 = math_csum_m60444A45FBA529E9ED20646FA61559F4B53D96ED_inline(L_2, /*hidden argument*/NULL);
		return ((int32_t)il2cpp_codegen_add((int32_t)L_3, (int32_t)((int32_t)-2042742999)));
	}
}
// Unity.Mathematics.uint4 Unity.Mathematics.math::uint4(System.UInt32,System.UInt32,System.UInt32,System.UInt32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  math_uint4_m2AAC3E9468B39F889CA506EF27BAD9E428C6E15D (uint32_t ___x0, uint32_t ___y1, uint32_t ___z2, uint32_t ___w3, const RuntimeMethod* method)
{
	{
		// public static uint4 uint4(uint x, uint y, uint z, uint w) { return new uint4(x, y, z, w); }
		uint32_t L_0 = ___x0;
		uint32_t L_1 = ___y1;
		uint32_t L_2 = ___z2;
		uint32_t L_3 = ___w3;
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_4;
		memset((&L_4), 0, sizeof(L_4));
		uint4__ctor_m542805076C6C9E3A87DC3242D32E60C4347439E8_inline((&L_4), L_0, L_1, L_2, L_3, /*hidden argument*/NULL);
		return L_4;
	}
}
// System.UInt32 Unity.Mathematics.math::hash(Unity.Mathematics.uint4)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t math_hash_m75BFBA2E7EB5F1542B66C31F5CC1F398EFBF697E (uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  ___v0, const RuntimeMethod* method)
{
	{
		// return csum(v * uint4(0xB492BF15u, 0xD37220E3u, 0x7AA2C2BDu, 0xE16BC89Du)) + 0x7AA07CD3u;
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_0 = ___v0;
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_1;
		L_1 = math_uint4_m2AAC3E9468B39F889CA506EF27BAD9E428C6E15D_inline(((int32_t)-1265451243), ((int32_t)-747495197), ((int32_t)2057487037), ((int32_t)-513029987), /*hidden argument*/NULL);
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_2;
		L_2 = uint4_op_Multiply_m27352F838EE80439EE98A136D8D246AF5E9EF681_inline(L_0, L_1, /*hidden argument*/NULL);
		uint32_t L_3;
		L_3 = math_csum_m6A08B2FBD9E51F2CC9984B12285CEB4B188B2A35_inline(L_2, /*hidden argument*/NULL);
		return ((int32_t)il2cpp_codegen_add((int32_t)L_3, (int32_t)((int32_t)2057338067)));
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void Unity.Mathematics.uint2::.ctor(System.UInt32,System.UInt32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void uint2__ctor_m73EC9E1A714B67A555B594981E100729750DCE96 (uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A * __this, uint32_t ___x0, uint32_t ___y1, const RuntimeMethod* method)
{
	{
		// this.x = x;
		uint32_t L_0 = ___x0;
		__this->set_x_0(L_0);
		// this.y = y;
		uint32_t L_1 = ___y1;
		__this->set_y_1(L_1);
		// }
		return;
	}
}
IL2CPP_EXTERN_C  void uint2__ctor_m73EC9E1A714B67A555B594981E100729750DCE96_AdjustorThunk (RuntimeObject * __this, uint32_t ___x0, uint32_t ___y1, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A * _thisAdjusted = reinterpret_cast<uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A *>(__this + _offset);
	uint2__ctor_m73EC9E1A714B67A555B594981E100729750DCE96_inline(_thisAdjusted, ___x0, ___y1, method);
}
// Unity.Mathematics.uint2 Unity.Mathematics.uint2::op_Multiply(Unity.Mathematics.uint2,Unity.Mathematics.uint2)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  uint2_op_Multiply_m7636391131B0EDC9918A5772AD85C68109F2235F (uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  ___lhs0, uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  ___rhs1, const RuntimeMethod* method)
{
	{
		// public static uint2 operator * (uint2 lhs, uint2 rhs) { return new uint2 (lhs.x * rhs.x, lhs.y * rhs.y); }
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_0 = ___lhs0;
		uint32_t L_1 = L_0.get_x_0();
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_2 = ___rhs1;
		uint32_t L_3 = L_2.get_x_0();
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_4 = ___lhs0;
		uint32_t L_5 = L_4.get_y_1();
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_6 = ___rhs1;
		uint32_t L_7 = L_6.get_y_1();
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_8;
		memset((&L_8), 0, sizeof(L_8));
		uint2__ctor_m73EC9E1A714B67A555B594981E100729750DCE96_inline((&L_8), ((int32_t)il2cpp_codegen_multiply((int32_t)L_1, (int32_t)L_3)), ((int32_t)il2cpp_codegen_multiply((int32_t)L_5, (int32_t)L_7)), /*hidden argument*/NULL);
		return L_8;
	}
}
// Unity.Mathematics.uint2 Unity.Mathematics.uint2::op_BitwiseAnd(Unity.Mathematics.uint2,System.UInt32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  uint2_op_BitwiseAnd_mB0E2C747CA4063432C69AFBC68BB4EC28B2815C2 (uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  ___lhs0, uint32_t ___rhs1, const RuntimeMethod* method)
{
	{
		// public static uint2 operator & (uint2 lhs, uint rhs) { return new uint2 (lhs.x & rhs, lhs.y & rhs); }
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_0 = ___lhs0;
		uint32_t L_1 = L_0.get_x_0();
		uint32_t L_2 = ___rhs1;
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_3 = ___lhs0;
		uint32_t L_4 = L_3.get_y_1();
		uint32_t L_5 = ___rhs1;
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_6;
		memset((&L_6), 0, sizeof(L_6));
		uint2__ctor_m73EC9E1A714B67A555B594981E100729750DCE96_inline((&L_6), ((int32_t)((int32_t)L_1&(int32_t)L_2)), ((int32_t)((int32_t)L_4&(int32_t)L_5)), /*hidden argument*/NULL);
		return L_6;
	}
}
// System.Boolean Unity.Mathematics.uint2::Equals(Unity.Mathematics.uint2)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool uint2_Equals_m4B2B64A008B39D7386AE19DEDA4AEC83E1C37B36 (uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A * __this, uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  ___rhs0, const RuntimeMethod* method)
{
	{
		// public bool Equals(uint2 rhs) { return x == rhs.x && y == rhs.y; }
		uint32_t L_0 = __this->get_x_0();
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_1 = ___rhs0;
		uint32_t L_2 = L_1.get_x_0();
		if ((!(((uint32_t)L_0) == ((uint32_t)L_2))))
		{
			goto IL_001d;
		}
	}
	{
		uint32_t L_3 = __this->get_y_1();
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_4 = ___rhs0;
		uint32_t L_5 = L_4.get_y_1();
		return (bool)((((int32_t)L_3) == ((int32_t)L_5))? 1 : 0);
	}

IL_001d:
	{
		return (bool)0;
	}
}
IL2CPP_EXTERN_C  bool uint2_Equals_m4B2B64A008B39D7386AE19DEDA4AEC83E1C37B36_AdjustorThunk (RuntimeObject * __this, uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  ___rhs0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A * _thisAdjusted = reinterpret_cast<uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A *>(__this + _offset);
	bool _returnValue;
	_returnValue = uint2_Equals_m4B2B64A008B39D7386AE19DEDA4AEC83E1C37B36_inline(_thisAdjusted, ___rhs0, method);
	return _returnValue;
}
// System.Boolean Unity.Mathematics.uint2::Equals(System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool uint2_Equals_m25297222C97C233F3D316E747165E47F731FBCB6 (uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A * __this, RuntimeObject * ___o0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// public override bool Equals(object o) { return Equals((uint2)o); }
		RuntimeObject * L_0 = ___o0;
		bool L_1;
		L_1 = uint2_Equals_m4B2B64A008B39D7386AE19DEDA4AEC83E1C37B36_inline((uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A *)__this, ((*(uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A *)((uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A *)UnBox(L_0, uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A_il2cpp_TypeInfo_var)))), /*hidden argument*/NULL);
		return L_1;
	}
}
IL2CPP_EXTERN_C  bool uint2_Equals_m25297222C97C233F3D316E747165E47F731FBCB6_AdjustorThunk (RuntimeObject * __this, RuntimeObject * ___o0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A * _thisAdjusted = reinterpret_cast<uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A *>(__this + _offset);
	bool _returnValue;
	_returnValue = uint2_Equals_m25297222C97C233F3D316E747165E47F731FBCB6(_thisAdjusted, ___o0, method);
	return _returnValue;
}
// System.Int32 Unity.Mathematics.uint2::GetHashCode()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t uint2_GetHashCode_m5D6FED071659D7B1E286571116AA379996E21540 (uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A * __this, const RuntimeMethod* method)
{
	{
		// public override int GetHashCode() { return (int)math.hash(this); }
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_0 = (*(uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A *)__this);
		uint32_t L_1;
		L_1 = math_hash_m0A5EC4565F35FF66EB626E43BFE5C30853603652_inline(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
IL2CPP_EXTERN_C  int32_t uint2_GetHashCode_m5D6FED071659D7B1E286571116AA379996E21540_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A * _thisAdjusted = reinterpret_cast<uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A *>(__this + _offset);
	int32_t _returnValue;
	_returnValue = uint2_GetHashCode_m5D6FED071659D7B1E286571116AA379996E21540_inline(_thisAdjusted, method);
	return _returnValue;
}
// System.String Unity.Mathematics.uint2::ToString()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* uint2_ToString_mCAEFE74E44CB92672B2B6AFE042C6796416F18D7 (uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&UInt32_tE60352A06233E4E69DD198BCC67142159F686B15_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralE368123B559BBC0EC2335D3AF9EC37C25C8B5945);
		s_Il2CppMethodInitialized = true;
	}
	{
		// return string.Format("uint2({0}, {1})", x, y);
		uint32_t L_0 = __this->get_x_0();
		uint32_t L_1 = L_0;
		RuntimeObject * L_2 = Box(UInt32_tE60352A06233E4E69DD198BCC67142159F686B15_il2cpp_TypeInfo_var, &L_1);
		uint32_t L_3 = __this->get_y_1();
		uint32_t L_4 = L_3;
		RuntimeObject * L_5 = Box(UInt32_tE60352A06233E4E69DD198BCC67142159F686B15_il2cpp_TypeInfo_var, &L_4);
		String_t* L_6;
		L_6 = String_Format_m8D1CB0410C35E052A53AE957C914C841E54BAB66(_stringLiteralE368123B559BBC0EC2335D3AF9EC37C25C8B5945, L_2, L_5, /*hidden argument*/NULL);
		return L_6;
	}
}
IL2CPP_EXTERN_C  String_t* uint2_ToString_mCAEFE74E44CB92672B2B6AFE042C6796416F18D7_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A * _thisAdjusted = reinterpret_cast<uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A *>(__this + _offset);
	String_t* _returnValue;
	_returnValue = uint2_ToString_mCAEFE74E44CB92672B2B6AFE042C6796416F18D7_inline(_thisAdjusted, method);
	return _returnValue;
}
// System.String Unity.Mathematics.uint2::ToString(System.String,System.IFormatProvider)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* uint2_ToString_mF753477C3131F00ABFE352F02919CC57CB6F8F88 (uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A * __this, String_t* ___format0, RuntimeObject* ___formatProvider1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralE368123B559BBC0EC2335D3AF9EC37C25C8B5945);
		s_Il2CppMethodInitialized = true;
	}
	{
		// return string.Format("uint2({0}, {1})", x.ToString(format, formatProvider), y.ToString(format, formatProvider));
		uint32_t* L_0 = __this->get_address_of_x_0();
		String_t* L_1 = ___format0;
		RuntimeObject* L_2 = ___formatProvider1;
		String_t* L_3;
		L_3 = UInt32_ToString_mAF0A46E9EC70EA43A02EBE522FF287E20DEE691B((uint32_t*)L_0, L_1, L_2, /*hidden argument*/NULL);
		uint32_t* L_4 = __this->get_address_of_y_1();
		String_t* L_5 = ___format0;
		RuntimeObject* L_6 = ___formatProvider1;
		String_t* L_7;
		L_7 = UInt32_ToString_mAF0A46E9EC70EA43A02EBE522FF287E20DEE691B((uint32_t*)L_4, L_5, L_6, /*hidden argument*/NULL);
		String_t* L_8;
		L_8 = String_Format_m8D1CB0410C35E052A53AE957C914C841E54BAB66(_stringLiteralE368123B559BBC0EC2335D3AF9EC37C25C8B5945, L_3, L_7, /*hidden argument*/NULL);
		return L_8;
	}
}
IL2CPP_EXTERN_C  String_t* uint2_ToString_mF753477C3131F00ABFE352F02919CC57CB6F8F88_AdjustorThunk (RuntimeObject * __this, String_t* ___format0, RuntimeObject* ___formatProvider1, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A * _thisAdjusted = reinterpret_cast<uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A *>(__this + _offset);
	String_t* _returnValue;
	_returnValue = uint2_ToString_mF753477C3131F00ABFE352F02919CC57CB6F8F88_inline(_thisAdjusted, ___format0, ___formatProvider1, method);
	return _returnValue;
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void Unity.Mathematics.uint3::.ctor(System.UInt32,System.UInt32,System.UInt32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void uint3__ctor_m3B61A70D37EB10BE4F26625A9BBB52466AE9ECE3 (uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE * __this, uint32_t ___x0, uint32_t ___y1, uint32_t ___z2, const RuntimeMethod* method)
{
	{
		// this.x = x;
		uint32_t L_0 = ___x0;
		__this->set_x_0(L_0);
		// this.y = y;
		uint32_t L_1 = ___y1;
		__this->set_y_1(L_1);
		// this.z = z;
		uint32_t L_2 = ___z2;
		__this->set_z_2(L_2);
		// }
		return;
	}
}
IL2CPP_EXTERN_C  void uint3__ctor_m3B61A70D37EB10BE4F26625A9BBB52466AE9ECE3_AdjustorThunk (RuntimeObject * __this, uint32_t ___x0, uint32_t ___y1, uint32_t ___z2, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE * _thisAdjusted = reinterpret_cast<uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE *>(__this + _offset);
	uint3__ctor_m3B61A70D37EB10BE4F26625A9BBB52466AE9ECE3_inline(_thisAdjusted, ___x0, ___y1, ___z2, method);
}
// Unity.Mathematics.uint3 Unity.Mathematics.uint3::op_Multiply(Unity.Mathematics.uint3,Unity.Mathematics.uint3)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  uint3_op_Multiply_mBF3B660B4057B2D4ACD4B6B3DDDC4E747A6C8877 (uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  ___lhs0, uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  ___rhs1, const RuntimeMethod* method)
{
	{
		// public static uint3 operator * (uint3 lhs, uint3 rhs) { return new uint3 (lhs.x * rhs.x, lhs.y * rhs.y, lhs.z * rhs.z); }
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_0 = ___lhs0;
		uint32_t L_1 = L_0.get_x_0();
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_2 = ___rhs1;
		uint32_t L_3 = L_2.get_x_0();
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_4 = ___lhs0;
		uint32_t L_5 = L_4.get_y_1();
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_6 = ___rhs1;
		uint32_t L_7 = L_6.get_y_1();
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_8 = ___lhs0;
		uint32_t L_9 = L_8.get_z_2();
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_10 = ___rhs1;
		uint32_t L_11 = L_10.get_z_2();
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_12;
		memset((&L_12), 0, sizeof(L_12));
		uint3__ctor_m3B61A70D37EB10BE4F26625A9BBB52466AE9ECE3_inline((&L_12), ((int32_t)il2cpp_codegen_multiply((int32_t)L_1, (int32_t)L_3)), ((int32_t)il2cpp_codegen_multiply((int32_t)L_5, (int32_t)L_7)), ((int32_t)il2cpp_codegen_multiply((int32_t)L_9, (int32_t)L_11)), /*hidden argument*/NULL);
		return L_12;
	}
}
// System.Boolean Unity.Mathematics.uint3::Equals(Unity.Mathematics.uint3)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool uint3_Equals_m4123D7A3796D0EB4F1D33541453971082875FAC5 (uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE * __this, uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  ___rhs0, const RuntimeMethod* method)
{
	{
		// public bool Equals(uint3 rhs) { return x == rhs.x && y == rhs.y && z == rhs.z; }
		uint32_t L_0 = __this->get_x_0();
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_1 = ___rhs0;
		uint32_t L_2 = L_1.get_x_0();
		if ((!(((uint32_t)L_0) == ((uint32_t)L_2))))
		{
			goto IL_002b;
		}
	}
	{
		uint32_t L_3 = __this->get_y_1();
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_4 = ___rhs0;
		uint32_t L_5 = L_4.get_y_1();
		if ((!(((uint32_t)L_3) == ((uint32_t)L_5))))
		{
			goto IL_002b;
		}
	}
	{
		uint32_t L_6 = __this->get_z_2();
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_7 = ___rhs0;
		uint32_t L_8 = L_7.get_z_2();
		return (bool)((((int32_t)L_6) == ((int32_t)L_8))? 1 : 0);
	}

IL_002b:
	{
		return (bool)0;
	}
}
IL2CPP_EXTERN_C  bool uint3_Equals_m4123D7A3796D0EB4F1D33541453971082875FAC5_AdjustorThunk (RuntimeObject * __this, uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  ___rhs0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE * _thisAdjusted = reinterpret_cast<uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE *>(__this + _offset);
	bool _returnValue;
	_returnValue = uint3_Equals_m4123D7A3796D0EB4F1D33541453971082875FAC5_inline(_thisAdjusted, ___rhs0, method);
	return _returnValue;
}
// System.Boolean Unity.Mathematics.uint3::Equals(System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool uint3_Equals_m6EEB50DA7949D150AE0E87B037BDFE252D5617CF (uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE * __this, RuntimeObject * ___o0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// public override bool Equals(object o) { return Equals((uint3)o); }
		RuntimeObject * L_0 = ___o0;
		bool L_1;
		L_1 = uint3_Equals_m4123D7A3796D0EB4F1D33541453971082875FAC5_inline((uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE *)__this, ((*(uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE *)((uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE *)UnBox(L_0, uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE_il2cpp_TypeInfo_var)))), /*hidden argument*/NULL);
		return L_1;
	}
}
IL2CPP_EXTERN_C  bool uint3_Equals_m6EEB50DA7949D150AE0E87B037BDFE252D5617CF_AdjustorThunk (RuntimeObject * __this, RuntimeObject * ___o0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE * _thisAdjusted = reinterpret_cast<uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE *>(__this + _offset);
	bool _returnValue;
	_returnValue = uint3_Equals_m6EEB50DA7949D150AE0E87B037BDFE252D5617CF(_thisAdjusted, ___o0, method);
	return _returnValue;
}
// System.Int32 Unity.Mathematics.uint3::GetHashCode()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t uint3_GetHashCode_mFAA802DA823258302D91BA287D4C924197646F5B (uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE * __this, const RuntimeMethod* method)
{
	{
		// public override int GetHashCode() { return (int)math.hash(this); }
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_0 = (*(uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE *)__this);
		uint32_t L_1;
		L_1 = math_hash_m8C856AA564098835DF61AF436DD3D70B51C34C56_inline(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
IL2CPP_EXTERN_C  int32_t uint3_GetHashCode_mFAA802DA823258302D91BA287D4C924197646F5B_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE * _thisAdjusted = reinterpret_cast<uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE *>(__this + _offset);
	int32_t _returnValue;
	_returnValue = uint3_GetHashCode_mFAA802DA823258302D91BA287D4C924197646F5B_inline(_thisAdjusted, method);
	return _returnValue;
}
// System.String Unity.Mathematics.uint3::ToString()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* uint3_ToString_m0497363E44BBF1E7F68936646E1CFC09675FF23B (uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&UInt32_tE60352A06233E4E69DD198BCC67142159F686B15_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralFEC52A4F763D4C868968D018DEC2AF8064D4C8E2);
		s_Il2CppMethodInitialized = true;
	}
	{
		// return string.Format("uint3({0}, {1}, {2})", x, y, z);
		uint32_t L_0 = __this->get_x_0();
		uint32_t L_1 = L_0;
		RuntimeObject * L_2 = Box(UInt32_tE60352A06233E4E69DD198BCC67142159F686B15_il2cpp_TypeInfo_var, &L_1);
		uint32_t L_3 = __this->get_y_1();
		uint32_t L_4 = L_3;
		RuntimeObject * L_5 = Box(UInt32_tE60352A06233E4E69DD198BCC67142159F686B15_il2cpp_TypeInfo_var, &L_4);
		uint32_t L_6 = __this->get_z_2();
		uint32_t L_7 = L_6;
		RuntimeObject * L_8 = Box(UInt32_tE60352A06233E4E69DD198BCC67142159F686B15_il2cpp_TypeInfo_var, &L_7);
		String_t* L_9;
		L_9 = String_Format_m039737CCD992C5BFC8D16DFD681F5E8786E87FA6(_stringLiteralFEC52A4F763D4C868968D018DEC2AF8064D4C8E2, L_2, L_5, L_8, /*hidden argument*/NULL);
		return L_9;
	}
}
IL2CPP_EXTERN_C  String_t* uint3_ToString_m0497363E44BBF1E7F68936646E1CFC09675FF23B_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE * _thisAdjusted = reinterpret_cast<uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE *>(__this + _offset);
	String_t* _returnValue;
	_returnValue = uint3_ToString_m0497363E44BBF1E7F68936646E1CFC09675FF23B_inline(_thisAdjusted, method);
	return _returnValue;
}
// System.String Unity.Mathematics.uint3::ToString(System.String,System.IFormatProvider)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* uint3_ToString_m786F82DA9F9EE5A6985F8B8FE3600710D806232B (uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE * __this, String_t* ___format0, RuntimeObject* ___formatProvider1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralFEC52A4F763D4C868968D018DEC2AF8064D4C8E2);
		s_Il2CppMethodInitialized = true;
	}
	{
		// return string.Format("uint3({0}, {1}, {2})", x.ToString(format, formatProvider), y.ToString(format, formatProvider), z.ToString(format, formatProvider));
		uint32_t* L_0 = __this->get_address_of_x_0();
		String_t* L_1 = ___format0;
		RuntimeObject* L_2 = ___formatProvider1;
		String_t* L_3;
		L_3 = UInt32_ToString_mAF0A46E9EC70EA43A02EBE522FF287E20DEE691B((uint32_t*)L_0, L_1, L_2, /*hidden argument*/NULL);
		uint32_t* L_4 = __this->get_address_of_y_1();
		String_t* L_5 = ___format0;
		RuntimeObject* L_6 = ___formatProvider1;
		String_t* L_7;
		L_7 = UInt32_ToString_mAF0A46E9EC70EA43A02EBE522FF287E20DEE691B((uint32_t*)L_4, L_5, L_6, /*hidden argument*/NULL);
		uint32_t* L_8 = __this->get_address_of_z_2();
		String_t* L_9 = ___format0;
		RuntimeObject* L_10 = ___formatProvider1;
		String_t* L_11;
		L_11 = UInt32_ToString_mAF0A46E9EC70EA43A02EBE522FF287E20DEE691B((uint32_t*)L_8, L_9, L_10, /*hidden argument*/NULL);
		String_t* L_12;
		L_12 = String_Format_m039737CCD992C5BFC8D16DFD681F5E8786E87FA6(_stringLiteralFEC52A4F763D4C868968D018DEC2AF8064D4C8E2, L_3, L_7, L_11, /*hidden argument*/NULL);
		return L_12;
	}
}
IL2CPP_EXTERN_C  String_t* uint3_ToString_m786F82DA9F9EE5A6985F8B8FE3600710D806232B_AdjustorThunk (RuntimeObject * __this, String_t* ___format0, RuntimeObject* ___formatProvider1, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE * _thisAdjusted = reinterpret_cast<uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE *>(__this + _offset);
	String_t* _returnValue;
	_returnValue = uint3_ToString_m786F82DA9F9EE5A6985F8B8FE3600710D806232B_inline(_thisAdjusted, ___format0, ___formatProvider1, method);
	return _returnValue;
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void Unity.Mathematics.uint4::.ctor(System.UInt32,System.UInt32,System.UInt32,System.UInt32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void uint4__ctor_m542805076C6C9E3A87DC3242D32E60C4347439E8 (uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92 * __this, uint32_t ___x0, uint32_t ___y1, uint32_t ___z2, uint32_t ___w3, const RuntimeMethod* method)
{
	{
		// this.x = x;
		uint32_t L_0 = ___x0;
		__this->set_x_0(L_0);
		// this.y = y;
		uint32_t L_1 = ___y1;
		__this->set_y_1(L_1);
		// this.z = z;
		uint32_t L_2 = ___z2;
		__this->set_z_2(L_2);
		// this.w = w;
		uint32_t L_3 = ___w3;
		__this->set_w_3(L_3);
		// }
		return;
	}
}
IL2CPP_EXTERN_C  void uint4__ctor_m542805076C6C9E3A87DC3242D32E60C4347439E8_AdjustorThunk (RuntimeObject * __this, uint32_t ___x0, uint32_t ___y1, uint32_t ___z2, uint32_t ___w3, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92 * _thisAdjusted = reinterpret_cast<uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92 *>(__this + _offset);
	uint4__ctor_m542805076C6C9E3A87DC3242D32E60C4347439E8_inline(_thisAdjusted, ___x0, ___y1, ___z2, ___w3, method);
}
// Unity.Mathematics.uint4 Unity.Mathematics.uint4::op_Multiply(Unity.Mathematics.uint4,Unity.Mathematics.uint4)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  uint4_op_Multiply_m27352F838EE80439EE98A136D8D246AF5E9EF681 (uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  ___lhs0, uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  ___rhs1, const RuntimeMethod* method)
{
	{
		// public static uint4 operator * (uint4 lhs, uint4 rhs) { return new uint4 (lhs.x * rhs.x, lhs.y * rhs.y, lhs.z * rhs.z, lhs.w * rhs.w); }
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_0 = ___lhs0;
		uint32_t L_1 = L_0.get_x_0();
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_2 = ___rhs1;
		uint32_t L_3 = L_2.get_x_0();
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_4 = ___lhs0;
		uint32_t L_5 = L_4.get_y_1();
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_6 = ___rhs1;
		uint32_t L_7 = L_6.get_y_1();
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_8 = ___lhs0;
		uint32_t L_9 = L_8.get_z_2();
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_10 = ___rhs1;
		uint32_t L_11 = L_10.get_z_2();
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_12 = ___lhs0;
		uint32_t L_13 = L_12.get_w_3();
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_14 = ___rhs1;
		uint32_t L_15 = L_14.get_w_3();
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_16;
		memset((&L_16), 0, sizeof(L_16));
		uint4__ctor_m542805076C6C9E3A87DC3242D32E60C4347439E8_inline((&L_16), ((int32_t)il2cpp_codegen_multiply((int32_t)L_1, (int32_t)L_3)), ((int32_t)il2cpp_codegen_multiply((int32_t)L_5, (int32_t)L_7)), ((int32_t)il2cpp_codegen_multiply((int32_t)L_9, (int32_t)L_11)), ((int32_t)il2cpp_codegen_multiply((int32_t)L_13, (int32_t)L_15)), /*hidden argument*/NULL);
		return L_16;
	}
}
// System.Boolean Unity.Mathematics.uint4::Equals(Unity.Mathematics.uint4)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool uint4_Equals_mCD29FF2676C20223B8043FD676230CCB4EAA934D (uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92 * __this, uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  ___rhs0, const RuntimeMethod* method)
{
	{
		// public bool Equals(uint4 rhs) { return x == rhs.x && y == rhs.y && z == rhs.z && w == rhs.w; }
		uint32_t L_0 = __this->get_x_0();
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_1 = ___rhs0;
		uint32_t L_2 = L_1.get_x_0();
		if ((!(((uint32_t)L_0) == ((uint32_t)L_2))))
		{
			goto IL_0039;
		}
	}
	{
		uint32_t L_3 = __this->get_y_1();
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_4 = ___rhs0;
		uint32_t L_5 = L_4.get_y_1();
		if ((!(((uint32_t)L_3) == ((uint32_t)L_5))))
		{
			goto IL_0039;
		}
	}
	{
		uint32_t L_6 = __this->get_z_2();
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_7 = ___rhs0;
		uint32_t L_8 = L_7.get_z_2();
		if ((!(((uint32_t)L_6) == ((uint32_t)L_8))))
		{
			goto IL_0039;
		}
	}
	{
		uint32_t L_9 = __this->get_w_3();
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_10 = ___rhs0;
		uint32_t L_11 = L_10.get_w_3();
		return (bool)((((int32_t)L_9) == ((int32_t)L_11))? 1 : 0);
	}

IL_0039:
	{
		return (bool)0;
	}
}
IL2CPP_EXTERN_C  bool uint4_Equals_mCD29FF2676C20223B8043FD676230CCB4EAA934D_AdjustorThunk (RuntimeObject * __this, uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  ___rhs0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92 * _thisAdjusted = reinterpret_cast<uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92 *>(__this + _offset);
	bool _returnValue;
	_returnValue = uint4_Equals_mCD29FF2676C20223B8043FD676230CCB4EAA934D_inline(_thisAdjusted, ___rhs0, method);
	return _returnValue;
}
// System.Boolean Unity.Mathematics.uint4::Equals(System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool uint4_Equals_m852477DBE9163FE512CE869B6ED4DB1470B5171E (uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92 * __this, RuntimeObject * ___o0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// public override bool Equals(object o) { return Equals((uint4)o); }
		RuntimeObject * L_0 = ___o0;
		bool L_1;
		L_1 = uint4_Equals_mCD29FF2676C20223B8043FD676230CCB4EAA934D_inline((uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92 *)__this, ((*(uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92 *)((uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92 *)UnBox(L_0, uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92_il2cpp_TypeInfo_var)))), /*hidden argument*/NULL);
		return L_1;
	}
}
IL2CPP_EXTERN_C  bool uint4_Equals_m852477DBE9163FE512CE869B6ED4DB1470B5171E_AdjustorThunk (RuntimeObject * __this, RuntimeObject * ___o0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92 * _thisAdjusted = reinterpret_cast<uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92 *>(__this + _offset);
	bool _returnValue;
	_returnValue = uint4_Equals_m852477DBE9163FE512CE869B6ED4DB1470B5171E(_thisAdjusted, ___o0, method);
	return _returnValue;
}
// System.Int32 Unity.Mathematics.uint4::GetHashCode()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t uint4_GetHashCode_m86A07B8FA19284D7065183699510D9601B490778 (uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92 * __this, const RuntimeMethod* method)
{
	{
		// public override int GetHashCode() { return (int)math.hash(this); }
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_0 = (*(uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92 *)__this);
		uint32_t L_1;
		L_1 = math_hash_m75BFBA2E7EB5F1542B66C31F5CC1F398EFBF697E_inline(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
IL2CPP_EXTERN_C  int32_t uint4_GetHashCode_m86A07B8FA19284D7065183699510D9601B490778_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92 * _thisAdjusted = reinterpret_cast<uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92 *>(__this + _offset);
	int32_t _returnValue;
	_returnValue = uint4_GetHashCode_m86A07B8FA19284D7065183699510D9601B490778_inline(_thisAdjusted, method);
	return _returnValue;
}
// System.String Unity.Mathematics.uint4::ToString()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* uint4_ToString_m9EFC2F5F7AC7B62F848D0E59CE894B72EED63B7B (uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&UInt32_tE60352A06233E4E69DD198BCC67142159F686B15_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralE134155080D59FDE2A83A55D0BB359039175A4EA);
		s_Il2CppMethodInitialized = true;
	}
	{
		// return string.Format("uint4({0}, {1}, {2}, {3})", x, y, z, w);
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_0 = (ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE*)(ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE*)SZArrayNew(ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE_il2cpp_TypeInfo_var, (uint32_t)4);
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_1 = L_0;
		uint32_t L_2 = __this->get_x_0();
		uint32_t L_3 = L_2;
		RuntimeObject * L_4 = Box(UInt32_tE60352A06233E4E69DD198BCC67142159F686B15_il2cpp_TypeInfo_var, &L_3);
		NullCheck(L_1);
		ArrayElementTypeCheck (L_1, L_4);
		(L_1)->SetAt(static_cast<il2cpp_array_size_t>(0), (RuntimeObject *)L_4);
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_5 = L_1;
		uint32_t L_6 = __this->get_y_1();
		uint32_t L_7 = L_6;
		RuntimeObject * L_8 = Box(UInt32_tE60352A06233E4E69DD198BCC67142159F686B15_il2cpp_TypeInfo_var, &L_7);
		NullCheck(L_5);
		ArrayElementTypeCheck (L_5, L_8);
		(L_5)->SetAt(static_cast<il2cpp_array_size_t>(1), (RuntimeObject *)L_8);
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_9 = L_5;
		uint32_t L_10 = __this->get_z_2();
		uint32_t L_11 = L_10;
		RuntimeObject * L_12 = Box(UInt32_tE60352A06233E4E69DD198BCC67142159F686B15_il2cpp_TypeInfo_var, &L_11);
		NullCheck(L_9);
		ArrayElementTypeCheck (L_9, L_12);
		(L_9)->SetAt(static_cast<il2cpp_array_size_t>(2), (RuntimeObject *)L_12);
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_13 = L_9;
		uint32_t L_14 = __this->get_w_3();
		uint32_t L_15 = L_14;
		RuntimeObject * L_16 = Box(UInt32_tE60352A06233E4E69DD198BCC67142159F686B15_il2cpp_TypeInfo_var, &L_15);
		NullCheck(L_13);
		ArrayElementTypeCheck (L_13, L_16);
		(L_13)->SetAt(static_cast<il2cpp_array_size_t>(3), (RuntimeObject *)L_16);
		String_t* L_17;
		L_17 = String_Format_mCED6767EA5FEE6F15ABCD5B4F9150D1284C2795B(_stringLiteralE134155080D59FDE2A83A55D0BB359039175A4EA, L_13, /*hidden argument*/NULL);
		return L_17;
	}
}
IL2CPP_EXTERN_C  String_t* uint4_ToString_m9EFC2F5F7AC7B62F848D0E59CE894B72EED63B7B_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92 * _thisAdjusted = reinterpret_cast<uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92 *>(__this + _offset);
	String_t* _returnValue;
	_returnValue = uint4_ToString_m9EFC2F5F7AC7B62F848D0E59CE894B72EED63B7B_inline(_thisAdjusted, method);
	return _returnValue;
}
// System.String Unity.Mathematics.uint4::ToString(System.String,System.IFormatProvider)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* uint4_ToString_mC1805F654F5474DF4F49D92910751B8A9B81C315 (uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92 * __this, String_t* ___format0, RuntimeObject* ___formatProvider1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralE134155080D59FDE2A83A55D0BB359039175A4EA);
		s_Il2CppMethodInitialized = true;
	}
	{
		// return string.Format("uint4({0}, {1}, {2}, {3})", x.ToString(format, formatProvider), y.ToString(format, formatProvider), z.ToString(format, formatProvider), w.ToString(format, formatProvider));
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_0 = (ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE*)(ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE*)SZArrayNew(ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE_il2cpp_TypeInfo_var, (uint32_t)4);
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_1 = L_0;
		uint32_t* L_2 = __this->get_address_of_x_0();
		String_t* L_3 = ___format0;
		RuntimeObject* L_4 = ___formatProvider1;
		String_t* L_5;
		L_5 = UInt32_ToString_mAF0A46E9EC70EA43A02EBE522FF287E20DEE691B((uint32_t*)L_2, L_3, L_4, /*hidden argument*/NULL);
		NullCheck(L_1);
		ArrayElementTypeCheck (L_1, L_5);
		(L_1)->SetAt(static_cast<il2cpp_array_size_t>(0), (RuntimeObject *)L_5);
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_6 = L_1;
		uint32_t* L_7 = __this->get_address_of_y_1();
		String_t* L_8 = ___format0;
		RuntimeObject* L_9 = ___formatProvider1;
		String_t* L_10;
		L_10 = UInt32_ToString_mAF0A46E9EC70EA43A02EBE522FF287E20DEE691B((uint32_t*)L_7, L_8, L_9, /*hidden argument*/NULL);
		NullCheck(L_6);
		ArrayElementTypeCheck (L_6, L_10);
		(L_6)->SetAt(static_cast<il2cpp_array_size_t>(1), (RuntimeObject *)L_10);
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_11 = L_6;
		uint32_t* L_12 = __this->get_address_of_z_2();
		String_t* L_13 = ___format0;
		RuntimeObject* L_14 = ___formatProvider1;
		String_t* L_15;
		L_15 = UInt32_ToString_mAF0A46E9EC70EA43A02EBE522FF287E20DEE691B((uint32_t*)L_12, L_13, L_14, /*hidden argument*/NULL);
		NullCheck(L_11);
		ArrayElementTypeCheck (L_11, L_15);
		(L_11)->SetAt(static_cast<il2cpp_array_size_t>(2), (RuntimeObject *)L_15);
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_16 = L_11;
		uint32_t* L_17 = __this->get_address_of_w_3();
		String_t* L_18 = ___format0;
		RuntimeObject* L_19 = ___formatProvider1;
		String_t* L_20;
		L_20 = UInt32_ToString_mAF0A46E9EC70EA43A02EBE522FF287E20DEE691B((uint32_t*)L_17, L_18, L_19, /*hidden argument*/NULL);
		NullCheck(L_16);
		ArrayElementTypeCheck (L_16, L_20);
		(L_16)->SetAt(static_cast<il2cpp_array_size_t>(3), (RuntimeObject *)L_20);
		String_t* L_21;
		L_21 = String_Format_mCED6767EA5FEE6F15ABCD5B4F9150D1284C2795B(_stringLiteralE134155080D59FDE2A83A55D0BB359039175A4EA, L_16, /*hidden argument*/NULL);
		return L_21;
	}
}
IL2CPP_EXTERN_C  String_t* uint4_ToString_mC1805F654F5474DF4F49D92910751B8A9B81C315_AdjustorThunk (RuntimeObject * __this, String_t* ___format0, RuntimeObject* ___formatProvider1, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92 * _thisAdjusted = reinterpret_cast<uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92 *>(__this + _offset);
	String_t* _returnValue;
	_returnValue = uint4_ToString_mC1805F654F5474DF4F49D92910751B8A9B81C315_inline(_thisAdjusted, ___format0, ___formatProvider1, method);
	return _returnValue;
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void float2__ctor_mA85C140C72CD3A1E8F287AEC7FF12A35C85C819C_inline (float2_t11F5F2974404951113DDC4E13EEB6E2456295547 * __this, float ___x0, float ___y1, const RuntimeMethod* method)
{
	{
		// this.x = x;
		float L_0 = ___x0;
		__this->set_x_0(L_0);
		// this.y = y;
		float L_1 = ___y1;
		__this->set_y_1(L_1);
		// }
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float2_t11F5F2974404951113DDC4E13EEB6E2456295547  float2_get_xy_m70AC8FFD749BA962E2C2822CCD4B731098858DCB_inline (float2_t11F5F2974404951113DDC4E13EEB6E2456295547 * __this, const RuntimeMethod* method)
{
	{
		// get { return new float2(x, y); }
		float L_0 = __this->get_x_0();
		float L_1 = __this->get_y_1();
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_2;
		memset((&L_2), 0, sizeof(L_2));
		float2__ctor_mA85C140C72CD3A1E8F287AEC7FF12A35C85C819C_inline((&L_2), L_0, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool float2_Equals_m406569E20C262C01141F2977EB04430121AD5AFE_inline (float2_t11F5F2974404951113DDC4E13EEB6E2456295547 * __this, float2_t11F5F2974404951113DDC4E13EEB6E2456295547  ___rhs0, const RuntimeMethod* method)
{
	{
		// public bool Equals(float2 rhs) { return x == rhs.x && y == rhs.y; }
		float L_0 = __this->get_x_0();
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_1 = ___rhs0;
		float L_2 = L_1.get_x_0();
		if ((!(((float)L_0) == ((float)L_2))))
		{
			goto IL_001d;
		}
	}
	{
		float L_3 = __this->get_y_1();
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_4 = ___rhs0;
		float L_5 = L_4.get_y_1();
		return (bool)((((float)L_3) == ((float)L_5))? 1 : 0);
	}

IL_001d:
	{
		return (bool)0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint32_t math_hash_m0214B7050F1399AD283DFF8CB115A65E0B95E1BA_inline (float2_t11F5F2974404951113DDC4E13EEB6E2456295547  ___v0, const RuntimeMethod* method)
{
	{
		// return csum(asuint(v) * uint2(0xFA3A3285u, 0xAD55999Du)) + 0xDCDD5341u;
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_0 = ___v0;
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_1;
		L_1 = math_asuint_mADD3FB6B29BD406CC3254B1DE3776D5B92F7B161_inline(L_0, /*hidden argument*/NULL);
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_2;
		L_2 = math_uint2_mF2E830E0F3E660D4E640F5EF5D5A3FCA75378D01_inline(((int32_t)-96849275), ((int32_t)-1386899043), /*hidden argument*/NULL);
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_3;
		L_3 = uint2_op_Multiply_m7636391131B0EDC9918A5772AD85C68109F2235F_inline(L_1, L_2, /*hidden argument*/NULL);
		uint32_t L_4;
		L_4 = math_csum_m27D50739B96EE2F2DEA2EABD207F2B827F87E232_inline(L_3, /*hidden argument*/NULL);
		return ((int32_t)il2cpp_codegen_add((int32_t)L_4, (int32_t)((int32_t)-589475007)));
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t float2_GetHashCode_mAB652A4865F38E1A58F754B6B8E17F24617B2C23_inline (float2_t11F5F2974404951113DDC4E13EEB6E2456295547 * __this, const RuntimeMethod* method)
{
	{
		// public override int GetHashCode() { return (int)math.hash(this); }
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_0 = (*(float2_t11F5F2974404951113DDC4E13EEB6E2456295547 *)__this);
		uint32_t L_1;
		L_1 = math_hash_m0214B7050F1399AD283DFF8CB115A65E0B95E1BA_inline(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR String_t* float2_ToString_m88AFB1A56BC992680CB633C9A73EBEFD3369F8B1_inline (float2_t11F5F2974404951113DDC4E13EEB6E2456295547 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Single_tE07797BA3C98D4CA9B5A19413C19A76688AB899E_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral50EDAD5CFB15084F3338C313ED64018C8F78CD58);
		s_Il2CppMethodInitialized = true;
	}
	{
		// return string.Format("float2({0}f, {1}f)", x, y);
		float L_0 = __this->get_x_0();
		float L_1 = L_0;
		RuntimeObject * L_2 = Box(Single_tE07797BA3C98D4CA9B5A19413C19A76688AB899E_il2cpp_TypeInfo_var, &L_1);
		float L_3 = __this->get_y_1();
		float L_4 = L_3;
		RuntimeObject * L_5 = Box(Single_tE07797BA3C98D4CA9B5A19413C19A76688AB899E_il2cpp_TypeInfo_var, &L_4);
		String_t* L_6;
		L_6 = String_Format_m8D1CB0410C35E052A53AE957C914C841E54BAB66(_stringLiteral50EDAD5CFB15084F3338C313ED64018C8F78CD58, L_2, L_5, /*hidden argument*/NULL);
		return L_6;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR String_t* float2_ToString_m663E65C99B64AD3B4CBEC51AC457685D0A0369B6_inline (float2_t11F5F2974404951113DDC4E13EEB6E2456295547 * __this, String_t* ___format0, RuntimeObject* ___formatProvider1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral50EDAD5CFB15084F3338C313ED64018C8F78CD58);
		s_Il2CppMethodInitialized = true;
	}
	{
		// return string.Format("float2({0}f, {1}f)", x.ToString(format, formatProvider), y.ToString(format, formatProvider));
		float* L_0 = __this->get_address_of_x_0();
		String_t* L_1 = ___format0;
		RuntimeObject* L_2 = ___formatProvider1;
		String_t* L_3;
		L_3 = Single_ToString_m7631D332703B4197EAA7DC0BA067CE7E16334D8B((float*)L_0, L_1, L_2, /*hidden argument*/NULL);
		float* L_4 = __this->get_address_of_y_1();
		String_t* L_5 = ___format0;
		RuntimeObject* L_6 = ___formatProvider1;
		String_t* L_7;
		L_7 = Single_ToString_m7631D332703B4197EAA7DC0BA067CE7E16334D8B((float*)L_4, L_5, L_6, /*hidden argument*/NULL);
		String_t* L_8;
		L_8 = String_Format_m8D1CB0410C35E052A53AE957C914C841E54BAB66(_stringLiteral50EDAD5CFB15084F3338C313ED64018C8F78CD58, L_3, L_7, /*hidden argument*/NULL);
		return L_8;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void float3__ctor_m853853CCAF2BC58F66EE07DB9338C1644698D483_inline (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * __this, float ___x0, float ___y1, float ___z2, const RuntimeMethod* method)
{
	{
		// this.x = x;
		float L_0 = ___x0;
		__this->set_x_0(L_0);
		// this.y = y;
		float L_1 = ___y1;
		__this->set_y_1(L_1);
		// this.z = z;
		float L_2 = ___z2;
		__this->set_z_2(L_2);
		// }
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void float3__ctor_mB8B1FC017A7671C0F19CBF32B243871B770F219B_inline (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * __this, float2_t11F5F2974404951113DDC4E13EEB6E2456295547  ___xy0, float ___z1, const RuntimeMethod* method)
{
	{
		// this.x = xy.x;
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_0 = ___xy0;
		float L_1 = L_0.get_x_0();
		__this->set_x_0(L_1);
		// this.y = xy.y;
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_2 = ___xy0;
		float L_3 = L_2.get_y_1();
		__this->set_y_1(L_3);
		// this.z = z;
		float L_4 = ___z1;
		__this->set_z_2(L_4);
		// }
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void float3__ctor_mD066F7C313EE72EC068E4CD9E6475CD0D148A4B4_inline (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * __this, float ___v0, const RuntimeMethod* method)
{
	{
		// this.x = v;
		float L_0 = ___v0;
		__this->set_x_0(L_0);
		// this.y = v;
		float L_1 = ___v0;
		__this->set_y_1(L_1);
		// this.z = v;
		float L_2 = ___v0;
		__this->set_z_2(L_2);
		// }
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  float3_get_xzy_mE4543537819B8525168D59076E3A19F95728DC77_inline (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * __this, const RuntimeMethod* method)
{
	{
		// get { return new float3(x, z, y); }
		float L_0 = __this->get_x_0();
		float L_1 = __this->get_z_2();
		float L_2 = __this->get_y_1();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_3;
		memset((&L_3), 0, sizeof(L_3));
		float3__ctor_m853853CCAF2BC58F66EE07DB9338C1644698D483_inline((&L_3), L_0, L_1, L_2, /*hidden argument*/NULL);
		return L_3;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  float3_get_yzx_mAE305D9ABE33A40967A3BEECAF5E8CA1E66B2D6B_inline (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * __this, const RuntimeMethod* method)
{
	{
		// get { return new float3(y, z, x); }
		float L_0 = __this->get_y_1();
		float L_1 = __this->get_z_2();
		float L_2 = __this->get_x_0();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_3;
		memset((&L_3), 0, sizeof(L_3));
		float3__ctor_m853853CCAF2BC58F66EE07DB9338C1644698D483_inline((&L_3), L_0, L_1, L_2, /*hidden argument*/NULL);
		return L_3;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float2_t11F5F2974404951113DDC4E13EEB6E2456295547  float3_get_xz_m9955DC8BBF06D0C80113321EB39C8946100B3693_inline (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * __this, const RuntimeMethod* method)
{
	{
		// get { return new float2(x, z); }
		float L_0 = __this->get_x_0();
		float L_1 = __this->get_z_2();
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_2;
		memset((&L_2), 0, sizeof(L_2));
		float2__ctor_mA85C140C72CD3A1E8F287AEC7FF12A35C85C819C_inline((&L_2), L_0, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool float3_Equals_m082B461D20DCFD179A2A50F68737C51794D30F72_inline (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * __this, float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___rhs0, const RuntimeMethod* method)
{
	{
		// public bool Equals(float3 rhs) { return x == rhs.x && y == rhs.y && z == rhs.z; }
		float L_0 = __this->get_x_0();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_1 = ___rhs0;
		float L_2 = L_1.get_x_0();
		if ((!(((float)L_0) == ((float)L_2))))
		{
			goto IL_002b;
		}
	}
	{
		float L_3 = __this->get_y_1();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_4 = ___rhs0;
		float L_5 = L_4.get_y_1();
		if ((!(((float)L_3) == ((float)L_5))))
		{
			goto IL_002b;
		}
	}
	{
		float L_6 = __this->get_z_2();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_7 = ___rhs0;
		float L_8 = L_7.get_z_2();
		return (bool)((((float)L_6) == ((float)L_8))? 1 : 0);
	}

IL_002b:
	{
		return (bool)0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint32_t math_hash_m7B43A24382293202DAB3DF5C3953BE904664205B_inline (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___v0, const RuntimeMethod* method)
{
	{
		// return csum(asuint(v) * uint3(0x9B13B92Du, 0x4ABF0813u, 0x86068063u)) + 0xD75513F9u;
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_0 = ___v0;
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_1;
		L_1 = math_asuint_m391E0BC4333E70109D0AC31DBAB8693A082791A7_inline(L_0, /*hidden argument*/NULL);
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_2;
		L_2 = math_uint3_mCA0FF72ACE1A3319B3E19C41638C710CCFC56A68_inline(((int32_t)-1693206227), ((int32_t)1254033427), ((int32_t)-2046394269), /*hidden argument*/NULL);
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_3;
		L_3 = uint3_op_Multiply_mBF3B660B4057B2D4ACD4B6B3DDDC4E747A6C8877_inline(L_1, L_2, /*hidden argument*/NULL);
		uint32_t L_4;
		L_4 = math_csum_m60444A45FBA529E9ED20646FA61559F4B53D96ED_inline(L_3, /*hidden argument*/NULL);
		return ((int32_t)il2cpp_codegen_add((int32_t)L_4, (int32_t)((int32_t)-682290183)));
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t float3_GetHashCode_m9D7B789ABF601895DE5127F10AB318E5FB34FF33_inline (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * __this, const RuntimeMethod* method)
{
	{
		// public override int GetHashCode() { return (int)math.hash(this); }
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_0 = (*(float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D *)__this);
		uint32_t L_1;
		L_1 = math_hash_m7B43A24382293202DAB3DF5C3953BE904664205B_inline(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR String_t* float3_ToString_m1826B8701C72517A17CEDB7F7E4C804400A45F92_inline (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Single_tE07797BA3C98D4CA9B5A19413C19A76688AB899E_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral1578CABA4FF62AC9986DD5D0BA4C26A5CCB44A6A);
		s_Il2CppMethodInitialized = true;
	}
	{
		// return string.Format("float3({0}f, {1}f, {2}f)", x, y, z);
		float L_0 = __this->get_x_0();
		float L_1 = L_0;
		RuntimeObject * L_2 = Box(Single_tE07797BA3C98D4CA9B5A19413C19A76688AB899E_il2cpp_TypeInfo_var, &L_1);
		float L_3 = __this->get_y_1();
		float L_4 = L_3;
		RuntimeObject * L_5 = Box(Single_tE07797BA3C98D4CA9B5A19413C19A76688AB899E_il2cpp_TypeInfo_var, &L_4);
		float L_6 = __this->get_z_2();
		float L_7 = L_6;
		RuntimeObject * L_8 = Box(Single_tE07797BA3C98D4CA9B5A19413C19A76688AB899E_il2cpp_TypeInfo_var, &L_7);
		String_t* L_9;
		L_9 = String_Format_m039737CCD992C5BFC8D16DFD681F5E8786E87FA6(_stringLiteral1578CABA4FF62AC9986DD5D0BA4C26A5CCB44A6A, L_2, L_5, L_8, /*hidden argument*/NULL);
		return L_9;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR String_t* float3_ToString_m341757749BF9ED59EC04C13798F9402B220E86C6_inline (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D * __this, String_t* ___format0, RuntimeObject* ___formatProvider1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral1578CABA4FF62AC9986DD5D0BA4C26A5CCB44A6A);
		s_Il2CppMethodInitialized = true;
	}
	{
		// return string.Format("float3({0}f, {1}f, {2}f)", x.ToString(format, formatProvider), y.ToString(format, formatProvider), z.ToString(format, formatProvider));
		float* L_0 = __this->get_address_of_x_0();
		String_t* L_1 = ___format0;
		RuntimeObject* L_2 = ___formatProvider1;
		String_t* L_3;
		L_3 = Single_ToString_m7631D332703B4197EAA7DC0BA067CE7E16334D8B((float*)L_0, L_1, L_2, /*hidden argument*/NULL);
		float* L_4 = __this->get_address_of_y_1();
		String_t* L_5 = ___format0;
		RuntimeObject* L_6 = ___formatProvider1;
		String_t* L_7;
		L_7 = Single_ToString_m7631D332703B4197EAA7DC0BA067CE7E16334D8B((float*)L_4, L_5, L_6, /*hidden argument*/NULL);
		float* L_8 = __this->get_address_of_z_2();
		String_t* L_9 = ___format0;
		RuntimeObject* L_10 = ___formatProvider1;
		String_t* L_11;
		L_11 = Single_ToString_m7631D332703B4197EAA7DC0BA067CE7E16334D8B((float*)L_8, L_9, L_10, /*hidden argument*/NULL);
		String_t* L_12;
		L_12 = String_Format_m039737CCD992C5BFC8D16DFD681F5E8786E87FA6(_stringLiteral1578CABA4FF62AC9986DD5D0BA4C26A5CCB44A6A, L_3, L_7, L_11, /*hidden argument*/NULL);
		return L_12;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Vector3__ctor_m57495F692C6CE1CEF278CAD9A98221165D37E636_inline (Vector3_t65B972D6A585A0A5B63153CF1177A90D3C90D65E * __this, float ___x0, float ___y1, float ___z2, const RuntimeMethod* method)
{
	{
		float L_0 = ___x0;
		__this->set_x_2(L_0);
		float L_1 = ___y1;
		__this->set_y_3(L_1);
		float L_2 = ___z2;
		__this->set_z_4(L_2);
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void float4__ctor_m289038BF46A44D4F1F0A897417C1F9C96B96F349_inline (float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 * __this, float ___x0, float ___y1, float ___z2, float ___w3, const RuntimeMethod* method)
{
	{
		// this.x = x;
		float L_0 = ___x0;
		__this->set_x_0(L_0);
		// this.y = y;
		float L_1 = ___y1;
		__this->set_y_1(L_1);
		// this.z = z;
		float L_2 = ___z2;
		__this->set_z_2(L_2);
		// this.w = w;
		float L_3 = ___w3;
		__this->set_w_3(L_3);
		// }
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  float4_get_xyz_mC891E5A9ADFCD1137A3E1D0DF70A60A10290E4D2_inline (float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 * __this, const RuntimeMethod* method)
{
	{
		// get { return new float3(x, y, z); }
		float L_0 = __this->get_x_0();
		float L_1 = __this->get_y_1();
		float L_2 = __this->get_z_2();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_3;
		memset((&L_3), 0, sizeof(L_3));
		float3__ctor_m853853CCAF2BC58F66EE07DB9338C1644698D483_inline((&L_3), L_0, L_1, L_2, /*hidden argument*/NULL);
		return L_3;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void float4_set_xyz_m835174016809C625D7564655F4E2CCB95A024C45_inline (float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 * __this, float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___value0, const RuntimeMethod* method)
{
	{
		// set { x = value.x; y = value.y; z = value.z; }
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_0 = ___value0;
		float L_1 = L_0.get_x_0();
		__this->set_x_0(L_1);
		// set { x = value.x; y = value.y; z = value.z; }
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_2 = ___value0;
		float L_3 = L_2.get_y_1();
		__this->set_y_1(L_3);
		// set { x = value.x; y = value.y; z = value.z; }
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_4 = ___value0;
		float L_5 = L_4.get_z_2();
		__this->set_z_2(L_5);
		// set { x = value.x; y = value.y; z = value.z; }
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool float4_Equals_mFDF5FFF5DBF9FCD0FFD92C00CC3A0E6A22676C76_inline (float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 * __this, float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  ___rhs0, const RuntimeMethod* method)
{
	{
		// public bool Equals(float4 rhs) { return x == rhs.x && y == rhs.y && z == rhs.z && w == rhs.w; }
		float L_0 = __this->get_x_0();
		float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  L_1 = ___rhs0;
		float L_2 = L_1.get_x_0();
		if ((!(((float)L_0) == ((float)L_2))))
		{
			goto IL_0039;
		}
	}
	{
		float L_3 = __this->get_y_1();
		float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  L_4 = ___rhs0;
		float L_5 = L_4.get_y_1();
		if ((!(((float)L_3) == ((float)L_5))))
		{
			goto IL_0039;
		}
	}
	{
		float L_6 = __this->get_z_2();
		float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  L_7 = ___rhs0;
		float L_8 = L_7.get_z_2();
		if ((!(((float)L_6) == ((float)L_8))))
		{
			goto IL_0039;
		}
	}
	{
		float L_9 = __this->get_w_3();
		float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  L_10 = ___rhs0;
		float L_11 = L_10.get_w_3();
		return (bool)((((float)L_9) == ((float)L_11))? 1 : 0);
	}

IL_0039:
	{
		return (bool)0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint32_t math_hash_m53A15DB25196562BA8CF64481E3F9B4995AE75F7_inline (float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  ___v0, const RuntimeMethod* method)
{
	{
		// return csum(asuint(v) * uint4(0xE69626FFu, 0xBD010EEBu, 0x9CEDE1D1u, 0x43BE0B51u)) + 0xAF836EE1u;
		float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  L_0 = ___v0;
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_1;
		L_1 = math_asuint_m3D2A8007FE91051287F5761C654CD4E7F4B669CB_inline(L_0, /*hidden argument*/NULL);
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_2;
		L_2 = math_uint4_m2AAC3E9468B39F889CA506EF27BAD9E428C6E15D_inline(((int32_t)-426367233), ((int32_t)-1124004117), ((int32_t)-1662131759), ((int32_t)1136528209), /*hidden argument*/NULL);
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_3;
		L_3 = uint4_op_Multiply_m27352F838EE80439EE98A136D8D246AF5E9EF681_inline(L_1, L_2, /*hidden argument*/NULL);
		uint32_t L_4;
		L_4 = math_csum_m6A08B2FBD9E51F2CC9984B12285CEB4B188B2A35_inline(L_3, /*hidden argument*/NULL);
		return ((int32_t)il2cpp_codegen_add((int32_t)L_4, (int32_t)((int32_t)-1350340895)));
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t float4_GetHashCode_m7138A6A1ED3F8142D24A7D0F53264FD3D3C2DA97_inline (float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 * __this, const RuntimeMethod* method)
{
	{
		// public override int GetHashCode() { return (int)math.hash(this); }
		float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  L_0 = (*(float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 *)__this);
		uint32_t L_1;
		L_1 = math_hash_m53A15DB25196562BA8CF64481E3F9B4995AE75F7_inline(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR String_t* float4_ToString_mEF96A2289BB136EEE679B8F90D771C58DB031EB7_inline (float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Single_tE07797BA3C98D4CA9B5A19413C19A76688AB899E_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral43DDB8ABCD260FFF159CAB7520989AEB22E45033);
		s_Il2CppMethodInitialized = true;
	}
	{
		// return string.Format("float4({0}f, {1}f, {2}f, {3}f)", x, y, z, w);
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_0 = (ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE*)(ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE*)SZArrayNew(ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE_il2cpp_TypeInfo_var, (uint32_t)4);
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_1 = L_0;
		float L_2 = __this->get_x_0();
		float L_3 = L_2;
		RuntimeObject * L_4 = Box(Single_tE07797BA3C98D4CA9B5A19413C19A76688AB899E_il2cpp_TypeInfo_var, &L_3);
		NullCheck(L_1);
		ArrayElementTypeCheck (L_1, L_4);
		(L_1)->SetAt(static_cast<il2cpp_array_size_t>(0), (RuntimeObject *)L_4);
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_5 = L_1;
		float L_6 = __this->get_y_1();
		float L_7 = L_6;
		RuntimeObject * L_8 = Box(Single_tE07797BA3C98D4CA9B5A19413C19A76688AB899E_il2cpp_TypeInfo_var, &L_7);
		NullCheck(L_5);
		ArrayElementTypeCheck (L_5, L_8);
		(L_5)->SetAt(static_cast<il2cpp_array_size_t>(1), (RuntimeObject *)L_8);
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_9 = L_5;
		float L_10 = __this->get_z_2();
		float L_11 = L_10;
		RuntimeObject * L_12 = Box(Single_tE07797BA3C98D4CA9B5A19413C19A76688AB899E_il2cpp_TypeInfo_var, &L_11);
		NullCheck(L_9);
		ArrayElementTypeCheck (L_9, L_12);
		(L_9)->SetAt(static_cast<il2cpp_array_size_t>(2), (RuntimeObject *)L_12);
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_13 = L_9;
		float L_14 = __this->get_w_3();
		float L_15 = L_14;
		RuntimeObject * L_16 = Box(Single_tE07797BA3C98D4CA9B5A19413C19A76688AB899E_il2cpp_TypeInfo_var, &L_15);
		NullCheck(L_13);
		ArrayElementTypeCheck (L_13, L_16);
		(L_13)->SetAt(static_cast<il2cpp_array_size_t>(3), (RuntimeObject *)L_16);
		String_t* L_17;
		L_17 = String_Format_mCED6767EA5FEE6F15ABCD5B4F9150D1284C2795B(_stringLiteral43DDB8ABCD260FFF159CAB7520989AEB22E45033, L_13, /*hidden argument*/NULL);
		return L_17;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR String_t* float4_ToString_mF157EB1EA5B178949D39582EEB7AD960797E3CCF_inline (float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883 * __this, String_t* ___format0, RuntimeObject* ___formatProvider1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral43DDB8ABCD260FFF159CAB7520989AEB22E45033);
		s_Il2CppMethodInitialized = true;
	}
	{
		// return string.Format("float4({0}f, {1}f, {2}f, {3}f)", x.ToString(format, formatProvider), y.ToString(format, formatProvider), z.ToString(format, formatProvider), w.ToString(format, formatProvider));
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_0 = (ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE*)(ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE*)SZArrayNew(ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE_il2cpp_TypeInfo_var, (uint32_t)4);
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_1 = L_0;
		float* L_2 = __this->get_address_of_x_0();
		String_t* L_3 = ___format0;
		RuntimeObject* L_4 = ___formatProvider1;
		String_t* L_5;
		L_5 = Single_ToString_m7631D332703B4197EAA7DC0BA067CE7E16334D8B((float*)L_2, L_3, L_4, /*hidden argument*/NULL);
		NullCheck(L_1);
		ArrayElementTypeCheck (L_1, L_5);
		(L_1)->SetAt(static_cast<il2cpp_array_size_t>(0), (RuntimeObject *)L_5);
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_6 = L_1;
		float* L_7 = __this->get_address_of_y_1();
		String_t* L_8 = ___format0;
		RuntimeObject* L_9 = ___formatProvider1;
		String_t* L_10;
		L_10 = Single_ToString_m7631D332703B4197EAA7DC0BA067CE7E16334D8B((float*)L_7, L_8, L_9, /*hidden argument*/NULL);
		NullCheck(L_6);
		ArrayElementTypeCheck (L_6, L_10);
		(L_6)->SetAt(static_cast<il2cpp_array_size_t>(1), (RuntimeObject *)L_10);
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_11 = L_6;
		float* L_12 = __this->get_address_of_z_2();
		String_t* L_13 = ___format0;
		RuntimeObject* L_14 = ___formatProvider1;
		String_t* L_15;
		L_15 = Single_ToString_m7631D332703B4197EAA7DC0BA067CE7E16334D8B((float*)L_12, L_13, L_14, /*hidden argument*/NULL);
		NullCheck(L_11);
		ArrayElementTypeCheck (L_11, L_15);
		(L_11)->SetAt(static_cast<il2cpp_array_size_t>(2), (RuntimeObject *)L_15);
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_16 = L_11;
		float* L_17 = __this->get_address_of_w_3();
		String_t* L_18 = ___format0;
		RuntimeObject* L_19 = ___formatProvider1;
		String_t* L_20;
		L_20 = Single_ToString_m7631D332703B4197EAA7DC0BA067CE7E16334D8B((float*)L_17, L_18, L_19, /*hidden argument*/NULL);
		NullCheck(L_16);
		ArrayElementTypeCheck (L_16, L_20);
		(L_16)->SetAt(static_cast<il2cpp_array_size_t>(3), (RuntimeObject *)L_20);
		String_t* L_21;
		L_21 = String_Format_mCED6767EA5FEE6F15ABCD5B4F9150D1284C2795B(_stringLiteral43DDB8ABCD260FFF159CAB7520989AEB22E45033, L_16, /*hidden argument*/NULL);
		return L_21;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void int2__ctor_mF2809193E310D356095F5534AF632CEB504845D1_inline (int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558 * __this, int32_t ___x0, int32_t ___y1, const RuntimeMethod* method)
{
	{
		// this.x = x;
		int32_t L_0 = ___x0;
		__this->set_x_0(L_0);
		// this.y = y;
		int32_t L_1 = ___y1;
		__this->set_y_1(L_1);
		// }
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool int2_Equals_m24E4968D84F6232AB37F57692C3F8CBC03036668_inline (int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558 * __this, int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558  ___rhs0, const RuntimeMethod* method)
{
	{
		// public bool Equals(int2 rhs) { return x == rhs.x && y == rhs.y; }
		int32_t L_0 = __this->get_x_0();
		int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558  L_1 = ___rhs0;
		int32_t L_2 = L_1.get_x_0();
		if ((!(((uint32_t)L_0) == ((uint32_t)L_2))))
		{
			goto IL_001d;
		}
	}
	{
		int32_t L_3 = __this->get_y_1();
		int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558  L_4 = ___rhs0;
		int32_t L_5 = L_4.get_y_1();
		return (bool)((((int32_t)L_3) == ((int32_t)L_5))? 1 : 0);
	}

IL_001d:
	{
		return (bool)0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint32_t math_hash_m23BB2E45EEDF0493DF3AD90AC3837C34A70FE471_inline (int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558  ___v0, const RuntimeMethod* method)
{
	{
		// return csum(asuint(v) * uint2(0x83B58237u, 0x833E3E29u)) + 0xA9D919BFu;
		int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558  L_0 = ___v0;
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_1;
		L_1 = math_asuint_mA2C4FDC7E23CDB70403D11B606D2ED33B4A6551D_inline(L_0, /*hidden argument*/NULL);
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_2;
		L_2 = math_uint2_mF2E830E0F3E660D4E640F5EF5D5A3FCA75378D01_inline(((int32_t)-2085256649), ((int32_t)-2093072855), /*hidden argument*/NULL);
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_3;
		L_3 = uint2_op_Multiply_m7636391131B0EDC9918A5772AD85C68109F2235F_inline(L_1, L_2, /*hidden argument*/NULL);
		uint32_t L_4;
		L_4 = math_csum_m27D50739B96EE2F2DEA2EABD207F2B827F87E232_inline(L_3, /*hidden argument*/NULL);
		return ((int32_t)il2cpp_codegen_add((int32_t)L_4, (int32_t)((int32_t)-1445389889)));
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t int2_GetHashCode_m8F2D5944D3AEC3ADCB056ADD4B03DF6038B5C7B0_inline (int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558 * __this, const RuntimeMethod* method)
{
	{
		// public override int GetHashCode() { return (int)math.hash(this); }
		int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558  L_0 = (*(int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558 *)__this);
		uint32_t L_1;
		L_1 = math_hash_m23BB2E45EEDF0493DF3AD90AC3837C34A70FE471_inline(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR String_t* int2_ToString_m04651E132A626D5DDED8BCF33FB65768602FB655_inline (int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Int32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral039B19E6A63E9AA22F1AF2817559D285768A7B4A);
		s_Il2CppMethodInitialized = true;
	}
	{
		// return string.Format("int2({0}, {1})", x, y);
		int32_t L_0 = __this->get_x_0();
		int32_t L_1 = L_0;
		RuntimeObject * L_2 = Box(Int32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_il2cpp_TypeInfo_var, &L_1);
		int32_t L_3 = __this->get_y_1();
		int32_t L_4 = L_3;
		RuntimeObject * L_5 = Box(Int32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_il2cpp_TypeInfo_var, &L_4);
		String_t* L_6;
		L_6 = String_Format_m8D1CB0410C35E052A53AE957C914C841E54BAB66(_stringLiteral039B19E6A63E9AA22F1AF2817559D285768A7B4A, L_2, L_5, /*hidden argument*/NULL);
		return L_6;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR String_t* int2_ToString_mBE1C05766EA0EE72C974AB8D78FBB0FFE747E1AC_inline (int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558 * __this, String_t* ___format0, RuntimeObject* ___formatProvider1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral039B19E6A63E9AA22F1AF2817559D285768A7B4A);
		s_Il2CppMethodInitialized = true;
	}
	{
		// return string.Format("int2({0}, {1})", x.ToString(format, formatProvider), y.ToString(format, formatProvider));
		int32_t* L_0 = __this->get_address_of_x_0();
		String_t* L_1 = ___format0;
		RuntimeObject* L_2 = ___formatProvider1;
		String_t* L_3;
		L_3 = Int32_ToString_m246774E1922012AE787EB97743F42CB798B70CD8((int32_t*)L_0, L_1, L_2, /*hidden argument*/NULL);
		int32_t* L_4 = __this->get_address_of_y_1();
		String_t* L_5 = ___format0;
		RuntimeObject* L_6 = ___formatProvider1;
		String_t* L_7;
		L_7 = Int32_ToString_m246774E1922012AE787EB97743F42CB798B70CD8((int32_t*)L_4, L_5, L_6, /*hidden argument*/NULL);
		String_t* L_8;
		L_8 = String_Format_m8D1CB0410C35E052A53AE957C914C841E54BAB66(_stringLiteral039B19E6A63E9AA22F1AF2817559D285768A7B4A, L_3, L_7, /*hidden argument*/NULL);
		return L_8;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  math_asuint_mADD3FB6B29BD406CC3254B1DE3776D5B92F7B161_inline (float2_t11F5F2974404951113DDC4E13EEB6E2456295547  ___x0, const RuntimeMethod* method)
{
	{
		// public static uint2 asuint(float2 x) { return uint2(asuint(x.x), asuint(x.y)); }
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_0 = ___x0;
		float L_1 = L_0.get_x_0();
		uint32_t L_2;
		L_2 = math_asuint_m5C798CD94D48BA6240ECBB5EFDAD2D565ECDDEE6_inline(L_1, /*hidden argument*/NULL);
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_3 = ___x0;
		float L_4 = L_3.get_y_1();
		uint32_t L_5;
		L_5 = math_asuint_m5C798CD94D48BA6240ECBB5EFDAD2D565ECDDEE6_inline(L_4, /*hidden argument*/NULL);
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_6;
		L_6 = math_uint2_mF2E830E0F3E660D4E640F5EF5D5A3FCA75378D01_inline(L_2, L_5, /*hidden argument*/NULL);
		return L_6;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  math_uint2_mF2E830E0F3E660D4E640F5EF5D5A3FCA75378D01_inline (uint32_t ___x0, uint32_t ___y1, const RuntimeMethod* method)
{
	{
		// public static uint2 uint2(uint x, uint y) { return new uint2(x, y); }
		uint32_t L_0 = ___x0;
		uint32_t L_1 = ___y1;
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_2;
		memset((&L_2), 0, sizeof(L_2));
		uint2__ctor_m73EC9E1A714B67A555B594981E100729750DCE96_inline((&L_2), L_0, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  uint2_op_Multiply_m7636391131B0EDC9918A5772AD85C68109F2235F_inline (uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  ___lhs0, uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  ___rhs1, const RuntimeMethod* method)
{
	{
		// public static uint2 operator * (uint2 lhs, uint2 rhs) { return new uint2 (lhs.x * rhs.x, lhs.y * rhs.y); }
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_0 = ___lhs0;
		uint32_t L_1 = L_0.get_x_0();
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_2 = ___rhs1;
		uint32_t L_3 = L_2.get_x_0();
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_4 = ___lhs0;
		uint32_t L_5 = L_4.get_y_1();
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_6 = ___rhs1;
		uint32_t L_7 = L_6.get_y_1();
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_8;
		memset((&L_8), 0, sizeof(L_8));
		uint2__ctor_m73EC9E1A714B67A555B594981E100729750DCE96_inline((&L_8), ((int32_t)il2cpp_codegen_multiply((int32_t)L_1, (int32_t)L_3)), ((int32_t)il2cpp_codegen_multiply((int32_t)L_5, (int32_t)L_7)), /*hidden argument*/NULL);
		return L_8;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint32_t math_csum_m27D50739B96EE2F2DEA2EABD207F2B827F87E232_inline (uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  ___x0, const RuntimeMethod* method)
{
	{
		// public static uint csum(uint2 x) { return x.x + x.y; }
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_0 = ___x0;
		uint32_t L_1 = L_0.get_x_0();
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_2 = ___x0;
		uint32_t L_3 = L_2.get_y_1();
		return ((int32_t)il2cpp_codegen_add((int32_t)L_1, (int32_t)L_3));
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  math_asuint_m391E0BC4333E70109D0AC31DBAB8693A082791A7_inline (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___x0, const RuntimeMethod* method)
{
	{
		// public static uint3 asuint(float3 x) { return uint3(asuint(x.x), asuint(x.y), asuint(x.z)); }
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_0 = ___x0;
		float L_1 = L_0.get_x_0();
		uint32_t L_2;
		L_2 = math_asuint_m5C798CD94D48BA6240ECBB5EFDAD2D565ECDDEE6_inline(L_1, /*hidden argument*/NULL);
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_3 = ___x0;
		float L_4 = L_3.get_y_1();
		uint32_t L_5;
		L_5 = math_asuint_m5C798CD94D48BA6240ECBB5EFDAD2D565ECDDEE6_inline(L_4, /*hidden argument*/NULL);
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_6 = ___x0;
		float L_7 = L_6.get_z_2();
		uint32_t L_8;
		L_8 = math_asuint_m5C798CD94D48BA6240ECBB5EFDAD2D565ECDDEE6_inline(L_7, /*hidden argument*/NULL);
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_9;
		L_9 = math_uint3_mCA0FF72ACE1A3319B3E19C41638C710CCFC56A68_inline(L_2, L_5, L_8, /*hidden argument*/NULL);
		return L_9;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  math_uint3_mCA0FF72ACE1A3319B3E19C41638C710CCFC56A68_inline (uint32_t ___x0, uint32_t ___y1, uint32_t ___z2, const RuntimeMethod* method)
{
	{
		// public static uint3 uint3(uint x, uint y, uint z) { return new uint3(x, y, z); }
		uint32_t L_0 = ___x0;
		uint32_t L_1 = ___y1;
		uint32_t L_2 = ___z2;
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_3;
		memset((&L_3), 0, sizeof(L_3));
		uint3__ctor_m3B61A70D37EB10BE4F26625A9BBB52466AE9ECE3_inline((&L_3), L_0, L_1, L_2, /*hidden argument*/NULL);
		return L_3;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  uint3_op_Multiply_mBF3B660B4057B2D4ACD4B6B3DDDC4E747A6C8877_inline (uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  ___lhs0, uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  ___rhs1, const RuntimeMethod* method)
{
	{
		// public static uint3 operator * (uint3 lhs, uint3 rhs) { return new uint3 (lhs.x * rhs.x, lhs.y * rhs.y, lhs.z * rhs.z); }
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_0 = ___lhs0;
		uint32_t L_1 = L_0.get_x_0();
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_2 = ___rhs1;
		uint32_t L_3 = L_2.get_x_0();
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_4 = ___lhs0;
		uint32_t L_5 = L_4.get_y_1();
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_6 = ___rhs1;
		uint32_t L_7 = L_6.get_y_1();
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_8 = ___lhs0;
		uint32_t L_9 = L_8.get_z_2();
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_10 = ___rhs1;
		uint32_t L_11 = L_10.get_z_2();
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_12;
		memset((&L_12), 0, sizeof(L_12));
		uint3__ctor_m3B61A70D37EB10BE4F26625A9BBB52466AE9ECE3_inline((&L_12), ((int32_t)il2cpp_codegen_multiply((int32_t)L_1, (int32_t)L_3)), ((int32_t)il2cpp_codegen_multiply((int32_t)L_5, (int32_t)L_7)), ((int32_t)il2cpp_codegen_multiply((int32_t)L_9, (int32_t)L_11)), /*hidden argument*/NULL);
		return L_12;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint32_t math_csum_m60444A45FBA529E9ED20646FA61559F4B53D96ED_inline (uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  ___x0, const RuntimeMethod* method)
{
	{
		// public static uint csum(uint3 x) { return x.x + x.y + x.z; }
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_0 = ___x0;
		uint32_t L_1 = L_0.get_x_0();
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_2 = ___x0;
		uint32_t L_3 = L_2.get_y_1();
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_4 = ___x0;
		uint32_t L_5 = L_4.get_z_2();
		return ((int32_t)il2cpp_codegen_add((int32_t)((int32_t)il2cpp_codegen_add((int32_t)L_1, (int32_t)L_3)), (int32_t)L_5));
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  math_asuint_m3D2A8007FE91051287F5761C654CD4E7F4B669CB_inline (float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  ___x0, const RuntimeMethod* method)
{
	{
		// public static uint4 asuint(float4 x) { return uint4(asuint(x.x), asuint(x.y), asuint(x.z), asuint(x.w)); }
		float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  L_0 = ___x0;
		float L_1 = L_0.get_x_0();
		uint32_t L_2;
		L_2 = math_asuint_m5C798CD94D48BA6240ECBB5EFDAD2D565ECDDEE6_inline(L_1, /*hidden argument*/NULL);
		float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  L_3 = ___x0;
		float L_4 = L_3.get_y_1();
		uint32_t L_5;
		L_5 = math_asuint_m5C798CD94D48BA6240ECBB5EFDAD2D565ECDDEE6_inline(L_4, /*hidden argument*/NULL);
		float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  L_6 = ___x0;
		float L_7 = L_6.get_z_2();
		uint32_t L_8;
		L_8 = math_asuint_m5C798CD94D48BA6240ECBB5EFDAD2D565ECDDEE6_inline(L_7, /*hidden argument*/NULL);
		float4_t866F9B9B0DB07AE8949D4ACE92A0A84C88769883  L_9 = ___x0;
		float L_10 = L_9.get_w_3();
		uint32_t L_11;
		L_11 = math_asuint_m5C798CD94D48BA6240ECBB5EFDAD2D565ECDDEE6_inline(L_10, /*hidden argument*/NULL);
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_12;
		L_12 = math_uint4_m2AAC3E9468B39F889CA506EF27BAD9E428C6E15D_inline(L_2, L_5, L_8, L_11, /*hidden argument*/NULL);
		return L_12;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  math_uint4_m2AAC3E9468B39F889CA506EF27BAD9E428C6E15D_inline (uint32_t ___x0, uint32_t ___y1, uint32_t ___z2, uint32_t ___w3, const RuntimeMethod* method)
{
	{
		// public static uint4 uint4(uint x, uint y, uint z, uint w) { return new uint4(x, y, z, w); }
		uint32_t L_0 = ___x0;
		uint32_t L_1 = ___y1;
		uint32_t L_2 = ___z2;
		uint32_t L_3 = ___w3;
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_4;
		memset((&L_4), 0, sizeof(L_4));
		uint4__ctor_m542805076C6C9E3A87DC3242D32E60C4347439E8_inline((&L_4), L_0, L_1, L_2, L_3, /*hidden argument*/NULL);
		return L_4;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  uint4_op_Multiply_m27352F838EE80439EE98A136D8D246AF5E9EF681_inline (uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  ___lhs0, uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  ___rhs1, const RuntimeMethod* method)
{
	{
		// public static uint4 operator * (uint4 lhs, uint4 rhs) { return new uint4 (lhs.x * rhs.x, lhs.y * rhs.y, lhs.z * rhs.z, lhs.w * rhs.w); }
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_0 = ___lhs0;
		uint32_t L_1 = L_0.get_x_0();
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_2 = ___rhs1;
		uint32_t L_3 = L_2.get_x_0();
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_4 = ___lhs0;
		uint32_t L_5 = L_4.get_y_1();
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_6 = ___rhs1;
		uint32_t L_7 = L_6.get_y_1();
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_8 = ___lhs0;
		uint32_t L_9 = L_8.get_z_2();
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_10 = ___rhs1;
		uint32_t L_11 = L_10.get_z_2();
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_12 = ___lhs0;
		uint32_t L_13 = L_12.get_w_3();
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_14 = ___rhs1;
		uint32_t L_15 = L_14.get_w_3();
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_16;
		memset((&L_16), 0, sizeof(L_16));
		uint4__ctor_m542805076C6C9E3A87DC3242D32E60C4347439E8_inline((&L_16), ((int32_t)il2cpp_codegen_multiply((int32_t)L_1, (int32_t)L_3)), ((int32_t)il2cpp_codegen_multiply((int32_t)L_5, (int32_t)L_7)), ((int32_t)il2cpp_codegen_multiply((int32_t)L_9, (int32_t)L_11)), ((int32_t)il2cpp_codegen_multiply((int32_t)L_13, (int32_t)L_15)), /*hidden argument*/NULL);
		return L_16;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint32_t math_csum_m6A08B2FBD9E51F2CC9984B12285CEB4B188B2A35_inline (uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  ___x0, const RuntimeMethod* method)
{
	{
		// public static uint csum(uint4 x) { return x.x + x.y + x.z + x.w; }
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_0 = ___x0;
		uint32_t L_1 = L_0.get_x_0();
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_2 = ___x0;
		uint32_t L_3 = L_2.get_y_1();
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_4 = ___x0;
		uint32_t L_5 = L_4.get_z_2();
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_6 = ___x0;
		uint32_t L_7 = L_6.get_w_3();
		return ((int32_t)il2cpp_codegen_add((int32_t)((int32_t)il2cpp_codegen_add((int32_t)((int32_t)il2cpp_codegen_add((int32_t)L_1, (int32_t)L_3)), (int32_t)L_5)), (int32_t)L_7));
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  math_asuint_mA2C4FDC7E23CDB70403D11B606D2ED33B4A6551D_inline (int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558  ___x0, const RuntimeMethod* method)
{
	{
		// public static uint2 asuint(int2 x) { return uint2((uint)x.x, (uint)x.y); }
		int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558  L_0 = ___x0;
		int32_t L_1 = L_0.get_x_0();
		int2_tF5D919E29091CECAA300ADBF6461B71B0A5F9558  L_2 = ___x0;
		int32_t L_3 = L_2.get_y_1();
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_4;
		L_4 = math_uint2_mF2E830E0F3E660D4E640F5EF5D5A3FCA75378D01_inline(L_1, L_3, /*hidden argument*/NULL);
		return L_4;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t math_asint_mA58A5DFF25FB3AF5A3D8705D6BA70B916A2E41E7_inline (float ___x0, const RuntimeMethod* method)
{
	IntFloatUnion_t3B42C127ECCA706E64B5C2B9EE370A632FC83548  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		// u.intValue = 0;
		(&V_0)->set_intValue_0(0);
		// u.floatValue = x;
		float L_0 = ___x0;
		(&V_0)->set_floatValue_1(L_0);
		// return u.intValue;
		IntFloatUnion_t3B42C127ECCA706E64B5C2B9EE370A632FC83548  L_1 = V_0;
		int32_t L_2 = L_1.get_intValue_0();
		return L_2;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint32_t math_asuint_m5C798CD94D48BA6240ECBB5EFDAD2D565ECDDEE6_inline (float ___x0, const RuntimeMethod* method)
{
	{
		// public static uint asuint(float x) { return (uint)asint(x); }
		float L_0 = ___x0;
		int32_t L_1;
		L_1 = math_asint_mA58A5DFF25FB3AF5A3D8705D6BA70B916A2E41E7_inline(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_asfloat_m0F490C819C7F72ECFEA9B6079E690C72ED5028ED_inline (int32_t ___x0, const RuntimeMethod* method)
{
	IntFloatUnion_t3B42C127ECCA706E64B5C2B9EE370A632FC83548  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		// u.floatValue = 0;
		(&V_0)->set_floatValue_1((0.0f));
		// u.intValue = x;
		int32_t L_0 = ___x0;
		(&V_0)->set_intValue_0(L_0);
		// return u.floatValue;
		IntFloatUnion_t3B42C127ECCA706E64B5C2B9EE370A632FC83548  L_1 = V_0;
		float L_2 = L_1.get_floatValue_1();
		return L_2;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_asfloat_m10F84A2A94E30A6EA7D23F9FCDBCDDB709328684_inline (uint32_t ___x0, const RuntimeMethod* method)
{
	{
		// public static float  asfloat(uint x) { return asfloat((int)x); }
		uint32_t L_0 = ___x0;
		float L_1;
		L_1 = math_asfloat_m0F490C819C7F72ECFEA9B6079E690C72ED5028ED_inline(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float2_t11F5F2974404951113DDC4E13EEB6E2456295547  math_float2_mB67FFC2F70C70410B564621543211FA6172F549F_inline (float ___x0, float ___y1, const RuntimeMethod* method)
{
	{
		// public static float2 float2(float x, float y) { return new float2(x, y); }
		float L_0 = ___x0;
		float L_1 = ___y1;
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_2;
		memset((&L_2), 0, sizeof(L_2));
		float2__ctor_mA85C140C72CD3A1E8F287AEC7FF12A35C85C819C_inline((&L_2), L_0, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_min_m39054317B5C9E28B04360370E05713632A3B544F_inline (float ___x0, float ___y1, const RuntimeMethod* method)
{
	{
		// public static float min(float x, float y) { return float.IsNaN(y) || x < y ? x : y; }
		float L_0 = ___y1;
		bool L_1;
		L_1 = Single_IsNaN_m458FF076EF1944D4D888A585F7C6C49DA4730599(L_0, /*hidden argument*/NULL);
		if (L_1)
		{
			goto IL_000e;
		}
	}
	{
		float L_2 = ___x0;
		float L_3 = ___y1;
		if ((((float)L_2) < ((float)L_3)))
		{
			goto IL_000e;
		}
	}
	{
		float L_4 = ___y1;
		return L_4;
	}

IL_000e:
	{
		float L_5 = ___x0;
		return L_5;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_max_m2D9E0840A13662E878067A28926E1A85323E7E25_inline (float ___x0, float ___y1, const RuntimeMethod* method)
{
	{
		// public static float max(float x, float y) { return float.IsNaN(y) || x > y ? x : y; }
		float L_0 = ___y1;
		bool L_1;
		L_1 = Single_IsNaN_m458FF076EF1944D4D888A585F7C6C49DA4730599(L_0, /*hidden argument*/NULL);
		if (L_1)
		{
			goto IL_000e;
		}
	}
	{
		float L_2 = ___x0;
		float L_3 = ___y1;
		if ((((float)L_2) > ((float)L_3)))
		{
			goto IL_000e;
		}
	}
	{
		float L_4 = ___y1;
		return L_4;
	}

IL_000e:
	{
		float L_5 = ___x0;
		return L_5;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  uint2_op_BitwiseAnd_mB0E2C747CA4063432C69AFBC68BB4EC28B2815C2_inline (uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  ___lhs0, uint32_t ___rhs1, const RuntimeMethod* method)
{
	{
		// public static uint2 operator & (uint2 lhs, uint rhs) { return new uint2 (lhs.x & rhs, lhs.y & rhs); }
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_0 = ___lhs0;
		uint32_t L_1 = L_0.get_x_0();
		uint32_t L_2 = ___rhs1;
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_3 = ___lhs0;
		uint32_t L_4 = L_3.get_y_1();
		uint32_t L_5 = ___rhs1;
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_6;
		memset((&L_6), 0, sizeof(L_6));
		uint2__ctor_m73EC9E1A714B67A555B594981E100729750DCE96_inline((&L_6), ((int32_t)((int32_t)L_1&(int32_t)L_2)), ((int32_t)((int32_t)L_4&(int32_t)L_5)), /*hidden argument*/NULL);
		return L_6;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float2_t11F5F2974404951113DDC4E13EEB6E2456295547  math_asfloat_m56FF653BF60DF76D1E13AF495440DF5EB57CFA6E_inline (uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  ___x0, const RuntimeMethod* method)
{
	{
		// public static float2 asfloat(uint2 x) { return float2(asfloat(x.x), asfloat(x.y)); }
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_0 = ___x0;
		uint32_t L_1 = L_0.get_x_0();
		float L_2;
		L_2 = math_asfloat_m10F84A2A94E30A6EA7D23F9FCDBCDDB709328684_inline(L_1, /*hidden argument*/NULL);
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_3 = ___x0;
		uint32_t L_4 = L_3.get_y_1();
		float L_5;
		L_5 = math_asfloat_m10F84A2A94E30A6EA7D23F9FCDBCDDB709328684_inline(L_4, /*hidden argument*/NULL);
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_6;
		L_6 = math_float2_mB67FFC2F70C70410B564621543211FA6172F549F_inline(L_2, L_5, /*hidden argument*/NULL);
		return L_6;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_dot_mF3A96DE35F8C3264D3FD4F70B4090DB3261B168B_inline (float2_t11F5F2974404951113DDC4E13EEB6E2456295547  ___x0, float2_t11F5F2974404951113DDC4E13EEB6E2456295547  ___y1, const RuntimeMethod* method)
{
	{
		// public static float dot(float2 x, float2 y) { return x.x * y.x + x.y * y.y; }
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_0 = ___x0;
		float L_1 = L_0.get_x_0();
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_2 = ___y1;
		float L_3 = L_2.get_x_0();
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_4 = ___x0;
		float L_5 = L_4.get_y_1();
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_6 = ___y1;
		float L_7 = L_6.get_y_1();
		return ((float)il2cpp_codegen_add((float)((float)il2cpp_codegen_multiply((float)L_1, (float)L_3)), (float)((float)il2cpp_codegen_multiply((float)L_5, (float)L_7))));
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_rsqrt_m4A5597C29F30C68AF6855620522D41CB739F9F80_inline (float ___x0, const RuntimeMethod* method)
{
	{
		// public static float rsqrt(float x) { return 1.0f / sqrt(x); }
		float L_0 = ___x0;
		float L_1;
		L_1 = math_sqrt_m4FD392CA865BFABB6645F3AE365F5FBA2F2F40F6(L_0, /*hidden argument*/NULL);
		return ((float)((float)(1.0f)/(float)L_1));
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float2_t11F5F2974404951113DDC4E13EEB6E2456295547  float2_op_Multiply_m07CB14BD054267E48BF40992AD4A341FAF0A21ED_inline (float ___lhs0, float2_t11F5F2974404951113DDC4E13EEB6E2456295547  ___rhs1, const RuntimeMethod* method)
{
	{
		// public static float2 operator * (float lhs, float2 rhs) { return new float2 (lhs * rhs.x, lhs * rhs.y); }
		float L_0 = ___lhs0;
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_1 = ___rhs1;
		float L_2 = L_1.get_x_0();
		float L_3 = ___lhs0;
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_4 = ___rhs1;
		float L_5 = L_4.get_y_1();
		float2_t11F5F2974404951113DDC4E13EEB6E2456295547  L_6;
		memset((&L_6), 0, sizeof(L_6));
		float2__ctor_mA85C140C72CD3A1E8F287AEC7FF12A35C85C819C_inline((&L_6), ((float)il2cpp_codegen_multiply((float)L_0, (float)L_2)), ((float)il2cpp_codegen_multiply((float)L_3, (float)L_5)), /*hidden argument*/NULL);
		return L_6;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_dot_m04AB38B7D16991336C8B141B3D59E7C4C6D9D3ED_inline (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___x0, float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___y1, const RuntimeMethod* method)
{
	{
		// public static float dot(float3 x, float3 y) { return x.x * y.x + x.y * y.y + x.z * y.z; }
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_0 = ___x0;
		float L_1 = L_0.get_x_0();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_2 = ___y1;
		float L_3 = L_2.get_x_0();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_4 = ___x0;
		float L_5 = L_4.get_y_1();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_6 = ___y1;
		float L_7 = L_6.get_y_1();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_8 = ___x0;
		float L_9 = L_8.get_z_2();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_10 = ___y1;
		float L_11 = L_10.get_z_2();
		return ((float)il2cpp_codegen_add((float)((float)il2cpp_codegen_add((float)((float)il2cpp_codegen_multiply((float)L_1, (float)L_3)), (float)((float)il2cpp_codegen_multiply((float)L_5, (float)L_7)))), (float)((float)il2cpp_codegen_multiply((float)L_9, (float)L_11))));
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  float3_op_Multiply_m66E0DDABA7E629CCCEFC6407B038D6FD42E1A1B0_inline (float ___lhs0, float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___rhs1, const RuntimeMethod* method)
{
	{
		// public static float3 operator * (float lhs, float3 rhs) { return new float3 (lhs * rhs.x, lhs * rhs.y, lhs * rhs.z); }
		float L_0 = ___lhs0;
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_1 = ___rhs1;
		float L_2 = L_1.get_x_0();
		float L_3 = ___lhs0;
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_4 = ___rhs1;
		float L_5 = L_4.get_y_1();
		float L_6 = ___lhs0;
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_7 = ___rhs1;
		float L_8 = L_7.get_z_2();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_9;
		memset((&L_9), 0, sizeof(L_9));
		float3__ctor_m853853CCAF2BC58F66EE07DB9338C1644698D483_inline((&L_9), ((float)il2cpp_codegen_multiply((float)L_0, (float)L_2)), ((float)il2cpp_codegen_multiply((float)L_3, (float)L_5)), ((float)il2cpp_codegen_multiply((float)L_6, (float)L_8)), /*hidden argument*/NULL);
		return L_9;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  float3_op_Multiply_m296B37BB82979715ED4A076EBE7BE72F83C56CD7_inline (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___lhs0, float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___rhs1, const RuntimeMethod* method)
{
	{
		// public static float3 operator * (float3 lhs, float3 rhs) { return new float3 (lhs.x * rhs.x, lhs.y * rhs.y, lhs.z * rhs.z); }
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_0 = ___lhs0;
		float L_1 = L_0.get_x_0();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_2 = ___rhs1;
		float L_3 = L_2.get_x_0();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_4 = ___lhs0;
		float L_5 = L_4.get_y_1();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_6 = ___rhs1;
		float L_7 = L_6.get_y_1();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_8 = ___lhs0;
		float L_9 = L_8.get_z_2();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_10 = ___rhs1;
		float L_11 = L_10.get_z_2();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_12;
		memset((&L_12), 0, sizeof(L_12));
		float3__ctor_m853853CCAF2BC58F66EE07DB9338C1644698D483_inline((&L_12), ((float)il2cpp_codegen_multiply((float)L_1, (float)L_3)), ((float)il2cpp_codegen_multiply((float)L_5, (float)L_7)), ((float)il2cpp_codegen_multiply((float)L_9, (float)L_11)), /*hidden argument*/NULL);
		return L_12;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  float3_op_Subtraction_mB3250D4D18B21370A6FEA3B2B527CFA7B6DE439D_inline (float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___lhs0, float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  ___rhs1, const RuntimeMethod* method)
{
	{
		// public static float3 operator - (float3 lhs, float3 rhs) { return new float3 (lhs.x - rhs.x, lhs.y - rhs.y, lhs.z - rhs.z); }
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_0 = ___lhs0;
		float L_1 = L_0.get_x_0();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_2 = ___rhs1;
		float L_3 = L_2.get_x_0();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_4 = ___lhs0;
		float L_5 = L_4.get_y_1();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_6 = ___rhs1;
		float L_7 = L_6.get_y_1();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_8 = ___lhs0;
		float L_9 = L_8.get_z_2();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_10 = ___rhs1;
		float L_11 = L_10.get_z_2();
		float3_tE0DD2FF13F818025945C9AC314390D2A1F55E37D  L_12;
		memset((&L_12), 0, sizeof(L_12));
		float3__ctor_m853853CCAF2BC58F66EE07DB9338C1644698D483_inline((&L_12), ((float)il2cpp_codegen_subtract((float)L_1, (float)L_3)), ((float)il2cpp_codegen_subtract((float)L_5, (float)L_7)), ((float)il2cpp_codegen_subtract((float)L_9, (float)L_11)), /*hidden argument*/NULL);
		return L_12;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void uint2__ctor_m73EC9E1A714B67A555B594981E100729750DCE96_inline (uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A * __this, uint32_t ___x0, uint32_t ___y1, const RuntimeMethod* method)
{
	{
		// this.x = x;
		uint32_t L_0 = ___x0;
		__this->set_x_0(L_0);
		// this.y = y;
		uint32_t L_1 = ___y1;
		__this->set_y_1(L_1);
		// }
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void uint3__ctor_m3B61A70D37EB10BE4F26625A9BBB52466AE9ECE3_inline (uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE * __this, uint32_t ___x0, uint32_t ___y1, uint32_t ___z2, const RuntimeMethod* method)
{
	{
		// this.x = x;
		uint32_t L_0 = ___x0;
		__this->set_x_0(L_0);
		// this.y = y;
		uint32_t L_1 = ___y1;
		__this->set_y_1(L_1);
		// this.z = z;
		uint32_t L_2 = ___z2;
		__this->set_z_2(L_2);
		// }
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void uint4__ctor_m542805076C6C9E3A87DC3242D32E60C4347439E8_inline (uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92 * __this, uint32_t ___x0, uint32_t ___y1, uint32_t ___z2, uint32_t ___w3, const RuntimeMethod* method)
{
	{
		// this.x = x;
		uint32_t L_0 = ___x0;
		__this->set_x_0(L_0);
		// this.y = y;
		uint32_t L_1 = ___y1;
		__this->set_y_1(L_1);
		// this.z = z;
		uint32_t L_2 = ___z2;
		__this->set_z_2(L_2);
		// this.w = w;
		uint32_t L_3 = ___w3;
		__this->set_w_3(L_3);
		// }
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool uint2_Equals_m4B2B64A008B39D7386AE19DEDA4AEC83E1C37B36_inline (uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A * __this, uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  ___rhs0, const RuntimeMethod* method)
{
	{
		// public bool Equals(uint2 rhs) { return x == rhs.x && y == rhs.y; }
		uint32_t L_0 = __this->get_x_0();
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_1 = ___rhs0;
		uint32_t L_2 = L_1.get_x_0();
		if ((!(((uint32_t)L_0) == ((uint32_t)L_2))))
		{
			goto IL_001d;
		}
	}
	{
		uint32_t L_3 = __this->get_y_1();
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_4 = ___rhs0;
		uint32_t L_5 = L_4.get_y_1();
		return (bool)((((int32_t)L_3) == ((int32_t)L_5))? 1 : 0);
	}

IL_001d:
	{
		return (bool)0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint32_t math_hash_m0A5EC4565F35FF66EB626E43BFE5C30853603652_inline (uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  ___v0, const RuntimeMethod* method)
{
	{
		// return csum(v * uint2(0x4473BBB1u, 0xCBA11D5Fu)) + 0x685835CFu;
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_0 = ___v0;
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_1;
		L_1 = math_uint2_mF2E830E0F3E660D4E640F5EF5D5A3FCA75378D01_inline(((int32_t)1148435377), ((int32_t)-878633633), /*hidden argument*/NULL);
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_2;
		L_2 = uint2_op_Multiply_m7636391131B0EDC9918A5772AD85C68109F2235F_inline(L_0, L_1, /*hidden argument*/NULL);
		uint32_t L_3;
		L_3 = math_csum_m27D50739B96EE2F2DEA2EABD207F2B827F87E232_inline(L_2, /*hidden argument*/NULL);
		return ((int32_t)il2cpp_codegen_add((int32_t)L_3, (int32_t)((int32_t)1750611407)));
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t uint2_GetHashCode_m5D6FED071659D7B1E286571116AA379996E21540_inline (uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A * __this, const RuntimeMethod* method)
{
	{
		// public override int GetHashCode() { return (int)math.hash(this); }
		uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A  L_0 = (*(uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A *)__this);
		uint32_t L_1;
		L_1 = math_hash_m0A5EC4565F35FF66EB626E43BFE5C30853603652_inline(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR String_t* uint2_ToString_mCAEFE74E44CB92672B2B6AFE042C6796416F18D7_inline (uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&UInt32_tE60352A06233E4E69DD198BCC67142159F686B15_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralE368123B559BBC0EC2335D3AF9EC37C25C8B5945);
		s_Il2CppMethodInitialized = true;
	}
	{
		// return string.Format("uint2({0}, {1})", x, y);
		uint32_t L_0 = __this->get_x_0();
		uint32_t L_1 = L_0;
		RuntimeObject * L_2 = Box(UInt32_tE60352A06233E4E69DD198BCC67142159F686B15_il2cpp_TypeInfo_var, &L_1);
		uint32_t L_3 = __this->get_y_1();
		uint32_t L_4 = L_3;
		RuntimeObject * L_5 = Box(UInt32_tE60352A06233E4E69DD198BCC67142159F686B15_il2cpp_TypeInfo_var, &L_4);
		String_t* L_6;
		L_6 = String_Format_m8D1CB0410C35E052A53AE957C914C841E54BAB66(_stringLiteralE368123B559BBC0EC2335D3AF9EC37C25C8B5945, L_2, L_5, /*hidden argument*/NULL);
		return L_6;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR String_t* uint2_ToString_mF753477C3131F00ABFE352F02919CC57CB6F8F88_inline (uint2_t7EFB16363EC27D5EE357BB695C2916A9E8C03D7A * __this, String_t* ___format0, RuntimeObject* ___formatProvider1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralE368123B559BBC0EC2335D3AF9EC37C25C8B5945);
		s_Il2CppMethodInitialized = true;
	}
	{
		// return string.Format("uint2({0}, {1})", x.ToString(format, formatProvider), y.ToString(format, formatProvider));
		uint32_t* L_0 = __this->get_address_of_x_0();
		String_t* L_1 = ___format0;
		RuntimeObject* L_2 = ___formatProvider1;
		String_t* L_3;
		L_3 = UInt32_ToString_mAF0A46E9EC70EA43A02EBE522FF287E20DEE691B((uint32_t*)L_0, L_1, L_2, /*hidden argument*/NULL);
		uint32_t* L_4 = __this->get_address_of_y_1();
		String_t* L_5 = ___format0;
		RuntimeObject* L_6 = ___formatProvider1;
		String_t* L_7;
		L_7 = UInt32_ToString_mAF0A46E9EC70EA43A02EBE522FF287E20DEE691B((uint32_t*)L_4, L_5, L_6, /*hidden argument*/NULL);
		String_t* L_8;
		L_8 = String_Format_m8D1CB0410C35E052A53AE957C914C841E54BAB66(_stringLiteralE368123B559BBC0EC2335D3AF9EC37C25C8B5945, L_3, L_7, /*hidden argument*/NULL);
		return L_8;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool uint3_Equals_m4123D7A3796D0EB4F1D33541453971082875FAC5_inline (uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE * __this, uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  ___rhs0, const RuntimeMethod* method)
{
	{
		// public bool Equals(uint3 rhs) { return x == rhs.x && y == rhs.y && z == rhs.z; }
		uint32_t L_0 = __this->get_x_0();
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_1 = ___rhs0;
		uint32_t L_2 = L_1.get_x_0();
		if ((!(((uint32_t)L_0) == ((uint32_t)L_2))))
		{
			goto IL_002b;
		}
	}
	{
		uint32_t L_3 = __this->get_y_1();
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_4 = ___rhs0;
		uint32_t L_5 = L_4.get_y_1();
		if ((!(((uint32_t)L_3) == ((uint32_t)L_5))))
		{
			goto IL_002b;
		}
	}
	{
		uint32_t L_6 = __this->get_z_2();
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_7 = ___rhs0;
		uint32_t L_8 = L_7.get_z_2();
		return (bool)((((int32_t)L_6) == ((int32_t)L_8))? 1 : 0);
	}

IL_002b:
	{
		return (bool)0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint32_t math_hash_m8C856AA564098835DF61AF436DD3D70B51C34C56_inline (uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  ___v0, const RuntimeMethod* method)
{
	{
		// return csum(v * uint3(0xCD266C89u, 0xF1852A33u, 0x77E35E77u)) + 0x863E3729u;
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_0 = ___v0;
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_1;
		L_1 = math_uint3_mCA0FF72ACE1A3319B3E19C41638C710CCFC56A68_inline(((int32_t)-853119863), ((int32_t)-242931149), ((int32_t)2011389559), /*hidden argument*/NULL);
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_2;
		L_2 = uint3_op_Multiply_mBF3B660B4057B2D4ACD4B6B3DDDC4E747A6C8877_inline(L_0, L_1, /*hidden argument*/NULL);
		uint32_t L_3;
		L_3 = math_csum_m60444A45FBA529E9ED20646FA61559F4B53D96ED_inline(L_2, /*hidden argument*/NULL);
		return ((int32_t)il2cpp_codegen_add((int32_t)L_3, (int32_t)((int32_t)-2042742999)));
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t uint3_GetHashCode_mFAA802DA823258302D91BA287D4C924197646F5B_inline (uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE * __this, const RuntimeMethod* method)
{
	{
		// public override int GetHashCode() { return (int)math.hash(this); }
		uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE  L_0 = (*(uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE *)__this);
		uint32_t L_1;
		L_1 = math_hash_m8C856AA564098835DF61AF436DD3D70B51C34C56_inline(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR String_t* uint3_ToString_m0497363E44BBF1E7F68936646E1CFC09675FF23B_inline (uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&UInt32_tE60352A06233E4E69DD198BCC67142159F686B15_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralFEC52A4F763D4C868968D018DEC2AF8064D4C8E2);
		s_Il2CppMethodInitialized = true;
	}
	{
		// return string.Format("uint3({0}, {1}, {2})", x, y, z);
		uint32_t L_0 = __this->get_x_0();
		uint32_t L_1 = L_0;
		RuntimeObject * L_2 = Box(UInt32_tE60352A06233E4E69DD198BCC67142159F686B15_il2cpp_TypeInfo_var, &L_1);
		uint32_t L_3 = __this->get_y_1();
		uint32_t L_4 = L_3;
		RuntimeObject * L_5 = Box(UInt32_tE60352A06233E4E69DD198BCC67142159F686B15_il2cpp_TypeInfo_var, &L_4);
		uint32_t L_6 = __this->get_z_2();
		uint32_t L_7 = L_6;
		RuntimeObject * L_8 = Box(UInt32_tE60352A06233E4E69DD198BCC67142159F686B15_il2cpp_TypeInfo_var, &L_7);
		String_t* L_9;
		L_9 = String_Format_m039737CCD992C5BFC8D16DFD681F5E8786E87FA6(_stringLiteralFEC52A4F763D4C868968D018DEC2AF8064D4C8E2, L_2, L_5, L_8, /*hidden argument*/NULL);
		return L_9;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR String_t* uint3_ToString_m786F82DA9F9EE5A6985F8B8FE3600710D806232B_inline (uint3_tFFC02518718716A961F404F5474E31B2E0CE7CFE * __this, String_t* ___format0, RuntimeObject* ___formatProvider1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralFEC52A4F763D4C868968D018DEC2AF8064D4C8E2);
		s_Il2CppMethodInitialized = true;
	}
	{
		// return string.Format("uint3({0}, {1}, {2})", x.ToString(format, formatProvider), y.ToString(format, formatProvider), z.ToString(format, formatProvider));
		uint32_t* L_0 = __this->get_address_of_x_0();
		String_t* L_1 = ___format0;
		RuntimeObject* L_2 = ___formatProvider1;
		String_t* L_3;
		L_3 = UInt32_ToString_mAF0A46E9EC70EA43A02EBE522FF287E20DEE691B((uint32_t*)L_0, L_1, L_2, /*hidden argument*/NULL);
		uint32_t* L_4 = __this->get_address_of_y_1();
		String_t* L_5 = ___format0;
		RuntimeObject* L_6 = ___formatProvider1;
		String_t* L_7;
		L_7 = UInt32_ToString_mAF0A46E9EC70EA43A02EBE522FF287E20DEE691B((uint32_t*)L_4, L_5, L_6, /*hidden argument*/NULL);
		uint32_t* L_8 = __this->get_address_of_z_2();
		String_t* L_9 = ___format0;
		RuntimeObject* L_10 = ___formatProvider1;
		String_t* L_11;
		L_11 = UInt32_ToString_mAF0A46E9EC70EA43A02EBE522FF287E20DEE691B((uint32_t*)L_8, L_9, L_10, /*hidden argument*/NULL);
		String_t* L_12;
		L_12 = String_Format_m039737CCD992C5BFC8D16DFD681F5E8786E87FA6(_stringLiteralFEC52A4F763D4C868968D018DEC2AF8064D4C8E2, L_3, L_7, L_11, /*hidden argument*/NULL);
		return L_12;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool uint4_Equals_mCD29FF2676C20223B8043FD676230CCB4EAA934D_inline (uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92 * __this, uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  ___rhs0, const RuntimeMethod* method)
{
	{
		// public bool Equals(uint4 rhs) { return x == rhs.x && y == rhs.y && z == rhs.z && w == rhs.w; }
		uint32_t L_0 = __this->get_x_0();
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_1 = ___rhs0;
		uint32_t L_2 = L_1.get_x_0();
		if ((!(((uint32_t)L_0) == ((uint32_t)L_2))))
		{
			goto IL_0039;
		}
	}
	{
		uint32_t L_3 = __this->get_y_1();
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_4 = ___rhs0;
		uint32_t L_5 = L_4.get_y_1();
		if ((!(((uint32_t)L_3) == ((uint32_t)L_5))))
		{
			goto IL_0039;
		}
	}
	{
		uint32_t L_6 = __this->get_z_2();
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_7 = ___rhs0;
		uint32_t L_8 = L_7.get_z_2();
		if ((!(((uint32_t)L_6) == ((uint32_t)L_8))))
		{
			goto IL_0039;
		}
	}
	{
		uint32_t L_9 = __this->get_w_3();
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_10 = ___rhs0;
		uint32_t L_11 = L_10.get_w_3();
		return (bool)((((int32_t)L_9) == ((int32_t)L_11))? 1 : 0);
	}

IL_0039:
	{
		return (bool)0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint32_t math_hash_m75BFBA2E7EB5F1542B66C31F5CC1F398EFBF697E_inline (uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  ___v0, const RuntimeMethod* method)
{
	{
		// return csum(v * uint4(0xB492BF15u, 0xD37220E3u, 0x7AA2C2BDu, 0xE16BC89Du)) + 0x7AA07CD3u;
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_0 = ___v0;
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_1;
		L_1 = math_uint4_m2AAC3E9468B39F889CA506EF27BAD9E428C6E15D_inline(((int32_t)-1265451243), ((int32_t)-747495197), ((int32_t)2057487037), ((int32_t)-513029987), /*hidden argument*/NULL);
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_2;
		L_2 = uint4_op_Multiply_m27352F838EE80439EE98A136D8D246AF5E9EF681_inline(L_0, L_1, /*hidden argument*/NULL);
		uint32_t L_3;
		L_3 = math_csum_m6A08B2FBD9E51F2CC9984B12285CEB4B188B2A35_inline(L_2, /*hidden argument*/NULL);
		return ((int32_t)il2cpp_codegen_add((int32_t)L_3, (int32_t)((int32_t)2057338067)));
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t uint4_GetHashCode_m86A07B8FA19284D7065183699510D9601B490778_inline (uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92 * __this, const RuntimeMethod* method)
{
	{
		// public override int GetHashCode() { return (int)math.hash(this); }
		uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92  L_0 = (*(uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92 *)__this);
		uint32_t L_1;
		L_1 = math_hash_m75BFBA2E7EB5F1542B66C31F5CC1F398EFBF697E_inline(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR String_t* uint4_ToString_m9EFC2F5F7AC7B62F848D0E59CE894B72EED63B7B_inline (uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&UInt32_tE60352A06233E4E69DD198BCC67142159F686B15_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralE134155080D59FDE2A83A55D0BB359039175A4EA);
		s_Il2CppMethodInitialized = true;
	}
	{
		// return string.Format("uint4({0}, {1}, {2}, {3})", x, y, z, w);
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_0 = (ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE*)(ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE*)SZArrayNew(ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE_il2cpp_TypeInfo_var, (uint32_t)4);
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_1 = L_0;
		uint32_t L_2 = __this->get_x_0();
		uint32_t L_3 = L_2;
		RuntimeObject * L_4 = Box(UInt32_tE60352A06233E4E69DD198BCC67142159F686B15_il2cpp_TypeInfo_var, &L_3);
		NullCheck(L_1);
		ArrayElementTypeCheck (L_1, L_4);
		(L_1)->SetAt(static_cast<il2cpp_array_size_t>(0), (RuntimeObject *)L_4);
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_5 = L_1;
		uint32_t L_6 = __this->get_y_1();
		uint32_t L_7 = L_6;
		RuntimeObject * L_8 = Box(UInt32_tE60352A06233E4E69DD198BCC67142159F686B15_il2cpp_TypeInfo_var, &L_7);
		NullCheck(L_5);
		ArrayElementTypeCheck (L_5, L_8);
		(L_5)->SetAt(static_cast<il2cpp_array_size_t>(1), (RuntimeObject *)L_8);
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_9 = L_5;
		uint32_t L_10 = __this->get_z_2();
		uint32_t L_11 = L_10;
		RuntimeObject * L_12 = Box(UInt32_tE60352A06233E4E69DD198BCC67142159F686B15_il2cpp_TypeInfo_var, &L_11);
		NullCheck(L_9);
		ArrayElementTypeCheck (L_9, L_12);
		(L_9)->SetAt(static_cast<il2cpp_array_size_t>(2), (RuntimeObject *)L_12);
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_13 = L_9;
		uint32_t L_14 = __this->get_w_3();
		uint32_t L_15 = L_14;
		RuntimeObject * L_16 = Box(UInt32_tE60352A06233E4E69DD198BCC67142159F686B15_il2cpp_TypeInfo_var, &L_15);
		NullCheck(L_13);
		ArrayElementTypeCheck (L_13, L_16);
		(L_13)->SetAt(static_cast<il2cpp_array_size_t>(3), (RuntimeObject *)L_16);
		String_t* L_17;
		L_17 = String_Format_mCED6767EA5FEE6F15ABCD5B4F9150D1284C2795B(_stringLiteralE134155080D59FDE2A83A55D0BB359039175A4EA, L_13, /*hidden argument*/NULL);
		return L_17;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR String_t* uint4_ToString_mC1805F654F5474DF4F49D92910751B8A9B81C315_inline (uint4_t6C7A8C67DCDD20CC3282CA4AA5382744FB27EE92 * __this, String_t* ___format0, RuntimeObject* ___formatProvider1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralE134155080D59FDE2A83A55D0BB359039175A4EA);
		s_Il2CppMethodInitialized = true;
	}
	{
		// return string.Format("uint4({0}, {1}, {2}, {3})", x.ToString(format, formatProvider), y.ToString(format, formatProvider), z.ToString(format, formatProvider), w.ToString(format, formatProvider));
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_0 = (ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE*)(ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE*)SZArrayNew(ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE_il2cpp_TypeInfo_var, (uint32_t)4);
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_1 = L_0;
		uint32_t* L_2 = __this->get_address_of_x_0();
		String_t* L_3 = ___format0;
		RuntimeObject* L_4 = ___formatProvider1;
		String_t* L_5;
		L_5 = UInt32_ToString_mAF0A46E9EC70EA43A02EBE522FF287E20DEE691B((uint32_t*)L_2, L_3, L_4, /*hidden argument*/NULL);
		NullCheck(L_1);
		ArrayElementTypeCheck (L_1, L_5);
		(L_1)->SetAt(static_cast<il2cpp_array_size_t>(0), (RuntimeObject *)L_5);
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_6 = L_1;
		uint32_t* L_7 = __this->get_address_of_y_1();
		String_t* L_8 = ___format0;
		RuntimeObject* L_9 = ___formatProvider1;
		String_t* L_10;
		L_10 = UInt32_ToString_mAF0A46E9EC70EA43A02EBE522FF287E20DEE691B((uint32_t*)L_7, L_8, L_9, /*hidden argument*/NULL);
		NullCheck(L_6);
		ArrayElementTypeCheck (L_6, L_10);
		(L_6)->SetAt(static_cast<il2cpp_array_size_t>(1), (RuntimeObject *)L_10);
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_11 = L_6;
		uint32_t* L_12 = __this->get_address_of_z_2();
		String_t* L_13 = ___format0;
		RuntimeObject* L_14 = ___formatProvider1;
		String_t* L_15;
		L_15 = UInt32_ToString_mAF0A46E9EC70EA43A02EBE522FF287E20DEE691B((uint32_t*)L_12, L_13, L_14, /*hidden argument*/NULL);
		NullCheck(L_11);
		ArrayElementTypeCheck (L_11, L_15);
		(L_11)->SetAt(static_cast<il2cpp_array_size_t>(2), (RuntimeObject *)L_15);
		ObjectU5BU5D_tC1F4EE0DB0B7300255F5FD4AF64FE4C585CF5ADE* L_16 = L_11;
		uint32_t* L_17 = __this->get_address_of_w_3();
		String_t* L_18 = ___format0;
		RuntimeObject* L_19 = ___formatProvider1;
		String_t* L_20;
		L_20 = UInt32_ToString_mAF0A46E9EC70EA43A02EBE522FF287E20DEE691B((uint32_t*)L_17, L_18, L_19, /*hidden argument*/NULL);
		NullCheck(L_16);
		ArrayElementTypeCheck (L_16, L_20);
		(L_16)->SetAt(static_cast<il2cpp_array_size_t>(3), (RuntimeObject *)L_20);
		String_t* L_21;
		L_21 = String_Format_mCED6767EA5FEE6F15ABCD5B4F9150D1284C2795B(_stringLiteralE134155080D59FDE2A83A55D0BB359039175A4EA, L_16, /*hidden argument*/NULL);
		return L_21;
	}
}
